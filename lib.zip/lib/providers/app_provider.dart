import 'dart:async';
import 'dart:convert';
import 'dart:math';

import '../app/route_paths.dart';
import 'package:cloud_firestore/cloud_firestore.dart'
    show DocumentSnapshot, FieldValue;
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_auth/firebase_auth.dart' as fa;
import 'package:flutter/foundation.dart';
import 'package:google_sign_in_all_platforms/google_sign_in_all_platforms.dart';
import 'package:localstore/localstore.dart';

import '../models/app_notification.dart';
import '../models/cash_game.dart';
import '../models/game.dart';
import '../models/group.dart';
import '../models/live_game.dart';
import '../models/table_settings.dart';
import '../models/tournament.dart';
import '../models/tournament_preset.dart';
import '../models/user.dart';
import '../models/chip_color.dart';
import '../repositories/firebase_repository.dart';
import '../utils/formatters.dart';
import '../utils/mock_data.dart';
import '../utils/model_codec.dart';
import '../utils/sanitization.dart';
import '../utils/tournament_engine.dart';
import '../utils/voice_service.dart';
import '../services/browser_notifications.dart';
import '../services/onesignal_sender.dart';
import '../services/projections.dart' as projections;
import '../services/push_service.dart';
import '../services/recovery_service.dart';

/// One future-level edit produced by the admin structure editor.
typedef LevelEdit = ({int level, int sb, int bb, int? ante, int durationMins});

/// Result of looking up a game / TV code.
enum CodeLookupResult { game, tv, notFound, rateLimited }

/// What a scanned / typed / pasted join code points at. Produced by
/// [AppProvider.resolveJoinCode] so the unified join screen can pick a flow.
enum JoinCodeKind { group, game, tv, notFound, rateLimited, error }

/// Outcome of [AppProvider.resolveJoinCode] — the [kind] plus the cleaned
/// [code] that was extracted from whatever the user entered (bare code,
/// full invite link, or QR payload).
class JoinCodeResolution {
  const JoinCodeResolution(this.kind, this.code);

  final JoinCodeKind kind;
  final String code;
}

/// How the admin wants checked-in players distributed to tables/seats
/// (checklist §13.1). Mirrored by the screen's `SeatingMode`.
enum TableSeatingMode { random, manual, keepGuests, separateGuests }

/// A suggested seat move that balances table counts. Produced by
/// [AppProvider.requestSeatingBalance]; the admin must confirm it before it is
/// applied (checklist §13.2).
class SeatMoveRecommendation {
  const SeatMoveRecommendation({
    required this.fromPlayerId,
    required this.fromPlayerName,
    required this.fromTable,
    required this.fromSeat,
    required this.toTable,
    required this.toSeat,
    required this.reason,
  });

  final String fromPlayerId;
  final String fromPlayerName;
  final int fromTable;
  final int fromSeat;
  final int toTable;
  final int toSeat;
  final String reason;
}

/// Folds member-owned fields from the [remote] server game back into the
/// admin's [local] game just before an authority whole-document `.set()`, so a
/// member's RSVP / guest-slot write that landed while the admin's save was
/// debouncing is not silently overwritten.
///
/// Rules:
///  - the admin's own player row ([adminId]) keeps the local value (the admin
///    owns their own RSVP through a separate write path);
///  - every other member row adopts a differing server RSVP;
///  - rows present on the server but not locally are appended (a member who
///    joined after the game was created writes their whole row on first RSVP;
///    a "+N" RSVP creates guest rows) — local rows are never dropped;
///  - the server's guest-slot list wins whenever it differs (members rewrite
///    it via their +N count / guest names; the admin never edits slots).
///
/// Pure and side-effect free so it can be unit tested.
LiveGame mergeMemberOwnedFields(LiveGame local, LiveGame remote,
    {String? adminId}) {
  if (remote.id != local.id) return local;
  final localById = {for (final p in local.players) p.id: p};
  var changed = false;

  final merged = <Player>[
    for (final p in local.players)
      if (p.isGuest || p.id == adminId)
        p
      else
        () {
          final r = remote.players.where((x) => x.id == p.id).firstOrNull;
          if (r != null) {
            final rsvpChanged = r.rsvp != p.rsvp;
            // Merge checkedIn if the member checked themselves in remotely,
            // taking care not to let a stale remote overwrite an admin's local check-in.
            final checkInArrived = r.checkedIn && !p.checkedIn;
            
            if (rsvpChanged || checkInArrived) {
              changed = true;
              return p.copyWith(
                rsvp: r.rsvp,
                checkedIn: checkInArrived ? true : p.checkedIn,
              );
            }
          }
          return p;
        }(),
  ];

  for (final r in remote.players) {
    if (!localById.containsKey(r.id)) {
      merged.add(r);
      changed = true;
    }
  }

  String slotSig(List<GuestSlot> s) =>
      s.map((x) => guestSlotToMap(x).toString()).join('|');
  final slotsDiffer = slotSig(remote.guestSlots) != slotSig(local.guestSlots);

  if (!changed && !slotsDiffer) return local;
  return local.copyWith(
    players: merged,
    guestSlots: slotsDiffer ? remote.guestSlots : null,
  );
}

/// Re-attaches the admin-only figures that `saveGame` scrubs out of the public
/// game document (organizer cut, prize amounts, per-player financial counters)
/// onto a [remote] copy, taking them from the [local] one already in memory.
///
/// Every path that rebuilds the admin's current game from a server document
/// must apply this, so all of them produce structurally identical results for
/// identical server state. Pure and side-effect free for testing.
LiveGame restoreAdminPrivateFields(LiveGame remote, LiveGame local) {
  if (local.id != remote.id) return remote;
  final saved = {for (final p in local.players) p.id: p};
  return remote.copyWith(
    settings: remote.settings.copyWith(
      organizerPct: local.settings.organizerPct,
    ),
    players: [
      for (final p in remote.players)
        if (saved[p.id] case final r?)
          p.copyWith(
            rebuys: r.rebuys,
            reEntries: r.reEntries,
            hasAddOn: r.hasAddOn,
            knockouts: r.knockouts,
          )
        else
          p,
    ],
    structure: remote.structure.copyWith(
      prizes: local.structure.prizes,
      organizerAmount: local.structure.organizerAmount,
    ),
  );
}

/// Application-level UI state (no business logic / backend).
class AppProvider extends ChangeNotifier {
  AppProvider({String? initialColorTheme, String? initialThemePreference}) {
    if (initialColorTheme != null) _colorTheme = initialColorTheme;
    if (initialThemePreference != null) _themePreference = initialThemePreference;
    _currentGame = null;
    _startTick();
    _loadRecovery();
    _initConnectivity();
    // Firebase may be unavailable (widget tests run before initializeApp);
    // degrade gracefully by marking auth resolved so route guards open up.
    try {
      _authSub = _repo.authStateChanges().listen(_onAuthStateChanged);
    } catch (_) {
      _backendUp = false;
      _authReady = true;
    }
  }

  final FirebaseRepository _repo = FirebaseRepository.instance;

  /// False when Firebase never came up (widget tests) — every cloud sync
  /// entry point checks this before touching the repository.
  bool _backendUp = true;

  /// Firebase auth session subscription — cancelled on dispose.
  StreamSubscription<fa.User?>? _authSub;

  /// Live data subscriptions, all keyed to the signed-in user / selected
  /// group and cancelled on sign-out or dispose.
  StreamSubscription<List<GroupMembership>>? _groupsSub;
  StreamSubscription<Group>? _bundleSub;

  /// Whether the current group's live bundle has delivered its first snapshot.
  /// Reset to false on every [_selectGroup]; flipped true on the first emit.
  bool _bundleLoaded = false;

  /// Completes when the current group's bundle first loads (or errors). Lets
  /// [joinGroup] wait for real-time group data before the caller navigates.
  Completer<void>? _bundleReady;

  /// Completes once the signed-in user's data has bootstrapped after login —
  /// the groups index has loaded and (if a group was auto-selected) its bundle
  /// too. Lets [login] / [register] land the user on a populated dashboard.
  Completer<void>? _userBootstrap;

  /// Future that resolves when post-login data is ready (see [_userBootstrap]).
  Future<void> get userDataReady =>
      _userBootstrap?.future ?? Future<void>.value();
  StreamSubscription? _gameDocSub;

  /// Backoff re-subscription timers for the game-scoped streams. A Firestore
  /// `.snapshots()` that hits `permission-denied` (the auth token has not yet
  /// propagated into the SDK in the seconds after a web login) is dead for
  /// good, so we rebuild it a few times until it sticks — no page reload.
  Timer? _gameDocRetryTimer;
  Timer? _gameChatRetryTimer;

  /// Per-game chat lives in `groups/{gid}/games/{gameId}/chat` — a subcollection
  /// both the host and members append to directly. This keeps a member's
  /// message from being rolled back by the game-doc rule that forbids member
  /// `chat` writes, and from vanishing while it waits for the host to
  /// re-publish a projection.
  StreamSubscription<List<ChatMessage>>? _gameChatSub;
  List<ChatMessage> _gameChatMessages = const [];
  String? _gameChatKey;

  /// The signed-in member's own pending RSVP per game id. The write is
  /// committed the instant [setRSVP] runs; this overlay is re-applied on top
  /// of every adopted remote game so a lagging or racing snapshot never
  /// visibly reverts the member's own selection before their ack lands. The
  /// entry is dropped once a remote snapshot agrees, or if the write is
  /// rejected. `containsKey` distinguishes "no overlay" from "overlay = clear".
  final Map<String, Rsvp?> _pendingOwnRsvp = {};
  final Set<String> _pendingCheckIn = {};

  /// Last member-RSVP patch failure, surfaced on the invitation screen so
  /// backend rejections are never invisible (vs silent optimistic state that
  /// vanishes on refresh). Debug aid for the persistence audit.
  String? lastRsvpError;

  /// Last authority whole-document save failure. Non-null means the admin's
  /// most recent change did NOT reach Firestore — screens can surface it so a
  /// rejected write is never mistaken for a successful one.
  String? lastSaveError;

  StreamSubscription<dynamic>? _lookupSub;
  StreamSubscription<List<TournamentPreset>>? _presetsSub;
  StreamSubscription<
          List<({String id, String name, List<ChipColor> chips})>>?
      _chipSetsSub;
  StreamSubscription<List<AppNotification>>? _notificationsSub;
  StreamSubscription<List<GameRequest>>? _requestsSub;
  StreamSubscription<List<CashSession>>? _cashSub;
  StreamSubscription<List<GameResultRow>>? _resultsSub;
  StreamSubscription<List<Map<String, dynamic>>>? _pendingInvitesSub;

  /// Live member-rosters per group id, so the index-derived group list on the
  /// home screen / sidebar shows real-time member counts (free plan — no Cloud
  /// Function, and the membership index itself is not live).
  final Map<String, StreamSubscription<List<AppUser>>> _groupMembersSubs = {};

  /// Game ids whose own-result has already been written this session
  /// (doc id = gameId makes the write idempotent anyway).
  final Set<String> _resultsRecorded = <String>{};

  /// This player's lifetime results — aggregated into [_user.stats].
  List<GameResultRow> _myResults = const [];

  /// Signature of the last stats summary pushed to roster rows (dedupe).
  String? _lastPushedStatsKey;

  /// Browser-notification delivery bookkeeping: the first inbox emission is
  /// treated as history (never pushed); afterwards only new unread ids fire.
  final Set<String> _seenNotificationIds = <String>{};
  bool _notificationsPrimed = false;

  /// Debounces whole-document game saves so rapid admin edits coalesce.
  Timer? _gameSaveDebounce;
  Timer? _projectionDebounce;

  /// The game doc currently mirrored via [_gameDocSub] — used to skip
  /// adopting our own server acks (echo prevention).
  String? _syncedGameKey;

  /// True once a remote emission for [_syncedGameKey] was adopted; afterwards
  /// snapshots written by this device are ignored so debounced local edits are
  /// never reverted by their own ack.
  bool _gameSyncPrimed = false;

  /// True while a debounced save is pending — remote adoptions wait until it
  /// flushes so newer local state is not overwritten by an older snapshot.
  bool _pendingGameSave = false;

  /// Content signature of the last game state this device persisted (or
  /// adopted). `_syncGameToCloud` compares against this instead of object
  /// identity, so a bundle re-emit that hands back a fresh `LiveGame` instance
  /// with unchanged content is NOT treated as a local edit — that false
  /// "dirty" was starving the admin's `_adoptRemoteMap` and making the admin
  /// side look frozen while members updated live.
  String? _lastSavedSignature;
  String _gameSignature(LiveGame g) => jsonEncode(liveGameToMap(g));

  /// True the instant an authority makes a local edit to [_currentGame] that
  /// has not yet been persisted — set synchronously when the debounce timer is
  /// armed (not when it fires), so a remote snapshot that lands during the
  /// debounce window can no longer overwrite the admin's optimistic change
  /// (pause / resume / next level / accept check-in / confirm seating all
  /// "undoing themselves" a beat after the tap). Cleared once the save queue
  /// drains with nothing left to write.
  bool _localGameDirty = false;

  /// True once the first Firebase auth snapshot has been resolved. The router
  /// holds navigation at splash until this flips so the persisted session is
  /// restored before any guard runs.
  bool _authReady = false;
  bool get authReady => _authReady;

  bool _isTickUpdate = false;

  /// Timestamp of the last Firestore game sync — shown on TV mode as a
  /// staleness indicator so viewers know if the feed is stale.
  DateTime? _lastGameUpdate;
  DateTime? get lastGameUpdate => _lastGameUpdate;

  // ── Connectivity / recovery state (offline indicator, checklist 12-075) ────
  bool _isOffline = false;
  bool get isOffline => _isOffline;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  bool _hasReconnected = false;
  bool get hasReconnected => _hasReconnected;

  /// Initializes real connectivity monitoring (spec §15).
  void _initConnectivity() {
    try {
      _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
        final wasOffline = _isOffline;
        _isOffline = results.every((r) => r == ConnectivityResult.none);
        if (!wasOffline && _isOffline) {
          pushNotification(
            AppNotification(
              id: 'n-${DateTime.now().millisecondsSinceEpoch}',
              title: 'Connection warning',
              body: 'You are offline. Real-time sync is paused.',
              type: NotificationType.system,
              link: '/',
              read: false,
              timestamp: DateTime.now(),
            ),
          );
        }
        if (wasOffline && !_isOffline) {
          _hasReconnected = true;
        }
        notifyListeners();
      });
    } catch (_) {
      // connectivity_plus unavailable (tests) — stay with manual toggle
    }
  }

  /// Clears the reconnection banner after the user acknowledges it.
  void clearReconnectedBanner() {
    _hasReconnected = false;
    notifyListeners();
  }

  /// True when the active game was restored from local storage on startup.
  bool _restoredFromRecovery = false;
  bool get restoredFromRecovery => _restoredFromRecovery;
  DateTime? _recoveryTime;
  DateTime? get recoveryTime => _recoveryTime;

  /// Timestamp of the last non-clock data sync. TV/player/guest views use it
  /// to show "last updated" and distinguish a live feed from a stale one
  /// (checklist 15-039, 18-028, 20-038). Clock ticks do not count as syncs.
  DateTime _lastSync = DateTime.now();
  DateTime get lastSync => _lastSync;

  /// Demo-only toggle: flips the connectivity indicator. While offline every
  /// change is still persisted to local storage (RecoveryService), so nothing
  /// is lost and the app "reconnects" on tap.
  void toggleOffline() {
    _isOffline = !_isOffline;
    if (!_isOffline) _hasReconnected = true;
    notifyListeners();
  }

  @override
  void notifyListeners() {
    super.notifyListeners();
    if (_isTickUpdate) return;
    _lastSync = DateTime.now();
    _syncGameToCloud();
    _ensureRequestsSubscription();
    final game = _currentGame;
    if (game == null) {
      RecoveryService.clearGame();
    } else if (isAdmin) {
      // Crash-resume snapshots belong to the ADMIN only — they are the device
      // that owns the live game document. Saving one on a member's device made
      // their optimistic RSVP look "persisted" across a reload while the
      // server never received it (and, worse, the restored copy then blocked
      // all remote adoption — see [_dropRecoveryIfNotAuthority]).
      RecoveryService.saveGame(game);
    }
    final session = _cashSession;
    if (session != null && !session.isCompleted) {
      RecoveryService.saveCashSession(session);
    } else {
      RecoveryService.clearCashSession();
    }
  }

  // ── Preferences ────────────────────────────────────────────────────────────
  bool _notificationsEnabled = true;
  bool get notificationsEnabled => _notificationsEnabled;

  /// Enables push notifications. On Android/iOS this shows the OneSignal
  /// permission prompt; on web it prefers OneSignal web push and falls back
  /// to the plain Notification API when OneSignal isn't loaded. Returns an
  /// error message on denial, null on success.
  Future<String?> setNotificationsEnabled(bool value) async {
    final push = PushService.instance;
    if (value && push.isConfigured) {
      final granted = await push.requestPermission();
      if (!granted) {
        _notificationsEnabled = false;
        _persistPref('browserNotify', false);
        notifyListeners();
        if (kIsWeb) return 'Permission denied in this browser.';
        return 'Permission denied. Enable notifications for Poker Night '
            'in your device settings.';
      }
    } else if (value && kIsWeb && BrowserNotify.supported) {
      // OneSignal not configured — legacy web Notification API fallback.
      final granted = await BrowserNotify.requestPermission();
      if (!granted) {
        _notificationsEnabled = false;
        _persistPref('browserNotify', false);
        notifyListeners();
        return 'Permission denied in this browser.';
      }
    }
    if (!value && push.isConfigured) {
      // Soft-off: stop delivering pushes without revoking the OS permission.
      unawaited(push.optOut().catchError(
          (Object e) => debugPrint('push optOut failed: $e')));
    }
    _notificationsEnabled = value;
    _persistPref('browserNotify', value);
    notifyListeners();
    return null;
  }

  /// Called by [PushService] when the OS/browser permission changes.
  void syncPushPermission(bool granted) {
    if (!granted && _notificationsEnabled) {
      _notificationsEnabled = false;
      _persistPref('browserNotify', false);
      notifyListeners();
    }
  }

  /// Delivers newly-arrived inbox items as browser notifications when the
  /// user opted in; history is never replayed on sign-in. Skipped when
  /// OneSignal web push is live (the service worker already showed the
  /// system notification).
  void _deliverBrowserNotifications(List<AppNotification> list) {
    if (!_notificationsPrimed) {
      _notificationsPrimed = true;
      for (final n in list) {
        _seenNotificationIds.add(n.id);
      }
      return;
    }
    for (final n in list) {
      final isNew = _seenNotificationIds.add(n.id);
      if (isNew &&
          !n.read &&
          _notificationsEnabled &&
          !PushService.instance.suppressesInAppWebBanners) {
        BrowserNotify.show(n.title, n.body);
      }
    }
  }

  // ── Cloud sync plumbing ────────────────────────────────────────────────────
  /// Tracks which active-game document this device mirrors. When the key
  /// changes the old doc subscription is replaced and a fresh baseline is
  /// awaited before further remote adoptions.
  void _syncGameToCloud() {
    if (!_backendUp) return;
    _claimEditorIfNeeded();
    final game = _currentGame;
    final gid = game != null && game.groupId.isNotEmpty
        ? game.groupId
        : _currentGroupId;
    final key =
        (game == null || gid == null || _user == null) ? null : '$gid|${game.id}';

    if (key != _syncedGameKey) {
      _syncedGameKey = key;
      _gameSyncPrimed = false;
      _gameDocSub?.cancel();
      _gameDocSub = null;
      _gameDocRetryTimer?.cancel();
      _gameSaveDebounce?.cancel();
    _projectionDebounce?.cancel();
      _pendingGameSave = false;
      _localGameDirty = false;
      _lastSavedSignature = null;
      if (key != null && game != null && gid != null) {
        if (isGuest) {
          // Guests have no read access to the game doc — they follow the
          // sanitized publicGames projection (world-readable, no token gap).
          _gameDocSub = _repo.publicGameStream(game.id).listen((doc) {
            final payload = doc['guest'] as Map<String, dynamic>?;
            if (payload == null) return;
            _adoptRemoteMap(payload);
          }, onError: (Object e) => debugPrint('publicGameStream error: $e'));
        } else {
          // Admin authority reads the doc as admin; plain members follow the
          // raw doc too (rules gate it to isMember; figures are scrubbed in
          // saveGame). Both are auth-gated, so retry through the post-login
          // token-propagation gap instead of dying on the first denial.
          final asAdmin = _isGameAuthority;
          _subscribeGameDoc(key, gid, game.id, asAdmin: asAdmin);
        }
      }
    }

    // Per-game chat subcollection — followed by the host and every member so
    // messages appear immediately and survive the game-doc sync (see
    // [_gameChatMessages]).
    if (key != _gameChatKey) {
      _gameChatKey = key;
      _gameChatSub?.cancel();
      _gameChatSub = null;
      _gameChatRetryTimer?.cancel();
      _gameChatMessages = const [];
      if (key != null && game != null && gid != null && !isGuest) {
        _subscribeGameChat(key, gid, game.id);
      }
    }

    if (game == null || gid == null || _user == null) return;
    // Whole-document writes are reserved for the admin/authority device
    // (locked architecture §writes). Members patch their own fields and
    // guests use the request queue instead.
    if (!_isGameAuthority) return;
    // Content (not identity) check: a bundle re-emit hands back a fresh
    // LiveGame instance every time, so `identical` was perpetually false and
    // the admin was perpetually "dirty" — which blocked `_adoptRemoteMap` and
    // froze the admin's view. Only a real content change schedules a save.
    if (identical(_lastSavedGame, game)) return;
    final sig = _gameSignature(game);
    if (sig == _lastSavedSignature) return;
    // Mark the local game dirty NOW (not when the timer fires) so any remote
    // snapshot arriving during the debounce window is held off in
    // [_adoptRemoteMap] / the group-bundle handler instead of clobbering this
    // un-persisted edit.
    _localGameDirty = true;
    _gameSaveDebounce?.cancel();
    _projectionDebounce?.cancel();
    final effectiveGid = game.groupId.isNotEmpty ? game.groupId : gid;
    // Short debounce: the save queue ([_drainGameSaveQueue]) already coalesces
    // and serialises bursts, so a long wait only widens the window where a
    // concurrent remote write is invisible. Keep it tight for real-time feel.
    _gameSaveDebounce = Timer(const Duration(milliseconds: 250), () {
      final g = _currentGame;
      if (g == null || _user == null) return;
      _pendingLatestSave = g;
      _pendingGameSave = true;
      unawaited(_drainGameSaveQueue(effectiveGid));
    });
  }

  /// Serializes whole-document game saves so rapid admin actions (pause /
  /// resume, check-in accept, level changes) can never land out of order.
  /// Only one `.set()` runs at a time and the freshest snapshot always wins,
  /// so a slower earlier write can no longer clobber a newer one (the
  /// "tap 2-3-5 times then it works" / self-resume-pause symptom).
  bool _gameSaveInFlight = false;
  LiveGame? _pendingLatestSave;

  Future<void> _drainGameSaveQueue(String effectiveGid) async {
    if (_gameSaveInFlight) return;
    _gameSaveInFlight = true;
    try {
      do {
        final target = _pendingLatestSave;
        _pendingLatestSave = null;
        if (target == null || _user == null) break;
        final g = _currentGame;
        // Prefer the very latest authoritative state for this game.
        final freshest = (g != null && g.id == target.id) ? g : target;
        if (identical(_lastSavedGame, freshest)) continue;
        var toWrite = freshest.groupId.isNotEmpty
            ? freshest
            : freshest.copyWith(groupId: effectiveGid);
        // A member RSVP / guest-slot patch may have committed to the server
        // while this edit was debouncing (adoption was held off by
        // [_localGameDirty]). The whole-doc `.set()` below would silently
        // overwrite it, so fold those member-owned fields back in first.
        toWrite = await _reconcileMemberOwnedFields(toWrite);
        // Retry with backoff exactly like the member RSVP patch: right after a
        // web login the admin's writes are rejected with permission-denied
        // until the fresh auth token reaches the Firestore SDK. Previously the
        // first failure was rethrown out of an `unawaited(...)` call, which
        // both dropped the admin's edit and surfaced as an unhandled async
        // error in the console.
        const delaysMs = [0, 300, 800, 1800, 4000, 8000];
        var saved = false;
        Object? lastError;
        for (var attempt = 0; attempt < delaysMs.length && !saved; attempt++) {
          if (delaysMs[attempt] > 0) {
            await Future<void>.delayed(
                Duration(milliseconds: delaysMs[attempt]));
          }
          if (_user == null) break;
          var step = 'saveGame';
          try {
            await _repo.saveGame(toWrite, viewerId: _user?.id);
            step = 'publishProjections';
            await _publishProjections(toWrite);
            _lastSavedGame = toWrite;
            _lastSavedSignature = _gameSignature(toWrite);
            saved = true;
            if (lastSaveError != null) {
              lastSaveError = null;
              notifyListeners();
            }
          } catch (e) {
            lastError = e;
            debugPrint('$step failed (attempt ${attempt + 1}) '
                'gid=${toWrite.groupId} game=${toWrite.id} '
                'uid=${_user?.id} isAdmin=$isAdmin '
                'authority=$_isGameAuthority: $e');
            if (_isRetriablePermissionError(e)) await _nudgeAuthToken();
          }
        }
        if (!saved) {
          // Never rethrow out of this fire-and-forget drain — surface it
          // instead so the admin sees that their change did not persist.
          final errorStr = (lastError ?? '').toString().toLowerCase();
          if (_isRetriablePermissionError(lastError ?? '')) {
            lastSaveError = 'Changes not saved — this account does not have admin write access to this game.';
          } else if (errorStr.contains('quota-exceeded') || errorStr.contains('resource-exhausted') || errorStr.contains('quota')) {
            lastSaveError = 'Changes not saved — database quota exceeded (free tier limit reached).';
          } else {
            lastSaveError = 'Changes could not be saved. Check your connection.';
          }
          notifyListeners();
          break;
        }
      } while (_pendingLatestSave != null);
    } finally {
      _gameSaveInFlight = false;
      if (_pendingLatestSave == null) {
        _pendingGameSave = false;
        // Nothing left to write — local state now matches (or has been
        // superseded by) what is on the server, so remote snapshots may flow
        // through again.
        _localGameDirty = false;
      }
    }
  }

  /// Folds member-owned fields (per-player RSVP, guest slots, member-created
  /// guest rows) from the current server document back into [game] before an
  /// authority whole-doc save, so a member RSVP that committed during the
  /// debounce window is not silently overwritten. Best-effort: any failure or
  /// an in-progress admin RSVP change for this game leaves [game] untouched.
  Future<LiveGame> _reconcileMemberOwnedFields(LiveGame game) async {
    if (!_backendUp || game.groupId.isEmpty) return game;
    try {
      final raw = await _repo.gameDocOnce(game.groupId, game.id);
      if (raw == null) return game;
      final remote = liveGameFromFirestoreDoc(Map<String, dynamic>.from(raw));
      if (remote.id != game.id) return game;
      return mergeMemberOwnedFields(game, remote, adminId: _user?.id);
    } catch (e) {
      debugPrint('reconcileMemberOwnedFields failed: $e');
      return game;
    }
  }

  LiveGame? _lastSavedGame;

  /// Last resolved admin verdict per group id. While a group's live bundle is
  /// re-subscribing, [_currentGroup] is briefly the empty placeholder
  /// (blank ownerId, no members). Without this cache [isAdmin] would flip to
  /// false for those frames and the router / screen guards would bounce the
  /// admin off `/admin-dashboard` (or `/check-in`) mid-flow, then land them
  /// back a moment later. The cache holds the last real answer across that gap.
  final Map<String, bool> _adminVerdictByGroup = {};

  /// True when the signed-in user administers the current group (owner or a
  /// member row flagged `isAdmin`). Resilient to the transient empty-group
  /// window via [_adminVerdictByGroup].
  bool get isAdmin {
    final user = _user;
    if (user == null) return false;
    final group = _currentGroup;
    final gid = _currentGroupId ?? group.id;
    final resolvable =
        group.id.isNotEmpty && (group.ownerId.isNotEmpty || group.members.isNotEmpty);
    if (resolvable) {
      final verdict = group.ownerId == user.id ||
          group.members.any((m) => m.id == user.id && m.isAdmin);
      if (gid.isNotEmpty) _adminVerdictByGroup[gid] = verdict;
      return verdict;
    }
    // Placeholder group during a bundle re-subscription — reuse the last
    // real verdict for this group if we have one.
    if (gid.isNotEmpty && _adminVerdictByGroup.containsKey(gid)) {
      return _adminVerdictByGroup[gid]!;
    }
    return false;
  }

  /// True when the signed-in user holds the elevated Co-Admin role in the
  /// current group. Currently a cosmetic badge (permissions are restricted to 
  /// admin-only until multi-admin support is fully implemented).
  bool get isCoAdmin {
    final user = _user;
    if (user == null || isAdmin) return false;
    return _currentGroup.members.any((m) => m.id == user.id && m.isCoAdmin);
  }

  /// MVP spec §3.1: exactly one administrator per event. Co-admin permissions
  /// are restricted to admin-only until the multi-admin feature is implemented.
  bool get canManageMembers => isAdmin;

  /// MVP spec §3.3: only admin can grant rebuys/add-ons.
  bool get canGrantRebuys => isAdmin;

  /// This member's role in the current group, for role-picker UIs.
  GroupRole roleOf(AppUser member) => member.isAdmin
      ? GroupRole.admin
      : (member.isCoAdmin ? GroupRole.coAdmin : GroupRole.member);

  /// True only for the single "active editor" admin device — the one that may
  /// write the whole game document. Guests and plain members never qualify.
  /// The editor role lives in [LiveGame.editorDeviceId]: the first admin
  /// device to open a live game claims it, which prevents two admin sessions
  /// from racing whole-document writes (the seating-confirm revert bug).
  bool get _isGameAuthority =>
      isAdmin &&
      _currentGame != null &&
      (_currentGame!.editorDeviceId.isNotEmpty &&
          _currentGame!.editorDeviceId == _repo.deviceId);

  /// Single-active-editor claim (multi-device save fix). The first admin
  /// device to touch a live game becomes the whole-document writer and
  /// persists its device id; every other admin device stops writing the whole
  /// doc so a stale session can't clobber a fresh state (e.g. a confirmed
  /// seating plan). Never steals from an active editor.
  void _claimEditorIfNeeded() {
    final game = _currentGame;
    if (game == null || _user == null || !isAdmin || !_backendUp) return;
    final editor = game.editorDeviceId;
    final now = DateTime.now();
    final claimedAt = game.editorClaimedAt;
    final sameDevice = editor == _repo.deviceId;
    final stale = editor.isNotEmpty &&
        claimedAt != null &&
        now.difference(claimedAt) > _editorClaimStaleWindow;
    // Another live editor is actively writing — stay read-only.
    if (editor.isNotEmpty && !sameDevice && !stale) return;
    if (sameDevice) {
      // Heartbeat: ours. Persist the last-active stamp so other admin devices
      // don't judge us stale — but as a TARGETED, THROTTLED field patch, never
      // by mutating `_currentGame` (that made every notifyListeners() schedule
      // a full-document `.set()`, which continuously clobbered members' RSVP /
      // guest-slot writes — the "RSVP not persistent" bug).
      final due = _lastEditorHeartbeatAt == null ||
          now.difference(_lastEditorHeartbeatAt!) > _editorHeartbeatInterval;
      if (due) {
        _lastEditorHeartbeatAt = now;
        _patchActiveGame({'editorClaimedAt': now.toIso8601String()});
      }
      return;
    }
    _currentGame = game.copyWith(
      editorDeviceId: _repo.deviceId,
      editorClaimedAt: now,
    );
    _lastEditorHeartbeatAt = now;
    _syncGroupGame();
  }

  DateTime? _lastEditorHeartbeatAt;
  static const Duration _editorHeartbeatInterval = Duration(seconds: 25);

  /// Resolves `(gid, gameId)` for cloud operations on the active game, or
  /// null when there is nothing to target yet.
  (String, String)? get _cloudGameContext {
    final game = _currentGame;
    if (game == null || _user == null || !_backendUp) return null;
    final gid = game.groupId.isNotEmpty ? game.groupId : _currentGroupId;
    if (gid == null) return null;
    return (gid, game.id);
  }

  /// Member/guest-safe field patch: writes dot-paths without touching the
  /// rest of the document (locked architecture §writes).
  void _patchActiveGame(Map<String, dynamic> dotPaths) {
    final ctx = _cloudGameContext;
    if (ctx == null || dotPaths.isEmpty) return;
    unawaited(_repo
        .patchGame(ctx.$1, ctx.$2, dotPaths)
        .catchError((Object e) => debugPrint('patchGame failed: $e')));
  }

  /// Publishes sanitized public/TV/player/guest projections after a
  /// successful whole-doc save so TVs and guest devices can follow along.
  Future<void> _publishProjections(LiveGame game) async {
    if (!_backendUp) return;
    try {
      await _repo.publishPublicProjections(
        game: game,
        tv: liveGameToMap(projections.tvProjection(game)),
        player:
            liveGameToMap(projections.playerProjection(game, viewerId: '')),
        guest: liveGameToMap(projections.guestProjection(game)),
      );
    } catch (e) {
      debugPrint('publishProjections failed: $e');
      rethrow;
    }
  }

  /// Opens the request-queue subscription once this device qualifies as
  /// authority for the active game. Re-evaluated on every provider change so
  /// late-loading membership flips it on at the right moment.
  void _ensureRequestsSubscription() {
    if (!_backendUp || _currentGame == null || !_isGameAuthority) return;
    if (_requestsSub != null) return;
    final gameId = _currentGame!.id;
    _requestsSub = _repo.requestsStream(gameId).listen(
      _consumeRequests,
      onError: (Object e) => debugPrint('requests stream error: $e'),
    );
  }

  /// Applies queued member/guest requests to the authoritative local game,
  /// then marks each one consumed so other devices ignore it.
  Future<void> _consumeRequests(List<GameRequest> requests) async {
    final game = _currentGame;
    if (requests.isEmpty || game == null) return;
    final gameId = game.id;
    var changed = false;
    var hadError = false;
    for (final req in requests) {
      String? error;
      switch (req.kind) {
        case 'guestCheckIn':
          error = _applyQueuedGuestCheckIn(req.payload);
          break;
        case 'rebuyReq':
          requestRebuy((req.payload['playerId'] as String?) ?? '');
          break;
        case 'addOnReq':
          requestAddOn((req.payload['playerId'] as String?) ?? '');
          break;
        default:
          error = 'unknown kind';
      }
      if (error != null) hadError = true;
      try {
        await _repo.consumeRequest(gameId, req.id);
      } catch (e) {
        debugPrint('consumeRequest failed: $e');
      }
      changed = true;
    }
    if (changed && !hadError) notifyListeners();
  }

  /// Attaches a queued guest check-in to the authoritative game. Returns an
  /// error string when the slot is invalid — the request is consumed either
  /// way so it never re-processes.
  String? _applyQueuedGuestCheckIn(Map<String, dynamic> payload) {
    final game = _currentGame;
    if (game == null) return 'no active game';
    final name = Sanitization.sanitizeName((payload['name'] as String?) ?? 'Guest');
    final inviterId = (payload['inviterId'] as String?) ?? '';
    final slotNo = (payload['slot'] as num?)?.toInt() ?? 0;
    final guestId =
        (payload['guestId'] as String?) ?? 'g-${DateTime.now().millisecondsSinceEpoch}';

    final existingSlot = game.guestSlots
        .where((s) => s.inviterId == inviterId && s.slot == slotNo)
        .firstOrNull;
    if (game.status.isActiveLive && game.rebuysClosed) {
      return 'Late registration has closed - no new players can be added.';
    }
    if (existingSlot != null && !existingSlot.available) {
      return 'slot taken';
    }
    if (game.players.any(
      (p) => p.isGuest && p.inviterId == inviterId && p.guestSlot == slotNo,
    )) {
      return 'slot claimed';
    }

    final guest = Player(
      id: guestId,
      name: name,
      isGuest: true,
      inviterId: inviterId,
      guestSlot: slotNo,
      rsvp: Rsvp.going,
      checkedIn: false,
      confirmed: false,
      eliminated: false,
      rebuys: 0,
      hasAddOn: false,
      knockouts: 0,
      table: 0,
      seat: 0,
      active: false,
    );
    _pushUndo();
    _currentGame = game.copyWith(
      players: [...game.players, guest],
      pendingGuests: [...game.pendingGuests, guest],
      guestSlots: _markSlotReserved(
        game.guestSlots,
        inviterId,
        slotNo,
        name: name.trim(),
        // The queued claim carries the guest's check-in request (spec §7.1).
        requested: true,
      ),
    );
    
    // Alert the admin that a guest is waiting
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Guest Arrived',
        body: '$name is waiting to be checked in.',
        type: NotificationType.admin,
        link: '/game/${game.id}/check-in',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    
    return null;
  }

  /// Subscribes the raw game doc for a signed-in admin/member, re-subscribing
  /// with backoff if the stream errors (the post-login token gap). [key] pins
  /// the attempt to the current [_syncedGameKey] so a stale retry is dropped
  /// once the active game changes.
  void _subscribeGameDoc(String key, String gid, String gameId,
      {required bool asAdmin}) {
    var attempt = 0;
    void go() {
      if (_syncedGameKey != key) return;
      _gameDocSub?.cancel();
      _gameDocSub = _repo
          .gameDocSnapshots(gid, gameId, isAdmin: asAdmin)
          .listen(_adoptRemoteGame, onError: (Object e) {
        debugPrint('gameDoc stream error${asAdmin ? '' : ' (member)'}: $e');
        if (_syncedGameKey != key || attempt >= 8) return;
        if (_isRetriablePermissionError(e)) unawaited(_nudgeAuthToken());
        final delayMs = 400 * (1 << (attempt > 5 ? 5 : attempt));
        attempt++;
        _gameDocRetryTimer?.cancel();
        _gameDocRetryTimer = Timer(Duration(milliseconds: delayMs), go);
      });
    }

    go();
  }

  /// Per-game chat subscription with the same post-login backoff retry.
  void _subscribeGameChat(String key, String gid, String gameId) {
    var attempt = 0;
    void go() {
      if (_gameChatKey != key) return;
      _gameChatSub?.cancel();
      _gameChatSub = _repo.gameChatStream(gid, gameId).listen((msgs) {
        _gameChatMessages = msgs;
        notifyListeners();
      }, onError: (Object e) {
        debugPrint('gameChat stream error: $e');
        if (_gameChatKey != key || attempt >= 8) return;
        if (_isRetriablePermissionError(e)) unawaited(_nudgeAuthToken());
        final delayMs = 400 * (1 << (attempt > 5 ? 5 : attempt));
        attempt++;
        _gameChatRetryTimer?.cancel();
        _gameChatRetryTimer = Timer(Duration(milliseconds: delayMs), go);
      });
    }

    go();
  }

  /// Adopts a remote game document unless it is our own latency-compensated
  /// write or the ack of a write we just made (echo prevention, locked
  /// architecture §reads).
  void _adoptRemoteGame(DocumentSnapshot<Map<String, dynamic>> snap) {
    final data = snap.data();
    if (!snap.exists || data == null) return;
    if (snap.metadata.hasPendingWrites) return;
    _adoptRemoteMap(data);
  }

  /// Re-attaches the admin-only figures that `saveGame` scrubs out of the
  /// public game document (organizer cut, prize amounts, per-player financial
  /// counters) using the copy already held locally.
  ///
  /// EVERY path that rebuilds `_currentGame` from a server document must run
  /// this — `_adoptRemoteMap` (game-doc stream) and the group-bundle handler
  /// alike. When only one of them did, the two sources produced structurally
  /// different games for the same server state, which flipped the content
  /// signature on every bundle emit, left the admin permanently "dirty", and
  /// blocked the game-doc snapshot carrying a member's new RSVP.
  LiveGame _restoreAdminPrivateFields(LiveGame remote) {
    final local = _currentGame;
    if (!isAdmin || local == null) return remote;
    return restoreAdminPrivateFields(remote, local);
  }

  void _adoptRemoteMap(Map<String, dynamic> data) {
    if (!_gameSyncPrimed) {
      _gameSyncPrimed = true;
    } else if (data['writerId'] == _repo.deviceId) {
      return;
    }
    // A non-authority device must never let a local crash-resume snapshot win
    // over the server, so retire it before the guard below consults the flag.
    _dropRecoveryIfNotAuthority();
    // Hold off adopting remote state only while this device has a REAL
    // un-persisted authority edit (`_localGameDirty` is now content-based) or a
    // save in flight — otherwise a snapshot would revert the optimistic change.
    // The bare debounce-timer state is deliberately NOT checked: it is
    // rescheduled on every notify and would permanently block adoption.
    if (_pendingGameSave ||
        _localGameDirty ||
        _gameSaveInFlight ||
        _restoredFromRecovery) {
      return;
    }
    try {
      var remote = liveGameFromFirestoreDoc(Map<String, dynamic>.from(data));
      if (_currentGame?.id != remote.id) return;
      
      // Preserve private fields that are scrubbed from the public remote stream
      remote = _restoreAdminPrivateFields(remote);

      _currentGame = _withPendingCheckInOverlay(_withOwnRsvpOverlay(remote));
      _lastSavedGame = remote;
      // Adopted state is, by definition, in sync with the server — record its
      // signature so `_syncGameToCloud` doesn't immediately re-flag it dirty
      // and re-save it (the admin-side feedback loop). If an overlay changed
      // the content, the signature differs and the authority still saves it.
      _lastSavedSignature = _gameSignature(remote);
      // Crash-resume snapshots are the admin's (see [_dropRecoveryIfNotAuthority]).
      if (isAdmin) RecoveryService.saveGame(remote);
      // A foreign writer (e.g. the admin's whole-doc save) may have wiped this
      // member's just-written RSVP — re-write it rather than only masking it
      // with the overlay, so a page reload keeps the selection.
      _maybeReassertOwnRsvp(remote, data['writerId'] as String?);
      // Another device may have settled the tournament — record my result.
      _maybeRecordOwnResult(remote);
      if (_isGameAuthority) {
        // Fire-and-forget, but explicitly swallowed: `_publishProjections`
        // rethrows, and an un-caught rethrow out of a stream callback surfaced
        // as an unhandled async error (the RethrownDartError stack dumps).
        _projectionDebounce?.cancel();
        _projectionDebounce = Timer(const Duration(milliseconds: 1500), () {
          if (_currentGame != null) {
            unawaited(_publishProjections(_currentGame!).catchError((Object _) {}));
          }
        });
      }
      notifyListeners();
    } catch (e) {
      debugPrint('remote game decode failed: $e');
    }
  }

  /// How many times this member has re-written their own RSVP for a game after
  /// a foreign writer reverted it. Capped so a genuine rules rejection can't
  /// loop forever.
  final Map<String, int> _rsvpReassertCount = {};

  /// When a snapshot NOT written by this device still doesn't reflect this
  /// member's pending RSVP, re-issue the field patch (up to 3×). Purely
  /// masking it with [_pendingOwnRsvp] would keep the selection visible this
  /// session but lose it on reload.
  void _maybeReassertOwnRsvp(LiveGame remote, String? writerId) {
    final uid = _user?.id;
    if (uid == null || _isGameAuthority) return;
    if (!_pendingOwnRsvp.containsKey(remote.id)) return;
    if (writerId != null && writerId == _repo.deviceId) return;
    final want = _pendingOwnRsvp[remote.id];
    final serverMine = remote.players.where((p) => p.id == uid).firstOrNull;
    if (serverMine?.rsvp == want) return; // server already agrees
    final n = _rsvpReassertCount[remote.id] ?? 0;
    if (n >= 3) return;
    _rsvpReassertCount[remote.id] = n + 1;
    debugPrint('RSVP re-assert #${n + 1} for ${remote.id} '
        '(server=${serverMine?.rsvp?.name}, want=${want?.name})');
    final after = _withOwnRsvpOverlay(remote);
    _persistOwnRsvpPatch(remote.id, _rsvpDotPatch(remote, after), want);
  }

  /// Re-applies the member's own pending RSVP (see [_pendingOwnRsvp]) on top of
  /// a freshly adopted remote game, and drops the overlay once the remote
  /// agrees. No-op for the authority (they write the whole doc) and when
  /// there is no overlay for this game.
  LiveGame _withOwnRsvpOverlay(LiveGame game) {
    if (!_pendingOwnRsvp.containsKey(game.id)) return game;
    final uid = _user?.id;
    if (uid == null) return game;
    final want = _pendingOwnRsvp[game.id];
    final mine = game.players.where((p) => p.id == uid).firstOrNull;
    if (mine?.rsvp == want) {
      // The remote has caught up with the member's own selection — done.
      _pendingOwnRsvp.remove(game.id);
      _rsvpReassertCount.remove(game.id);
      return game;
    }
    final players = game.players.any((p) => p.id == uid)
        ? game.players
            .map((p) => p.id == uid ? p.copyWith(rsvp: want) : p)
            .toList()
        : [...game.players, _memberAsPlayer(uid, want)];
    var updated = game.copyWith(players: players);
    updated = _syncGuestSlots(updated, uid, want?.guestCount ?? 0);
    return updated;
  }

  LiveGame _withPendingCheckInOverlay(LiveGame game) {
    if (_pendingCheckIn.isEmpty) return game;
    var updated = game;
    final toRemove = <String>{};
    final updatedPlayers = game.players.map((p) {
      if (_pendingCheckIn.contains(p.id)) {
        if (p.checkedIn && p.confirmed) {
          toRemove.add(p.id);
          return p;
        }
        return p.copyWith(checkedIn: true, confirmed: false);
      }
      return p;
    }).toList();
    _pendingCheckIn.removeAll(toRemove);
    return updated.copyWith(players: updatedPlayers);
  }

  /// Subscribes every user-scoped collection after sign-in / hydration.
  void _subscribeUserData() {
    final uid = _repo.currentUid;
    if (!_backendUp || uid == null) return;

    // Release anyone waiting on a previous (now-cancelled) subscription before
    // starting a fresh bootstrap.
    if (!(_userBootstrap?.isCompleted ?? true)) _userBootstrap!.complete();
    _userBootstrap = Completer<void>();
    final bootstrap = _userBootstrap!;
    void bootstrapDone() {
      if (!bootstrap.isCompleted) bootstrap.complete();
    }

    _groupsSub?.cancel();
    _groupsSub = _repo.groupsIndexStream(uid).listen((rows) {
      // Rebuild from the lightweight index, but keep the already-loaded rich
      // bundle for the selected group (its members/games) so the sidebar count
      // doesn't flip back to 0 on every index re-delivery — apply the index's
      // pinned/name/icon on top.
      _groups = [
        for (final r in rows)
          if (r.groupId == _currentGroupId &&
              _currentGroup.id == r.groupId &&
              _currentGroup.members.isNotEmpty)
            _currentGroup.copyWith(
              name: r.name.isNotEmpty ? r.name : null,
              icon: r.icon,
              pinned: r.pinned,
            )
          else
            _groupFromMembership(r),
      ];
      // Additionally keep live member rosters for every group so home/sidebar
      // counts stay real-time even when no rich bundle is loaded yet.
      _syncGroupMembersSubs();
      // Mirror every group's notification outbox into this user's inbox
      // (free-plan fan-out — replaces the Cloud Function).
      _syncGroupOutboxSubs();
      // First group after sign-in is auto-selected (pinned first, then
      // alphabetical — same ordering the sidebar uses).
      if (_currentGroupId == null && rows.isNotEmpty) {
        final sorted = [...rows]
          ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        sorted.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
        _selectGroup(sorted.first.groupId);
      }
      // The index has loaded; if it picked a group, chain readiness to that
      // group's bundle so callers land on a populated dashboard.
      if (_currentGroupId != null) {
        groupReady.then((_) => bootstrapDone());
      } else {
        bootstrapDone();
      }
      notifyListeners();
    }, onError: (Object e) {
      debugPrint('groupsIndex stream error: $e');
      bootstrapDone();
    });

    _presetsSub?.cancel();
    _presetsSub = _repo.presetsStream(uid).listen((list) {
      _presets
        ..clear()
        ..addAll(list);
      notifyListeners();
    },
        onError: (Object e) => debugPrint('presets stream error: $e'));

    _chipSetsSub?.cancel();
    _chipSetsSub = _repo.chipSetsStream(uid).listen((list) {
      _savedChipSets
        ..clear()
        ..addAll(list);
      notifyListeners();
    },
        onError: (Object e) => debugPrint('chipSets stream error: $e'));

    _notificationsSub?.cancel();
    _notificationsSub = _repo.notificationsStream(uid).listen((list) {
      _deliverBrowserNotifications(list);
      _notifications = list;
      notifyListeners();
    },
        onError: (Object e) => debugPrint('notifications stream error: $e'));

    // Lifetime stats: recompute whenever a result lands (this device wrote it
    // or another device did — same source of truth either way).
    _resultsSub?.cancel();
    _resultsSub = _repo.resultsStream(uid).listen((rows) {
      _myResults = rows;
      final user = _user;
      if (user != null) {
        _user = user.copyWith(stats: _statsFromResults(rows));
        _pushStatsSummaries();
      }
      notifyListeners();
    },
        onError: (Object e) => debugPrint('results stream error: $e'));

    // Free-plan: accept pending admin-by-email invites by self-writing the
    // user's own membership index (there is no Cloud Function to mirror it).
    _pendingInvitesSub?.cancel();
    _pendingInvitesSub = _repo.pendingInvitesStream(uid).listen((invites) {
      for (final invite in invites) {
        final gid = invite['gid'] as String?;
        if (gid == null) continue;
        if (_groups.any((g) => g.id == gid)) continue;
        unawaited(_repo
            .updateGroupIndex(
              uid,
              gid,
              name: invite['name'] as String?,
              icon: invite['icon'] as String?,
              role: 'member',
            )
            .catchError((Object e) => debugPrint('accept invite failed: $e')));
        final inviteId = invite['id'] as String? ?? invite['__inviteId'] as String?;
        if (inviteId != null) {
          unawaited(_repo.removePendingInvite(inviteId).catchError(
              (Object e) => debugPrint('remove invite failed: $e')));
        }
      }
      notifyListeners();
    },
        onError: (Object e) => debugPrint('pendingInvites stream error: $e'));
  }

  /// Mirrors the lifetime stats summary onto this user's roster row in every
  /// group they belong to, so other members see real numbers. Skipped when
  /// the summary is unchanged since the last push.
  void _pushStatsSummaries() {
    if (!_backendUp) return;
    final stats = _user?.stats;
    final uid = _repo.currentUid;
    if (stats == null || uid == null) return;
    final key =
        '${stats.played}/${stats.wins}/${stats.podium}/${stats.avgFinish}/${stats.knockouts}';
    if (key == _lastPushedStatsKey) return;
    _lastPushedStatsKey = key;
    for (final g in _groups) {
      unawaited(_repo.saveMemberStats(g.id, uid, stats)
          .catchError((Object e) => debugPrint('saveMemberStats failed: $e')));
    }
  }

  /// Aggregates raw result rows into the lifetime [UserStats].
  UserStats _statsFromResults(List<GameResultRow> rows) {
    var wins = 0, podium = 0, knockouts = 0, finishSum = 0;
    for (final r in rows) {
      if (r.position <= 0) continue; // malformed / partial row
      if (r.position == 1) wins++;
      if (r.position <= 3) podium++;
      knockouts += r.knockouts;
      finishSum += r.position;
    }
    final played = rows.where((r) => r.position > 0).length;
    return UserStats(
      played: played,
      wins: wins,
      podium: podium,
      avgFinish: played == 0 ? 0 : finishSum / played,
      knockouts: knockouts,
    );
  }

  /// Offline/demo fallback for [_maybeRecordOwnResult]: keeps the in-memory
  /// result list and stats moving with no backend round-trip.
  void _recordOwnResultOffline(LiveGame game) {
    final uid = _user?.id;
    if (uid == null || game.finishOrder.isEmpty) return;
    if (_resultsRecorded.contains(game.id)) return;
    final me =
        game.players.where((p) => p.id == uid && !p.isGuest).firstOrNull;
    if (me == null) return;
    final index = game.finishOrder.indexOf(uid);
    if (index == -1) return;
    _resultsRecorded.add(game.id);
    _myResults = [
      ..._myResults.where((r) => r.gameId != game.id),
      GameResultRow(
        gameId: game.id,
        groupId: game.groupId,
        position: index + 1,
        playerCount: game.finishOrder.length,
        knockouts: me.knockouts,
        finishedAt: DateTime.now(),
      ),
    ];
    _user = _user?.copyWith(stats: _statsFromResults(_myResults));
    notifyListeners();
  }

  /// When [game] has settled, records this signed-in player's own result
  /// (`users/{uid}/results/{gameId}`) so every device aggregates identical
  /// lifetime stats. Guests are skipped.
  void _maybeRecordOwnResult(LiveGame game) {
    final uid = _repo.currentUid;
    if (!_backendUp || uid == null || _user == null) return;
    if (game.status != LiveGameStatus.completed || game.finishOrder.isEmpty) {
      return;
    }
    if (_resultsRecorded.contains(game.id)) return;
    final me =
        game.players.where((p) => p.id == uid && !p.isGuest).firstOrNull;
    if (me == null) return;
    final index = game.finishOrder.indexOf(uid);
    if (index == -1) return;
    _resultsRecorded.add(game.id);
    unawaited(_repo
        .saveGameResult(
          uid,
          game.id,
          GameResultRow(
            gameId: game.id,
            groupId: game.groupId,
            position: index + 1,
            playerCount: game.finishOrder.length,
            knockouts: me.knockouts,
            finishedAt: DateTime.now(),
          ),
        )
        .catchError(
            (Object e) => debugPrint('saveGameResult failed: $e')));
  }

  /// Cancels all user/group-scoped subscriptions and clears derived state.
  void _teardownUserData() {
    for (final s in [
      _groupsSub,
      _bundleSub,
      _gameDocSub,
      _gameChatSub,
      _lookupSub,
      _presetsSub,
      _chipSetsSub,
      _notificationsSub,
      _requestsSub,
      _cashSub,
      _resultsSub,
      _pendingInvitesSub,
    ]) {
      s?.cancel();
    }
    for (final s in _groupMembersSubs.values) {
      s.cancel();
    }
    _groupMembersSubs.clear();
    for (final s in _groupOutboxSubs.values) {
      s.cancel();
    }
    _groupOutboxSubs.clear();
    _outboxPrimed.clear();
    _mirrorCursors.clear();
    _mirroredOutboxIds.clear();
    _groupsSub = null;
    _bundleSub = null;
    _gameDocSub = null;
    _gameChatSub = null;
    _gameDocRetryTimer?.cancel();
    _gameChatRetryTimer?.cancel();
    _gameChatMessages = const [];
    _gameChatKey = null;
    _pendingOwnRsvp.clear();
    _rsvpReassertCount.clear();
    _pendingCheckIn.clear();
    _adminVerdictByGroup.clear();
    _localGameDirty = false;
    _lastSavedSignature = null;
    _lastEditorHeartbeatAt = null;
    lastSaveError = null;
    lastRsvpError = null;
    _lookupSub = null;
    _presetsSub = null;
    _chipSetsSub = null;
    _notificationsSub = null;
    _requestsSub = null;
    _cashSub = null;
    _resultsSub = null;
    _pendingInvitesSub = null;
    _gameSaveDebounce?.cancel();
    _projectionDebounce?.cancel();
    _pendingGameSave = false;
    _syncedGameKey = null;
    _gameSyncPrimed = false;
    _currentGroupId = null;
    _bundleLoaded = false;
    _bundleReady = null;
    _userBootstrap = null;
    // Drop any group-scoped state from the previous session so a different
    // account signing in on this device never sees it.
    _currentGroup = _kEmptyGroup;
    _notifications = const [];
    _cashHistory = const [];
    _myResults = const [];
    _resultsRecorded.clear();
    _lastPushedStatsKey = null;
    _seenNotificationIds.clear();
    _notificationsPrimed = false;
  }

  /// Selects a group by id and (re)subscribes its live bundle.
  void _selectGroup(String gid) {
    if (_currentGroupId == gid && _bundleSub != null) return;
    _currentGroupId = gid;
    _bundleSub?.cancel();
    _cashSub?.cancel();
    _cashSub = null;
    _bundleSub = null;
    _bundleLoaded = false;
    _bundleReady = Completer<void>();
    // Until the full bundle arrives, show the lightweight index row (name +
    // icon) for this group rather than the previously-selected group's data.
    final row = _groups.where((g) => g.id == gid).firstOrNull;
    _currentGroup = row ?? _kEmptyGroup;

    void markReady() {
      if (!(_bundleReady?.isCompleted ?? true)) _bundleReady!.complete();
    }

    if (!_backendUp) {
      markReady();
      return;
    }
    _bundleSub = _repo.groupBundleStream(gid).listen((g) {
      // _setGroup (not a bare `_currentGroup = g`) so the full group — members,
      // games, code — is also written into `_groups`, which backs the sidebar
      // / drawer / orderedGroups (they'd otherwise show the lightweight index
      // row with 0 members).
      // Keep the member's own not-yet-acked RSVP visible on the hub's game
      // cards too, not just the game screen (see [_pendingOwnRsvp]).
      final hydrated = _pendingOwnRsvp.isEmpty
          ? g
          : g.copyWith(
              games: g.games
                  .map((gm) => _withPendingCheckInOverlay(_withOwnRsvpOverlay(gm)))
                  .toList());
      _setGroup(hydrated);
      
      // The bundle is the first place a member's role becomes known, so retire
      // any stale local crash-resume snapshot here too.
      _dropRecoveryIfNotAuthority();
      // F-001 Fix: Keep the currently viewed game screen in sync for members
      // (and admins receiving RSVPs/Check-ins) without clobbering the admin's local timer.
      if (_currentGame != null) {
        if (isAdmin && (_pendingGameSave || _localGameDirty || _restoredFromRecovery)) {
          // Do not overwrite local edits with stale bundle data during debounce or recovery.
        } else {
          final updatedGame = hydrated.games.where((x) => x.id == _currentGame!.id).firstOrNull;
          if (updatedGame != null) {
            if (isAdmin) {
              // Same restore the game-doc stream applies, so both sources
              // produce an identical game for identical server state. Without
              // it the bundle copy (scrubbed) and the doc copy (restored)
              // alternated, the content signature flipped on every emit and
              // the admin stayed permanently "dirty" — which is what stopped
              // members' RSVPs from ever reaching the admin's screen.
              _currentGame = _restoreAdminPrivateFields(updatedGame).copyWith(
                secondsRemaining: _currentGame!.secondsRemaining,
                timerRunning: _currentGame!.timerRunning,
                levelEndTime: _currentGame!.levelEndTime,
              );
            } else {
              _currentGame = updatedGame;
            }
          }
        }
      }
      _bundleLoaded = true;
      markReady();
      // Catch results of games this device never followed live (e.g. the
      // player sat out or never opened the game screen).
      for (final finished in g.pastGames) {
        _maybeRecordOwnResult(finished);
      }
      notifyListeners();
    }, onError: (Object e) {
      debugPrint('groupBundle stream error: $e');
      markReady();
    });
    if (row?.ownerId == _user?.id) {
      _cashSub = _repo.completedCashSessionsStream(gid).listen((list) {
        _cashHistory = list;
        notifyListeners();
      }, onError: (Object e) => debugPrint('cashSessions stream error: $e'));
    }
  }

  /// Lightweight placeholder used before a group's live bundle has loaded and
  /// after the user leaves their last group.
  static const Group _kEmptyGroup = Group(
    id: '',
    name: '',
    joinCode: '',
    ownerId: '',
    members: [],
    games: [],
    chat: [],
    polls: [],
    notifications: [],
  );

  /// True while a group is selected but its live bundle (members, games, chat,
  /// settings) has not delivered its first snapshot — the group hub should
  /// render a loading state rather than an empty shell.
  bool get groupBundleLoading => _currentGroupId != null && !_bundleLoaded;

  /// Completes once the selected group's bundle has loaded (or errored).
  Future<void> get groupReady =>
      _bundleReady?.future ?? Future<void>.value();

  Group _groupFromMembership(GroupMembership r) => Group(
        id: r.groupId,
        name: r.name,
        joinCode: '',
        ownerId: '',
        members: const [],
        games: const [],
        chat: const [],
        polls: const [],
        notifications: const [],
        icon: r.icon,
        pinned: r.pinned,
      );

  // ── Notification outbox mirror (free-plan fan-out) ─────────────────────────
  final Map<String, StreamSubscription<List<OutboxNotification>>>
      _groupOutboxSubs = {};
  final Set<String> _mirroredOutboxIds = <String>{};
  final Map<String, bool> _outboxPrimed = {};
  final Map<String, int> _mirrorCursors = {};

  /// Subscribes each group's notification outbox and mirrors unseen items into
  /// the signed-in user's own inbox — the free-plan replacement for a Cloud
  /// Function. Cancels subs for groups that were left.
  void _syncGroupOutboxSubs() {
    final wanted = {for (final g in _groups) g.id};
    for (final gid in [
      for (final k in _groupOutboxSubs.keys)
        if (!wanted.contains(k)) k,
    ]) {
      _groupOutboxSubs.remove(gid)?.cancel();
      _outboxPrimed.remove(gid);
    }
    for (final g in _groups) {
      if (_groupOutboxSubs.containsKey(g.id)) continue;
      final gid = g.id;
      _mirrorCursors[gid] ??= -1;
      _groupOutboxSubs[gid] = _repo.groupOutboxStream(gid).listen(
        (docs) => _mirrorOutbox(gid, docs),
        onError: (Object e) => debugPrint('outbox stream error: $e'),
      );
    }
  }

  /// Copies staged group notifications into the user's own inbox. First
  /// emission is baselined silently (history); afterwards only items newer
  /// than the persisted cursor are mirrored — as unread.
  void _mirrorOutbox(String gid, List<OutboxNotification> docs) {
    final uid = _repo.currentUid;
    if (uid == null || !_backendUp) return;
    final primed = _outboxPrimed[gid] ?? false;
    var cursor = _mirrorCursors[gid] ?? -1;

    if (!primed) {
      // First-ever view of this group's outbox on this device: baseline
      // silently so a brand-new user's inbox isn't flooded with the group's
      // back-history. The flag is persisted, so this ONLY happens once — on
      // later app starts the cursor is restored and anything staged while
      // the app was closed IS delivered.
      _outboxPrimed[gid] = true;
      _persistPref('notifMirrorPrimed_$gid', true);
      for (final d in docs) {
        cursor = max(cursor, d.updatedAtMillis);
        _mirroredOutboxIds.add(d.id);
      }
    } else {
      for (final d in docs) {
        if (_mirroredOutboxIds.contains(d.id)) continue;
        _mirroredOutboxIds.add(d.id);
        if (d.updatedAtMillis <= cursor) continue;
        cursor = max(cursor, d.updatedAtMillis);
        if (!d.isFor(uid)) continue;
        unawaited(_repo
            .mirrorInboxNotification(uid, d.toAppNotification(read: false))
            .catchError((Object e) => debugPrint('mirror inbox failed: $e')));
      }
    }

    if (cursor != (_mirrorCursors[gid] ?? -1)) {
      _mirrorCursors[gid] = cursor;
      // No dots in the key — saveUserPref writes via a Firestore dot-path.
      _persistPref('notifMirrorCursor_$gid', cursor);
    }
  }

  /// Keeps the index-derived group list's `members` populated live so member
  /// counts on the home screen / sidebar are real-time. Subscribes a members
  /// stream per group and cancels subs for groups that were left/removed.
  void _syncGroupMembersSubs() {
    final wanted = {for (final g in _groups) g.id};
    final stale = [
      for (final entry in _groupMembersSubs.entries)
        if (!wanted.contains(entry.key)) entry.key,
    ];
    for (final gid in stale) {
      _groupMembersSubs.remove(gid)?.cancel();
    }
    for (final g in _groups) {
      if (_groupMembersSubs.containsKey(g.id)) continue;
      _groupMembersSubs[g.id] =
          _repo.groupMembersStream(g.id).listen((members) {
        final i = _groups.indexWhere((x) => x.id == g.id);
        if (i == -1) return;
        _groups = [..._groups]..[i] = _groups[i].copyWith(members: members);
        notifyListeners();
      }, onError: (Object e) => debugPrint('group members stream error: $e'));
    }
  }

  /// A recovery snapshot is the ADMIN's crash-resume copy. On any other device
  /// it is stale local state that must never win over the server — and while
  /// [_restoredFromRecovery] is set it also blocks every remote adoption, which
  /// silently froze members on their own optimistic RSVP: the value survived a
  /// reload locally, never reached Firestore, and the next tap short-circuited
  /// on the "already selected" guard so nothing was ever written again.
  ///
  /// Called once the signed-in user's role is actually known.
  void _dropRecoveryIfNotAuthority() {
    if (!_restoredFromRecovery) return;
    // Role not resolved yet — decide later rather than throwing away a real
    // admin's in-progress tournament.
    if (_user == null || _currentGroup.id.isEmpty) return;
    if (isAdmin) return;
    debugPrint('recovery: dropping local snapshot (not the game authority)');
    _restoredFromRecovery = false;
    _recoveryTime = null;
    RecoveryService.clearGame();
  }

  Future<void> _loadRecovery() async {
    final recovered = await RecoveryService.loadGame();
    if (recovered != null) {
      _currentGame = recovered;
      _restoredFromRecovery = true;
      _recoveryTime = DateTime.now();
    }
    final cash = await RecoveryService.loadCashSession();
    if (cash != null && !cash.isCompleted) {
      _cashSession = cash;
    }
    final guest = await RecoveryService.loadGuestSession();
    if (guest != null) {
      _guestSession = guest;
    }
    notifyListeners();
  }

  /// True if the locally recovered game state differs from the "cloud" state.
  /// Compares multiple fields to detect real conflicts, not just audit count.
  bool get hasOfflineConflict {
    if (_currentGame == null || !_restoredFromRecovery) return false;
    final cloudGame = _currentGroup.games
        .where((g) => g.id == _currentGame!.id)
        .firstOrNull;
    if (cloudGame == null) return false;
    return _currentGame!.revision > cloudGame.revision ||
        _currentGame!.auditHistory.length > cloudGame.auditHistory.length;
  }

  void resolveOfflineConflict({required bool keepLocal}) {
    if (_currentGame != null) {
      if (keepLocal) {
        // Sync local up to cloud
        final games = _currentGroup.games.toList();
        final idx = games.indexWhere((g) => g.id == _currentGame!.id);
        if (idx != -1) {
          games[idx] = _currentGame!;
          _setGroup(_currentGroup.copyWith(games: games));
        }
        _lastSavedGame = null;
        _syncGameToCloud();
      } else {
        // Revert local down to cloud
        final cloudGame = _currentGroup.games
            .where((g) => g.id == _currentGame!.id)
            .firstOrNull;
        if (cloudGame != null) {
          _currentGame = cloudGame;
          RecoveryService.saveGame(cloudGame);
        }
      }
    }
    _restoredFromRecovery = false;
    notifyListeners();
  }

  /// Exposes the snapshot timestamp so the restore prompt can show
  /// "last saved HH:MM" (Tech spec §20.1).
  DateTime? get restoredAt => RecoveryService.lastSavedAt;

  /// Admin declined the restored snapshot — drop the local active game.
  void discardRestoredGame() {
    _currentGame = null;
    _restoredFromRecovery = false;
    RecoveryService.clearGame();
    _syncGroupGame();
    notifyListeners();
  }

  // ── Auth ───────────────────────────────────────────────────────────────────
  AppUser? _user;
  AppUser? get user => _user;

  bool get isAuthenticated => _user != null;

  /// True while the signed-in account is an anonymous (guest) session.
  bool get isGuest => _repo.isSignedInAsGuest;

  Future<void> _onAuthStateChanged(fa.User? fbUser) async {
    if (fbUser == null) {
      // Nothing to hydrate for a signed-out user — release the router now.
      _authReady = true;
      _teardownUserData();
      if (_user != null) {
        _user = null;
        notifyListeners();
      }
      return;
    }
    // Keep the router gated at splash until the restored session is actually
    // usable (profile + streams). Flipping `_authReady` before this made the
    // guard see `ready=true, authed=false` during hydration and bounce a
    // signed-in user to the login page until a rebuild happened (the "tap a
    // field / login button and it logs me in" bug).
    await _hydrateUser(fbUser);
    _authReady = true;
    _calibrateServerTime();
    // Re-run the router guard now that both `ready` and `authed` are settled.
    notifyListeners();
  }

  /// Runs [op], retrying on any failure with a short back-off. Right after
  /// sign-in on web the first Firestore calls can fail with permission-denied
  /// until the fresh auth token propagates into the Firestore SDK; retrying a
  /// few times bridges that window so the UI doesn't need a page refresh.
  Future<T?> _retryRead<T>(Future<T> Function() op, {int tries = 6}) async {
    for (var attempt = 0; attempt < tries; attempt++) {
      try {
        return await op();
      } catch (e) {
        if (attempt == tries - 1) {
          debugPrint('hydration read failed after $tries attempts: $e');
          return null;
        }
        await Future<void>.delayed(Duration(milliseconds: 200 + attempt * 250));
      }
    }
    return null;
  }

  /// Forces a fresh ID token into the SDK. Called from stream/write retry
  /// paths after a `permission-denied` — on web the token can lag the auth
  /// state by a few seconds after login, and this pushes a live one through.
  Future<void> _nudgeAuthToken() async {
    try {
      await _repo.currentUser?.getIdToken(true);
    } catch (_) {}
  }

  /// True when [e] looks like the post-login token-propagation denial that a
  /// retry (with a token nudge) can clear, vs a permanent rules rejection.
  bool _isRetriablePermissionError(Object e) =>
      e.toString().contains('permission-denied') ||
      e.toString().contains('PERMISSION_DENIED') ||
      e.toString().contains('unauthenticated');

  Future<void>? _hydrating;

  /// Loads (creating on first sign-in) the Firestore profile for [fbUser] and
  /// mirrors it into [_user], then subscribes the user-scoped live streams.
  /// Called from the auth-state listener and directly after login/register;
  /// concurrent calls for the same session are coalesced.
  Future<void> _hydrateUser(fa.User fbUser) {
    final inFlight = _hydrating;
    if (inFlight != null) return inFlight;
    final run = _doHydrateUser(fbUser).whenComplete(() => _hydrating = null);
    _hydrating = run;
    return run;
  }

  Future<void> _doHydrateUser(fa.User fbUser) async {
    try {
      // Force a network token refresh so the Firestore SDK is handed a live
      // credential before the first read. A plain getIdToken() can return a
      // stale/empty token right after sign-in on web, which is what made every
      // isMember-gated read fail with permission-denied until a page reload.
      try {
        await fbUser.getIdToken(true);
      } catch (_) {
        try {
          await fbUser.getIdToken();
        } catch (_) {}
      }

      await _retryRead(() => _repo.ensureUserDoc(
            uid: fbUser.uid,
            name: fbUser.displayName ?? 'Player',
            email: fbUser.email ?? '',
            starterPresets: seedPresets,
            starterChipSet: seedChipSet,
          ));
      final loaded = await _retryRead(() => _repo.loadUser(fbUser.uid));
      _user = loaded ??
          _user ?? // never downgrade an already-hydrated profile
          AppUser(
            id: fbUser.uid,
            name: fbUser.displayName ?? 'Player',
            email: fbUser.email ?? '',
            isAdmin: false,
            stats: const UserStats(
              played: 0,
              wins: 0,
              podium: 0,
              avgFinish: 0,
              knockouts: 0,
            ),
          );
      notifyListeners();
      await _loadUserPrefs(fbUser.uid);
      // Subscribe only now — after the retried reads confirm the token works —
      // so the .snapshots() streams don't immediately error out (a Firestore
      // stream that hits permission-denied is dead until re-created).
      _subscribeUserData();
    } catch (e) {
      debugPrint('AppProvider: profile hydration failed: $e');
    }
  }

  /// Restores per-user preferences (`users/{uid}.prefs`) onto local state.
  Future<void> _loadUserPrefs(String uid) async {
    if (!_backendUp) return;
    try {
      final prefs = await _repo.loadUserPrefs(uid);
      final voice = prefs['voiceEnabled'];
      if (voice is bool) _voiceEnabled = voice;
      final notify = prefs['browserNotify'];
      if (notify is bool) {
        _notificationsEnabled = notify;
      } else {
        // By default turn on if no preference is set
        _notificationsEnabled = true;
        _persistPref('browserNotify', true);
        // Fire-and-forget the permission request so it prompts the user automatically
        Future.microtask(() => setNotificationsEnabled(true));
      }
      final colorTheme = prefs['colorTheme'];
      if (colorTheme is String) _colorTheme = colorTheme;
      final themePref = prefs['themePreference'];
      if (themePref is String) _themePreference = themePref;
      // Restore per-group notification-mirror cursors so history isn't
      // re-mirrored on every sign-in.
      for (final entry in prefs.entries) {
        if (entry.key.startsWith('notifMirrorCursor_')) {
          final gid = entry.key.substring('notifMirrorCursor_'.length);
          final v = entry.value;
          if (v is num) _mirrorCursors[gid] = v.toInt();
        } else if (entry.key.startsWith('notifMirrorPrimed_')) {
          final gid = entry.key.substring('notifMirrorPrimed_'.length);
          final v = entry.value;
          if (v is bool) _outboxPrimed[gid] = v;
        }
      }
      notifyListeners();
    } catch (e) {
      debugPrint('loadUserPrefs failed: $e');
    }
  }

  /// Fire-and-forget write of a single preference key.
  void _persistPref(String key, Object? value) {
    if (key == 'colorTheme' || key == 'themePreference') {
      try {
        final db = Localstore.instance;
        db.collection('app').doc('prefs').set({key: value}, SetOptions(merge: true));
      } catch (e) {
        debugPrint('Failed to save theme to localstore: $e');
      }
    }
    
    final uid = _repo.currentUid;
    if (!_backendUp || uid == null) return;
    unawaited(_repo
        .saveUserPref(uid, key, value)
        .catchError((Object e) => debugPrint('saveUserPref($key) failed: $e')));
  }

  /// Returns `null` on success or a friendly error message for the UI.
  Future<String?> login(String email, String password) async {
    try {
      final cred = await _repo.signIn(email, password);
      if (cred.user != null) await _hydrateUser(cred.user!);
      // Wait (bounded) for groups + the auto-selected group's bundle so the
      // dashboard is populated the moment we navigate to it.
      await userDataReady.timeout(const Duration(seconds: 8), onTimeout: () {});
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'invalid-credential' ||
        'wrong-password' ||
        'user-not-found' =>
          'Incorrect email or password.',
        'invalid-email' => 'Enter a valid email address.',
        'user-disabled' => 'This account has been disabled.',
        'too-many-requests' => 'Too many attempts. Please try again later.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Sign-in failed. Please try again.',
      };
    }
  }

  /// Returns `null` on success or a friendly error message for the UI.
  Future<String?> register(String name, String email, String password) async {
    try {
      final cred = await _repo.signUp(
        name: name,
        email: email,
        password: password,
      );
      if (cred.user != null) {
        await _hydrateUser(cred.user!);
        // Guarantee the chosen name is stored even if displayName propagation
        // lagged during hydration's ensureUserDoc.
        if (_user != null && _user!.name != name) {
          await _retryRead(
              () => _repo.updateUserProfile(cred.user!.uid, name: name));
          _user = _user!.copyWith(name: name);
          notifyListeners();
        }
      }
      await userDataReady.timeout(const Duration(seconds: 8), onTimeout: () {});
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'email-already-in-use' => 'An account already exists for that email.',
        'weak-password' => 'That password is too weak — use at least 8 characters.',
        'invalid-email' => 'Enter a valid email address.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Registration failed. Please try again.',
      };
    }
  }

  /// Converts the current anonymous guest session into a full account by
  /// linking credentials onto the existing uid, so stats/results recorded as
  /// a guest carry over automatically (user-flow spec §6.7). Returns `null`
  /// on success or a friendly error message for the UI.
  Future<String?> convertGuestAccount(
      String name, String email, String password) async {
    if (!_repo.isSignedInAsGuest) return 'Not a guest session.';
    try {
      final cred = await _repo.linkGuestAccount(
        name: name,
        email: email,
        password: password,
      );
      if (cred.user != null) await _hydrateUser(cred.user!);
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'email-already-in-use' ||
        'credential-already-in-use' =>
          'An account already exists for that email.',
        'weak-password' =>
          'That password is too weak — use at least 8 characters.',
        'invalid-email' => 'Enter a valid email address.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Account creation failed. Please try again.',
      };
    } on StateError {
      return 'Your session expired. Please sign in again.';
    }
  }

  /// Sends the reset email; returns `null` on success or a friendly error.
  Future<String?> requestPasswordReset(String email) async {
    try {
      await _repo.sendPasswordReset(email);
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'user-not-found' || 'invalid-credential' =>
          'No account found for that email.',
        'invalid-email' => 'Enter a valid email address.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Could not send the reset email. Please try again.',
      };
    }
  }

  /// Signs in anonymously — the entry point of the guest flow.
  Future<String?> signInAsGuest() async {
    try {
      final cred = await _repo.signInAsGuest();
      if (cred.user != null) await _hydrateUser(cred.user!);
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return e.message ?? 'Guest sign-in failed. Please try again.';
    }
  }

  /// Triggers Google Sign-In and authenticates with Firebase. Returns `null`
  /// on success, an empty string when the user cancels (caller should no-op),
  /// or a friendly error message on failure.
  Future<String?> loginWithGoogle() async {
    try {
      final cred = await _repo.signInWithGoogle();
      if (cred == null) return ''; // user cancelled — silent abort
      if (cred.user != null) await _hydrateUser(cred.user!);
      await userDataReady.timeout(const Duration(seconds: 8), onTimeout: () {});
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'account-exists-with-different-credential' =>
          'An account already exists with this email using a different sign-in method.',
        'invalid-credential' => 'Google sign-in failed. Please try again.',
        'user-disabled' => 'This account has been disabled.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Google sign-in failed. Please try again.',
      };
    } catch (e) {
      return 'Google sign-in failed. Please try again.';
    }
  }

  /// Upgrades the current anonymous guest session to a Google-linked account.
  /// Returns `null` on success, empty string on cancel, or an error message.
  Future<String?> convertGuestWithGoogle() async {
    if (!_repo.isSignedInAsGuest) return 'Not a guest session.';
    try {
      final cred = await _repo.linkGuestWithGoogle();
      if (cred == null) return ''; // user cancelled
      if (cred.user != null) await _hydrateUser(cred.user!);
      return null;
    } on fa.FirebaseAuthException catch (e) {
      return switch (e.code) {
        'credential-already-in-use' ||
        'email-already-in-use' =>
          'A Google account already exists for this email.',
        'network-request-failed' => 'Network error. Check your connection.',
        _ => e.message ?? 'Google sign-in failed. Please try again.',
      };
    } on StateError {
      return 'Your session expired. Please sign in again.';
    } catch (e) {
      return 'Google sign-in failed. Please try again.';
    }
  }

  Future<void> logout() async {
    // OneSignal external-id detach happens automatically via the auth-state
    // listener in PushService — no stale subscriptions linger on the account.
    await _repo.signOut();
  }

  // ── Chip Sets ──────────────────────────────────────────────────────────────
  /// Starter chip set seeded into new Firestore accounts (doc id `cs-default`
  /// keeps the "protected default" semantics of deleteChipSet).
  static const seedChipSet = (
    id: 'cs-default',
    name: 'Home Set (4 colour)',
    chips: MockData.defaultChipSet,
  );

  final List<({String id, String name, List<ChipColor> chips})> _savedChipSets =
      [seedChipSet];

  List<({String id, String name, List<ChipColor> chips})> get savedChipSets =>
      _savedChipSets;

  void saveChipSet(String id, String name, List<ChipColor> chips) {
    final idx = _savedChipSets.indexWhere((c) => c.id == id);
    if (idx >= 0) {
      _savedChipSets[idx] = (id: id, name: name, chips: chips);
    } else {
      _savedChipSets.add((id: id, name: name, chips: chips));
    }
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null && id != seedChipSet.id) {
      unawaited(_repo.saveChipSet(uid, id, name, chips)
          .catchError((Object e) => debugPrint('saveChipSet failed: $e')));
    }
  }

  void deleteChipSet(String id) {
    if (id == 'cs-default') return; // protect default
    _savedChipSets.removeWhere((c) => c.id == id);
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.deleteChipSet(uid, id)
          .catchError((Object e) => debugPrint('deleteChipSet failed: $e')));
    }
  }

  /// Updates the signed-in member's display details (profile screen) and
  /// persists them to the Firestore profile.
  void updateProfile({String? name, String? email}) {
    final current = _user;
    if (current == null) return;
    final nextName =
        name?.trim().isNotEmpty == true ? name!.trim() : current.name;
    final nextEmail =
        email?.trim().isNotEmpty == true ? email!.trim() : current.email;
    _user = current.copyWith(name: nextName, email: nextEmail);
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.updateUserProfile(uid, name: nextName, email: nextEmail)
          .catchError((Object e) => debugPrint('updateUserProfile failed: $e')));
    }
  }

  // ── Tournament Presets (checklist §9.1) ──────────────────────────────────
  /// Starter presets seeded into new Firestore accounts so the create-
  /// tournament wizard works out of the box.
  static final List<TournamentPreset> seedPresets = [
    TournamentPreset(
      id: 'pr-friday',
      name: 'Friday Night Regular',
      buyIn: 15,
      koEnabled: false,
      koAmount: 5,
      rebuys: true,
      rebuysCloseLevel: 6,
      reEntry: true,
      addOn: true,
      durationHours: 3.5,
      anteEnabled: true,
      anteAfterLevel: 6,
      organizerPct: 10,
      chipSetName: 'Home Set (4 colour)',
      chipSet: List.of(MockData.defaultChipSet),
    ),
    TournamentPreset(
      id: 'pr-deep',
      name: 'Deep Stack Turbo',
      buyIn: 25,
      koEnabled: true,
      koAmount: 10,
      rebuys: false,
      rebuysCloseLevel: 5,
      reEntry: false,
      addOn: false,
      durationHours: 5,
      anteEnabled: true,
      anteAfterLevel: 5,
      organizerPct: 0,
      chipSetName: 'Standard 500',
      chipSet: List.of(TournamentEngine.getPreset('Standard 500')),
    ),
  ];

  final List<TournamentPreset> _presets = List.of(seedPresets);

  List<TournamentPreset> get presets => List.unmodifiable(_presets);

  TournamentPreset? presetById(String? id) {
    if (id == null) return null;
    for (final p in _presets) {
      if (p.id == id) return p;
    }
    return null;
  }

  void savePreset(TournamentPreset preset) {
    final idx = _presets.indexWhere((p) => p.id == preset.id);
    if (idx >= 0) {
      _presets[idx] = preset;
    } else {
      _presets.add(preset);
    }
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.savePreset(uid, preset)
          .catchError((Object e) => debugPrint('savePreset failed: $e')));
    }
  }

  void deletePreset(String id) {
    _presets.removeWhere((p) => p.id == id);
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.deletePreset(uid, id)
          .catchError((Object e) => debugPrint('deletePreset failed: $e')));
    }
  }

  /// Suggests up to two presets that match the signals parsed from closed
  /// polls (e.g. "What buy-in?" → 15, "How long?" → 3.5h). Used by the
  /// create-tournament wizard (09-007 / 09-008 / 09-009).
  List<TournamentPreset> suggestPresets({
    required int expectedPlayers,
    List<num> pollSignals = const [],
  }) {
    if (_presets.isEmpty) return const [];

    int scoreFor(TournamentPreset p) {
      var score = 0;
      for (final s in pollSignals) {
        if (s == p.buyIn) score += 40;
        if (s == p.durationHours) score += 30;
        if ((s - p.buyIn).abs() <= 2 && s != p.buyIn) score += 10;
      }
      if (expectedPlayers >= 2 && expectedPlayers <= 10 && p.rebuys) score += 5;
      if (expectedPlayers > 10 && !p.rebuys) score += 5;
      return score;
    }

    final scored =
        _presets
            .map((p) => (preset: p, score: scoreFor(p)))
            .where((e) => e.score >= 15)
            .toList()
          ..sort((a, b) => b.score.compareTo(a.score));

    return scored.take(2).map((e) => e.preset).toList();
  }

  // ── Group ──────────────────────────────────────────────────────────────────
  /// Neutral placeholder until the first group of the signed-in user is
  /// auto-selected (or the user creates/joins one).
  Group _currentGroup = _kEmptyGroup;
  Group get currentGroup => _currentGroup;

  /// Id of the selected group — set the instant a group is chosen, even before
  /// its live bundle has loaded (unlike `currentGroup.id`, which lags).
  String? get currentGroupId => _currentGroupId;

  /// True once a real group bundle is subscribed (id is non-empty).
  bool get hasCurrentGroup => _currentGroupId != null;

  /// The group whose live bundle is currently subscribed.
  String? _currentGroupId;

  /// Every group the user belongs to, rebuilt from the live index stream.
  /// Rows are lightweight (no members/chat/games) — the rich state lives in
  /// [currentGroup] via the bundle subscription.
  List<Group> _groups = const [];
  List<Group> get groups => List.unmodifiable(_groups);

  /// Groups ordered pinned-first then alphabetically (client feedback: the
  /// sidebar lists all groups, pinnable, not a single slot).
  List<Group> get orderedGroups {
    final sorted = [..._groups]
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    sorted.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
    return sorted;
  }

  /// Replaces [currentGroup] everywhere it lives so the sidebar list and the
  /// group hub always reflect the same state.
  void _setGroup(Group group) {
    _currentGroup = group;
    final i = _groups.indexWhere((g) => g.id == group.id);
    _groups = i == -1 ? [..._groups, group] : ([..._groups]..[i] = group);
  }

  /// Selects the group hub target and subscribes its live Firestore bundle.
  void setCurrentGroup(Group group) => _selectGroup(group.id);

  /// Joins a group by its invite code. Returns false when the code is
  /// unknown or the request failed.
  Future<bool> joinGroup(String code) async {
    final user = _user;
    if (!_backendUp || user == null) return false;
    try {
      final gid = await _repo.joinByCode(code, user);
      if (gid == null) return false;
      _subscribeUserData(); // refresh the index with the new row promptly
      _selectGroup(gid);
      notifyListeners();
      // Wait for the group's live bundle (members, games, chat, polls,
      // settings) so the caller navigates into a fully-populated hub that then
      // keeps updating in real time — not an empty shell.
      await groupReady.timeout(const Duration(seconds: 10), onTimeout: () {});
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('joinGroup failed: $e');
      return false;
    }
  }

  /// Creates a new group with this account as owner. Returns null when the
  /// caller is unauthenticated or the write failed.
  Future<Group?> createGroup(String name, {String icon = '♠️'}) async {
    final user = _user;
    if (!_backendUp || user == null) return null;
    final group = Group(
      id: 'grp-${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      joinCode: Formatters.generateCode(),
      ownerId: user.id,
      members: [user],
      games: const [],
      chat: const [],
      polls: const [],
      notifications: const [],
      icon: icon,
    );
    try {
      await _repo.createGroup(group, user);
    } catch (e) {
      debugPrint('createGroup failed: $e');
      return null;
    }
    _subscribeUserData();
    _selectGroup(group.id);
    notifyListeners();
    return group;
  }

  /// Pins/unpins a group so it floats to the top of the sidebar's group list.
  void togglePinGroup(Group group) {
    _setGroup(group.copyWith(pinned: !group.pinned));
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo
          .updateGroupIndex(uid, group.id, pinned: !group.pinned)
          .catchError((Object e) =>
              debugPrint('updateGroupIndex(pinned) failed: $e')));
    }
  }

  /// Owner-only: sets a member's role (Member / Co-Admin / Admin). Co-Admin
  /// can add members directly and grant rebuys; only Admin (or the owner)
  /// can advance the tournament or touch blinds/seating settings.
  void setGroupRole(String userId, GroupRole role) {
    if (_user?.id != _currentGroup.ownerId) return; // Only owner can do this
    if (userId == _currentGroup.ownerId) return; // Cannot change owner's role
    final members = _currentGroup.members.map((m) {
      if (m.id != userId) return m;
      return m.copyWith(
        isAdmin: role == GroupRole.admin,
        isCoAdmin: role == GroupRole.coAdmin,
      );
    }).toList();
    _setGroup(_currentGroup.copyWith(members: members));
    notifyListeners();
    if (_backendUp) {
      unawaited(_repo
          .setMemberRole(_currentGroup.id, userId, role.storageValue)
          .catchError(
              (Object e) => debugPrint('setMemberRole failed: $e')));
    }
  }

  /// Host/Admin or Co-Admin: adds a registered user directly to the group by
  /// email, without going through an invite link/QR/join code. Returns null
  /// on success, or a friendly error message for the UI.
  Future<String?> addMemberByEmail(String email) async {
    if (!canManageMembers) return 'Only the Host can add members.';
    if (!_backendUp) return 'You are offline.';
    final trimmed = email.trim();
    if (trimmed.isEmpty) return 'Enter an email address.';
    AppUser? found;
    try {
      found = await _repo.findUserByEmail(trimmed);
    } catch (e) {
      debugPrint('findUserByEmail failed: $e');
      return 'Could not look up that email. Please try again.';
    }
    if (found == null) {
      return 'No account found for that email. Ask them to sign up '
          '(or open the app once) first, then try again.';
    }
    if (found.id == _user?.id) {
      return "You're already in this group.";
    }
    if (_currentGroup.members.any((m) => m.id == found!.id)) {
      return '${found.name.isEmpty ? 'That user' : found.name} is already in this group.';
    }
    try {
      await _repo.addMemberToGroup(
        _currentGroup.id,
        found,
        groupName: _currentGroup.name,
        groupIcon: _currentGroup.icon,
      );
    } catch (e) {
      debugPrint('addMemberByEmail failed: $e');
      return 'Could not add that member. Please try again.';
    }
    return null;
  }

  /// Owner-only: updates the group's default table-capacity/randomization
  /// settings. Individual tournaments may still override this
  /// ([updateTournamentTableSettings]).
  void updateGroupTableSettings(TableSettings settings) {
    if (_user?.id != _currentGroup.ownerId) return;
    _setGroup(_currentGroup.copyWith(tableSettings: settings));
    notifyListeners();
    if (_backendUp) {
      unawaited(_repo
          .updateGroupTableSettings(_currentGroup.id, settings)
          .catchError((Object e) =>
              debugPrint('updateGroupTableSettings failed: $e')));
    }
  }

  /// The table-capacity/randomization rules that actually apply to the
  /// active tournament: its own override if set, otherwise the group
  /// default.
  TableSettings get effectiveTableSettings =>
      _currentGame?.settings.tableSettingsOverride ??
      _currentGroup.tableSettings;

  /// Admin-only: sets (or clears, passing null) this tournament's override of
  /// the group's default table settings.
  void updateTournamentTableSettings(TableSettings? override) {
    final game = _currentGame;
    if (game == null || !isAdmin) return;
    _currentGame = game.copyWith(
      settings: game.settings.copyWith(
        tableSettingsOverride: override,
        clearTableSettingsOverride: override == null,
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  /// Owner-only: removes a member from the current group.
  void removeMember(String userId) {
    if (_user?.id != _currentGroup.ownerId) return;
    if (userId == _currentGroup.ownerId) return;
    final members =
        _currentGroup.members.where((m) => m.id != userId).toList();
    _setGroup(_currentGroup.copyWith(members: members));
    notifyListeners();
    if (_backendUp) {
      unawaited(_repo
          .deleteMember(_currentGroup.id, userId)
          .catchError(
              (Object e) => debugPrint('deleteMember failed: $e')));
    }
  }

  /// Transfers ownership of the current group to another member.
  /// Only callable by the current owner. Safe no-op for non-owners.
  Future<void> transferGroupOwnership(String newOwnerId) async {
    final userId = _user?.id;
    final gid = _currentGroup.id;
    if (userId == null || userId != _currentGroup.ownerId) return;
    if (newOwnerId == userId || newOwnerId.isEmpty) return;
    final newOwner = _currentGroup.members
        .where((m) => m.id == newOwnerId)
        .firstOrNull;
    if (newOwner == null) return;
    if (_backendUp) {
      await _repo
          .transferGroupOwnership(gid, userId, newOwnerId, newOwner.name)
          .catchError(
            (Object e) => debugPrint('transferOwnership failed: $e'),
          );
    }
  }

  /// Non-owner members may leave a group voluntarily.
  void leaveGroup() {
    final userId = _user?.id;
    if (userId == null || userId == _currentGroup.ownerId) return;
    final leftGid = _currentGroup.id;
    if (_backendUp && leftGid.isNotEmpty) {
      unawaited(_repo
          .deleteMember(leftGid, userId)
          .catchError(
              (Object e) => debugPrint('leaveGroup deleteMember failed: $e')));
    }
    // Drop the left group locally and switch the hub to another group (or an
    // empty state) straight away, tearing down its now-inaccessible bundle.
    _bundleSub?.cancel();
    _bundleSub = null;
    _cashSub?.cancel();
    _cashSub = null;
    _currentGroupId = null;
    _bundleLoaded = false;
    _bundleReady = null;
    _groups = _groups.where((g) => g.id != leftGid).toList();
    final next = orderedGroups.firstOrNull;
    if (next != null) {
      _selectGroup(next.id);
    } else {
      _currentGroup = _kEmptyGroup;
    }
    notifyListeners();
  }

  // ── Game ───────────────────────────────────────────────────────────────────
  LiveGame? _currentGame;
  LiveGame? get currentGame => _currentGame;

  // Undo stack (checklist 12-042/12-043/12-044, technical §11.3). Before every
  // admin mutation we snapshot the previous game; undo pops and restores it.
  static const int _maxUndoDepth = 30;
  final List<LiveGame?> _undoStack = [];

  /// An editor claim older than this is considered stale: any admin device may
  /// take over the single-writer role (90 seconds of silence).
  static const Duration _editorClaimStaleWindow = Duration(seconds: 90);

  bool get canUndo => _undoStack.isNotEmpty;

  /// Human-readable description of the most recent reversible action, used
  /// by the Undo confirmation ("Undo shows the action that will be reversed"
  /// — User Flow spec §12.6).
  String? get lastActionSummary {
    final history = _currentGame?.auditHistory;
    if (history == null || history.isEmpty) return null;
    return history.last.details;
  }

  /// Pending seat-balance recommendation (checklist §13.2), if any.
  SeatMoveRecommendation? _pendingSeatMove;

  void _pushUndo() {
    if (_currentGame == null) return;
    if (_undoStack.length >= _maxUndoDepth) _undoStack.removeAt(0);
    _undoStack.add(_currentGame);
    _saveUndoStack();
  }

  /// Idempotency guard (technical §18.1): claims the next revision for an
  /// administrator action carrying [idempotencyKey]. Returns the new revision
  /// to persist, or null when the key was already applied — a replayed action
  /// (browser retry, offline-restore redelivery) must never be applied twice.
  ///
  /// Callers fold the returned revision (and the key) into their final
  /// [LiveGame.copyWith] so the guard survives save, restore and fan-out.
  /// Claims the next revision for an admin mutation, rejecting a replayed
  /// action: if [idempotencyKey] matches the key that produced the current
  /// revision, the call is a duplicate and returns null. When the caller does
  /// not supply a key, one is derived deterministically from the action's own
  /// identity (`action-target-revision+1`) instead of bypassing replay
  /// protection entirely. Returns the new revision and the persistence key
  /// (the caller stores the latter as `lastIdempotencyKey`).
  (int?, String) _claimIdempotency(String idempotencyKey,
      {required String action, String target = ''}) {
    final g = _currentGame;
    if (g == null) return (null, '');
    final key = idempotencyKey.isNotEmpty
        ? idempotencyKey
        : '$action-${target.isEmpty ? g.id : target}-${g.revision + 1}';
    if (g.lastIdempotencyKey == key) return (null, key); // replay
    return (g.revision + 1, key);
  }

  void _clearUndoStack() {
    _undoStack.clear();
  }

  void _saveUndoStack() {
    final game = _currentGame;
    if (game == null) return;
    final stack = _undoStack.whereType<LiveGame>().toList();
    _repo.saveUndoStack(game.groupId, game.id, stack).catchError((Object e) {
      debugPrint('saveUndoStack failed: $e');
    });
  }

  void setCurrentGame(LiveGame game) {
    _clearUndoStack();
    // Re-apply the member's not-yet-acked RSVP / check-in so navigating into a
    // game never shows a stale bundle copy that drops a pending selection.
    _currentGame = _withPendingCheckInOverlay(_withOwnRsvpOverlay(game));
    notifyListeners();

    // Asynchronously load private sidecar data and undo stack if admin
    if (isAdmin) {
      _repo.loadPrivateGameData(game.groupId, game.id).then((privateData) {
        if (_currentGame?.id == game.id && privateData != null) {
          _currentGame = _currentGame!.copyWith(
            settings: _currentGame!.settings.copyWith(
              organizerPct: (privateData['organizerPct'] as num?)?.toInt() ?? _currentGame!.settings.organizerPct,
            ),
            players: _restorePrivatePlayerFinancials(
              _currentGame!.players,
              privateData['players'],
            ),
            structure: _currentGame!.structure?.copyWith(
              prizes: privateData['prizes'] != null ? (privateData['prizes'] as List).map((e) => Prize(place: e['place'], amount: e['amount'])).toList() : _currentGame!.structure!.prizes,
              organizerAmount: (privateData['organizerAmount'] as num?)?.toInt() ?? _currentGame!.structure!.organizerAmount,
            ) ?? _currentGame!.structure,
          );
          notifyListeners();
        }
      }).catchError((Object e) {
        debugPrint('Failed to load private sidecar: $e');
      });

      if (game.status.isActiveLive) {
        _repo.loadUndoStack(game.groupId, game.id).then((stack) {
          if (_currentGame?.id == game.id) {
            _undoStack.clear();
            _undoStack.addAll(stack);
            notifyListeners();
          }
        }).catchError((Object e) {
          debugPrint('Failed to load undo stack: $e');
        });
      }
    }
  }

  /// Merges per-player financial fields (rebuys / reEntries / hasAddOn /
  /// knockouts) back from the admin-only private sidecar, so an admin reload
  /// keeps the true figures even though the public game doc carries them
  /// scrubbed for non-authority readers (User Flow §2.3/§5.6).
  List<Player> _restorePrivatePlayerFinancials(
      List<Player> current, Object? raw) {
    if (raw is! List) return current;
    final saved = <String, Player>{};
    for (final e in raw) {
      if (e is! Map) continue;
      try {
        final p = playerFromMap(Map<String, dynamic>.from(e));
        saved[p.id] = p;
      } catch (_) {}
    }
    if (saved.isEmpty) return current;
    return current.map((p) {
      final r = saved[p.id];
      if (r == null) return p;
      return p.copyWith(
        rebuys: r.rebuys,
        reEntries: r.reEntries,
        hasAddOn: r.hasAddOn,
        knockouts: r.knockouts,
      );
    }).toList();
  }

  /// Resolves a game (live or past) by id from the group's synced list,
  /// falling back to the current active game (checklist 16-007).
  LiveGame? gameById(String id) {
    for (final g in _currentGroup.games) {
      if (g.id == id) return g;
    }
    return _currentGame?.id == id ? _currentGame : null;
  }

  LiveGame createGame(GameSettings settings) {
    // Client flow: creating an event does NOT generate the structure. The AI
    // finalises stacks/blinds/levels when the Admin taps "Generate Final
    // Structure" during check-in, using confirmed attendance.
    // Until then the structure stays empty.
    final structure = const TournamentStructure(
      startingStack: 0,
      chipPlan: [],
      rebuyStack: 0,
      rebuyChipPlan: [],
      addOnStack: 0,
      addOnChipPlan: [],
      levels: [],
      levelDuration: 15,
      expectedFinishMins: 0,
      prizes: [],
      prizePool: 0,
      organizerAmount: 0,
      colorUpInstructions: [],
      warnings: [],
    );
    // Seed participants from the group roster so the RSVP and check-in
    // screens list the real members. Guest seats appear as guest slots when
    // members answer Going +N — no placeholder players are invented.
    final seeded = [
      for (final member in _currentGroup.members)
        Player(
          id: member.id,
          name: member.name,
          isGuest: false,
          rsvp: null,
          checkedIn: false,
          confirmed: false,
          eliminated: false,
          rebuys: 0,
          hasAddOn: false,
          knockouts: 0,
          table: 0,
          seat: 0,
          active: true,
        ),
    ];
    final game = LiveGame(
      id: 'game-${DateTime.now().millisecondsSinceEpoch}',
      groupId: _currentGroup.id,
      settings: settings,
      structure: structure,
      status: LiveGameStatus.draft,
      publicCode: Formatters.generateCode(),
      tvCode: Formatters.generateCode(),
      currentLevel: 1,
      timerRunning: false,
      secondsRemaining: structure.levelDuration * 60,
      players: seeded,
      chat: const [],
      announcements: const [],
      totalChipsInPlay: structure.startingStack * seeded.length,
      pendingGuests: const [],
      finishOrder: const [],
      speedRecommendation: null,
    );
    _clearUndoStack();
    _currentGame = game;
    _syncGroupGame();
    notifyListeners();
    return game;
  }

  /// Keeps the group's copy of the current game in sync so the hub's upcoming
  /// list and history (12-090) reflect the live game's latest status. When the
  /// game does not exist yet on the group it is appended.
  void _syncGroupGame() {
    final game = _currentGame;
    if (game == null) return;
    _lastGameUpdate = DateTime.now();
    final games = _currentGroup.games;
    final idx = games.indexWhere((g) => g.id == game.id);
    _setGroup(
      _currentGroup.copyWith(
        games: idx == -1 ? [...games, game] : ([...games]..[idx] = game),
      ),
    );
  }

  void updateGameStatus(LiveGameStatus status) {
    final wasPublished = _currentGame?.status == LiveGameStatus.published;
    _currentGame = _currentGame!.copyWith(status: status);
    // Client feedback (07-018): inside the 30-minute window before start the
    // AI refreshes the stacks/blinds/levels estimate from the expected count.
    if (status == LiveGameStatus.checkin) generateFinalStructure(currentGame!.confirmedCount);
    if (status == LiveGameStatus.checkin && wasPublished) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Check-in opened',
          body:
              '${_currentGame!.settings.name} — you can check in now. Seats are assigned after the host confirms.',
          type: NotificationType.game,
          link: '/invitation',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
    _syncGroupGame();
    notifyListeners();
  }

  /// Cancels the tournament. Requires a reason: it is recorded in the audit
  /// log and members are notified (spec §12, checklist 10-042). Blocking —
  /// once cancelled the game cannot be started again.
  void cancelGame(String reason) {
    final game = _currentGame;
    if (game == null || _user == null) return;
    if (game.status == LiveGameStatus.completed ||
        game.status == LiveGameStatus.cancelled) {
      return;
    }
    _pushUndo();
    _ticker?.cancel();
    _currentGame = game.copyWith(
      status: LiveGameStatus.cancelled,
      timerRunning: false,
    );
    _syncGroupGame();
    addAuditRecord(
      'cancel',
      'Cancelled ${game.settings.name}. Reason: ${reason.trim().isEmpty ? 'Not provided' : reason.trim()}',
    );
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Tournament cancelled',
        body: '${game.settings.name} has been cancelled.',
        type: NotificationType.game,
        link: '/invitation',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    addAnnouncement('${game.settings.name} has been cancelled.', true);
    notifyListeners();
  }

  /// Publishes the tournament (checklist §4.3): the game opens for RSVP, a
  /// pinned event card is posted to the group chat, every member is notified,
  /// and the published structure is snapshotted for the §12.4 live diff.
  void publishGame() {
    final game = _currentGame;
    if (game == null || _user == null) return;
    _pushUndo();

    final anteText = game.settings.anteEnabled
        ? 'Ante: L${game.settings.anteAfterLevel}+'
        : 'No ante';
    final rebuyText = game.settings.rebuysCloseLevel > 0
        ? 'Rebuys: until L${game.settings.rebuysCloseLevel}'
        : 'No rebuys';
    final addonText = game.settings.addOn ? 'Add-on: Yes' : 'No add-on';
    final koText = game.settings.koEnabled && game.settings.koAmount > 0
        ? 'KO Bounty: ${game.settings.koAmount}'
        : null;

    final card = ChatMessage(
      id: 'pinned-${DateTime.now().millisecondsSinceEpoch}',
      authorId: _user!.id,
      authorName: _user!.name,
      body:
          '${game.settings.name} — ${game.settings.date} at ${game.settings.time}\n'
          'Buy-in: ${game.settings.buyIn} · Code: ${game.publicCode}\n'
          '$anteText · $rebuyText · $addonText'
          '${koText == null ? "" : " · $koText"}',
      timestamp: DateTime.now(),
      deleted: false,
      pinned: true,
      gameId: game.id,
    );
    _currentGame = game.copyWith(
      status: LiveGameStatus.published,
      chat: [...game.chat, card],
      originalLevels: List.of(game.structure.levels),
    );
    _setGroup(
      _currentGroup.copyWith(
        chat: [..._currentGroup.chat, card],
        games: _currentGroup.games
            .map(
              (g) => g.id == game.id
                  ? g.copyWith(
                      status: LiveGameStatus.published,
                      chat: [...g.chat, card],
                      originalLevels: List.of(game.structure.levels),
                    )
                  : g,
            )
            .toList(),
      ),
    );
    _postGroupChat(card);
    _syncGroupGame();
    if (_backendUp) {
      unawaited(_repo.upsertGameCodes(_currentGame!));
    }
    addAuditRecord(
      'publish',
      'Published ${game.settings.name} '
          '(${game.settings.date} ${game.settings.time}) for RSVP.',
    );
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'New game published',
        body:
            '${game.settings.name} is open for RSVP — '
            '${game.settings.date} at ${game.settings.time}.',
        type: NotificationType.game,
        link: '/invitation',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    addAnnouncement('${game.settings.name} is now open for RSVP.', true);
    notifyListeners();
  }

  /// Admin edits an already-created event's details. Records an audit entry,
  /// notifies members, and re-generates the structure when the field change
  /// would affect it (checklist §10.4). RSVP validity is surfaced in the audit.
  void updateEventSettings(GameSettings next, {bool clearRsvps = false}) {
    final game = _currentGame;
    if (game == null || _user == null) return;
    final prev = game.settings;
    if (prev == next) return;
    _pushUndo();

    var s = next;
    // The structure only depends on players, buy-in, duration and ante rules;
    // cosmetic fields (name/date/time/location/privacy) keep the structure.
    final affectsStructure =
        prev.players != s.players ||
        prev.buyIn != s.buyIn ||
        prev.durationHours != s.durationHours ||
        prev.anteEnabled != s.anteEnabled ||
        prev.anteAfterLevel != s.anteAfterLevel ||
        prev.anteStyle != s.anteStyle ||
        prev.koEnabled != s.koEnabled ||
        prev.koAmount != s.koAmount ||
        prev.rebuys != s.rebuys ||
        prev.rebuysCloseLevel != s.rebuysCloseLevel ||
        prev.reEntry != s.reEntry ||
        prev.addOn != s.addOn ||
        prev.addOnCloseLevel != s.addOnCloseLevel;

    final edits = <String>[];
    if (prev.name != s.name) edits.add('name → ${s.name}');
    if (prev.date != s.date) edits.add('date → ${s.date}');
    if (prev.time != s.time) edits.add('time → ${s.time}');
    if (prev.location != s.location) {
      edits.add('location ${s.locationPrivate ? '(private) ' : ''}updated');
    }
    if (prev.buyIn != s.buyIn) edits.add('buy-in → ${s.buyIn}');
    if (prev.locationPrivate != s.locationPrivate) {
      edits.add(s.locationPrivate ? 'address hidden' : 'address visible');
    }

    if (affectsStructure) {
      if (game.structure.levels.isEmpty && !(game.status == LiveGameStatus.ready)) {
        _currentGame = game.copyWith(
          settings: s,
          players: clearRsvps
              ? game.players.map((p) => p.copyWithClearRsvp()).toList()
              : game.players,
        );
        edits.add('settings saved (structure deferred)');
      } else {
        var structure = TournamentEngine.generate(
          TournamentParams(
            players: s.players,
            durationHours: s.durationHours,
            buyIn: s.buyIn,
            chipSet: s.chipSet,
            rebuys: s.rebuys,
            rebuysCloseLevel: s.rebuysCloseLevel,
            reEntry: s.reEntry,
            addOn: s.addOn,
            anteEnabled: s.anteEnabled,
            anteAfterLevel: s.anteAfterLevel,
            anteStyle: s.anteStyle,
            koEnabled: s.koEnabled,
            koAmount: s.koAmount,
            organizerPct: s.organizerPct,
            rebuyCost: s.rebuyCost,
            addOnCost: s.addOnCost,
          ),
        );
        // After play starts the starting stacks are frozen (client rule).
        if (game.stacksLocked) {
          structure = structure.copyWith(
            startingStack: game.structure.startingStack,
            chipPlan: game.structure.chipPlan,
            rebuyStack: game.structure.rebuyStack,
            rebuyChipPlan: game.structure.rebuyChipPlan,
            addOnStack: game.structure.addOnStack,
            addOnChipPlan: game.structure.addOnChipPlan,
          );
        }
        _currentGame = game.copyWith(
          settings: s,
          structure: structure,
          secondsRemaining: structure.levelDuration * 60,
          speedRecommendation: null,
          clearSpeedRecommendation: true,
          players: clearRsvps
              ? game.players.map((p) => p.copyWithClearRsvp()).toList()
              : game.players,
        );
        edits.add('structure regenerated');
      }
    } else {
      _currentGame = game.copyWith(
        settings: s,
        players: clearRsvps
            ? game.players.map((p) => p.copyWithClearRsvp()).toList()
            : game.players,
      );
    }

    // §10.4: persist a visible change timeline on the event record so every
    // member sees what moved without digging through chat history.
    if (edits.isNotEmpty) {
      final stamp = DateTime.now().toString().substring(0, 16);
      var log = [...game.changeLog, ...edits.map((e) => '$stamp · $e')];
      if (log.length > 12) log = log.sublist(log.length - 12);
      _currentGame = _currentGame!.copyWith(changeLog: log);
      _postUpdatedEventCard(log.last, s);
    }

    _syncGroupGame();
    addAuditRecord('event_edit', 'Event updated: ${edits.join('; ')}.');
    if (edits.isNotEmpty) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Event updated',
          body: '${s.name} — ${edits.take(2).join('; ')}.',
          type: NotificationType.game,
          link: '/invitation',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
    addAnnouncement('Event details updated.', false);
    notifyListeners();
  }

  /// Reposts the pinned event card after a published-event edit (User Flow
  /// §10.4 "Mark important changes in the pinned chat card"). The card uses
  /// the exact format of [publishGame]'s announcement card and appends an
  /// "Updated:" line carrying the newest change-log entry. Posted to both the
  /// game chat list and the group chat list, with cloud persistence mirroring
  /// the publish path. Only called when a change-log entry was produced.
  void _postUpdatedEventCard(String newestChangeLogEntry, GameSettings s) {
    final game = _currentGame;
    if (game == null || _user == null) return;
    final anteText = s.anteEnabled
        ? 'Ante: L${s.anteAfterLevel}+'
        : 'No ante';
    final rebuyText = s.rebuysCloseLevel > 0
        ? 'Rebuys: until L${s.rebuysCloseLevel}'
        : 'No rebuys';
    final addonText = s.addOn ? 'Add-on: Yes' : 'No add-on';
    final koText = s.koEnabled && s.koAmount > 0
        ? 'KO Bounty: ${s.koAmount}'
        : null;
    final card = ChatMessage(
      id: 'pinned-${DateTime.now().millisecondsSinceEpoch}',
      authorId: _user!.id,
      authorName: _user!.name,
      body:
          '${s.name} — ${s.date} at ${s.time}\n'
          'Buy-in: ${s.buyIn} · Code: ${game.publicCode}\n'
          '$anteText · $rebuyText · $addonText'
          '${koText == null ? "" : " · $koText"}\n'
          'Updated: $newestChangeLogEntry',
      timestamp: DateTime.now(),
      deleted: false,
      pinned: true,
      gameId: game.id,
    );
    _currentGame = game.copyWith(chat: [...game.chat, card]);
    _setGroup(
      _currentGroup.copyWith(chat: [..._currentGroup.chat, card]),
    );
    _postGroupChat(card);
  }

  /// Records that the end-of-rebuy settlement has been confirmed. From this
  /// point the public label reads "Prize Pool" instead of "Estimated Prize
  /// Pool" (12-068, 14-038/14-039, 15-009, 15-030), and no more rebuys,
  /// re-entries or add-ons are possible (12-065).
  /// Computes the *final* prize distribution from the actual contributions
  /// recorded at the end of the rebuy level (client rule: prices are only
  /// calculated there — exact field size, actual rebuys and the selected
  /// add-ons). [addOnCount] is the number of add-ons taken at settlement.
  ({int organizerAmount, int prizePool, List<Prize> prizes})
  previewSettlementPrizes(int addOnCount) {
    final game = _currentGame;
    if (game == null) {
      return (organizerAmount: 0, prizePool: 0, prizes: const []);
    }
    final s = game.settings;
    final participants = game.players
        .where((p) => p.confirmed || p.checkedIn)
        .length;
    final rebuys = game.players.fold<int>(0, (sum, p) => sum + p.rebuys);
    final reEntries = game.players.fold<int>(0, (sum, p) => sum + p.reEntries);
    final addOns = game.players.where((p) => p.hasAddOn).length + addOnCount;
    final gross =
        s.buyIn * participants +
        s.effectiveRebuyCost * rebuys +
        s.buyIn * reEntries +
        s.effectiveAddOnCost * addOns;
    final int roundingUnit = TournamentEngine.roundingUnitFor(s.buyIn);

    return TournamentEngine.recalculatePrizes(
      gross,
      participants,
      s.organizerPct.toDouble(),
      forcePaidPlaces: s.forcePaidPlaces,
      roundingUnit: roundingUnit,
    );
  }

  void confirmSettlement() {
    final game = _currentGame;
    if (game == null) return;
    final finalPrizes = previewSettlementPrizes(0);
    _currentGame = game.copyWith(
      settlementConfirmed: true,
      pendingGuests: const [],
      structure: game.structure.copyWith(
        organizerAmount: finalPrizes.organizerAmount,
        prizePool: finalPrizes.prizePool,
        prizes: finalPrizes.prizes,
      ),
    );
    _syncGroupGame();
    addAuditRecord(
      'settlement',
      'Rebuy/add-on break settled. Final prize pool: ${finalPrizes.prizePool}.',
    );
    addAnnouncement('Prize pool confirmed: ${finalPrizes.prizePool}.', true);
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Prize Pool confirmed',
        body:
            '${game.settings.name} — final prize pool: ${finalPrizes.prizePool}.',
        type: NotificationType.game,
        link: '/player-live',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  // ── Timer ──────────────────────────────────────────────────────────────────
  Timer? _ticker;
  Timer? _serverTimeRecalibration;

  /// Marks already announced per level (checklist 15-047/15-048) so the
  /// five-minute and one-minute warnings fire only once per level.
  final Set<String> _levelAnnouncementMarks = <String>{};

  void _announceLevelMark(int remaining) {
    final game = _currentGame;
    if (game == null || !game.timerRunning) return;
    final level = game.currentLevel;
    final mark = '$level';
    if (remaining <= 300 &&
        remaining > 60 &&
        !_levelAnnouncementMarks.contains('$mark:300')) {
      _levelAnnouncementMarks.add('$mark:300');
      addAnnouncement('Five minutes remaining in level $level.', true);
    }
    if (remaining <= 60 &&
        remaining > 0 &&
        !_levelAnnouncementMarks.contains('$mark:60')) {
      _levelAnnouncementMarks.add('$mark:60');
      addAnnouncement('One minute remaining in level $level.', true);
    }
  }

  void _startTick() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_currentGame == null || !_currentGame!.timerRunning) return;
      int remaining;
      if (_currentGame!.levelEndTime != null) {
        remaining = _currentGame!.levelEndTime!
            .difference(_serverNow)
            .inSeconds;
      } else {
        remaining = _currentGame!.secondsRemaining - 1;
      }
      if (remaining <= 0) {
        final isLastLevel = _currentGame!.currentLevel >= _currentGame!.structure.levels.length;
        if (isLastLevel) {
          _currentGame = _currentGame!.copyWith(
            secondsRemaining: 0,
            timerRunning: false,
          );
          addAnnouncement('Tournament has reached the end of the structure.', true);
          _syncGroupGame();
          notifyListeners();
        } else {
          nextLevel();
        }
        _evaluateSpeedRecommendation();
        return;
      }
      _announceLevelMark(remaining);
      // While the clock runs off [levelEndTime], every widget derives the
      // countdown from that timestamp via `currentSecondsRemaining()` — the
      // `secondsRemaining` field is not read. Mutating `_currentGame` each
      // second would only churn the object and make the NEXT unrelated
      // snapshot see a "changed" game and trigger a spurious whole-doc save.
      // Only refresh the field when there is no end-time to derive from.
      if (_currentGame!.levelEndTime == null) {
        _currentGame = _currentGame!.copyWith(secondsRemaining: remaining);
      }
      _isTickUpdate = true;
      notifyListeners();
      _isTickUpdate = false;
    });
  }

  /// Estimated minutes still to play from now, minus the minutes the target
  /// schedule still allows (technical §11.4). Positive drift means the
  /// tournament is running long; negative means it is running short. Returns
  /// 0 when no meaningful estimate exists (game not live yet, already over,
  /// or fewer than two players).
  ///
  /// Estimate: remaining levels' durations scaled by a pace factor of expected
  /// remaining field / actual remaining field (clamped 0.5..2.0). Target:
  /// settings.durationHours * 60 minus elapsed playing time (summed completed
  /// level durations plus the consumed part of the current level).
  int estimatedFinishDriftMinutes() {
    final game = _currentGame;
    if (game == null || !game.status.isActiveLive) return 0;
    if (game.players.length < 2) return 0;
    final levels = game.structure.levels;
    // Elapsed playing time: completed levels plus the consumed seconds of the
    // current level.
    var elapsedMins = 0.0;
    for (var i = 0; i < game.currentLevel - 1 && i < levels.length; i++) {
      elapsedMins += levels[i].durationMins;
    }
    final currentLevelData = game.currentLevelData;
    final currentDurationMins =
        currentLevelData?.durationMins ?? game.structure.levelDuration;
    final consumedSeconds =
        currentDurationMins * 60 - game.currentSecondsRemaining();
    elapsedMins += consumedSeconds.clamp(0, currentDurationMins * 60) / 60.0;
    // Remaining scheduled work: future levels only.
    var remainingLevelsMins = 0;
    for (var i = game.currentLevel; i < levels.length; i++) {
      remainingLevelsMins += levels[i].durationMins;
    }
    // Pace factor: how the actual remaining field compares with the expected
    // one (clamped so extreme fields cannot produce absurd estimates).
    final expectedRemaining = game.settings.players;
    final actualRemaining = game.activePlayers.length;
    if (actualRemaining < 1 || expectedRemaining < 1) return 0;
    final paceFactor =
        (expectedRemaining / actualRemaining).clamp(0.5, 2.0);
    final estimateMins = remainingLevelsMins * paceFactor;
    final targetRemainingMins =
        game.settings.durationHours * 60 - elapsedMins;
    return (estimateMins - targetRemainingMins).round();
  }

  /// Live recommendation (technical §11.4): if the estimated finish differs
  /// from the target by more than 20 minutes, offer a recommendation. Running
  /// long suggests speeding up future levels; running short suggests slowing
  /// them down. Never auto-mutates the structure and is cleared again on
  /// nextLevel/previousLevel/restart.
  void _evaluateSpeedRecommendation() {
    final game = _currentGame;
    if (game == null || game.status != LiveGameStatus.running) return;
    if (game.players.length < 2) return;
    final drift = estimatedFinishDriftMinutes();
    SpeedRecommendation? rec;
    if (drift > 20) {
      rec = SpeedRecommendation.speedUp;
    } else if (drift < -20) {
      rec = SpeedRecommendation.slowDown;
    }
    if (rec == game.speedRecommendation) return;
    _currentGame = game.copyWith(speedRecommendation: rec);
    notifyListeners();
  }

  /// Manually forces recalculation of finish time/speed recommendations.
  void forceEvaluateSpeedRecommendation() {
    _evaluateSpeedRecommendation();
    addAnnouncement('Recalculated speed recommendation.', false);
  }

  /// Used to derive server-authoritative timer from Firestore server time.
  Duration? _serverTimeOffset;

  /// The calibrated offset between local device time and server truth.
  Duration get serverTimeOffset => _serverTimeOffset ?? Duration.zero;

  /// Calibrates the local-to-server time offset using a Firestore write/read
  /// round-trip. Call once on startup and periodically to keep drift minimal.
  Future<void> _calibrateServerTime() async {
    if (!_backendUp) return;
    try {
      final before = DateTime.now();
      final ref = _repo.serverTimeRef;
      await ref.set({'t': FieldValue.serverTimestamp()});
      final snap = await ref.get();
      final serverTs = snap.data()?['t'];
      final after = DateTime.now();
      if (serverTs != null) {
        final serverDt = (serverTs as dynamic).toDate() as DateTime;
        final mid = before.add(after.difference(before) ~/ 2);
        _serverTimeOffset = serverDt.difference(mid);
      }
    } catch (_) {
      // Ignore — fallback to local time
    }
  }

  /// Returns the current server-authoritative time, falling back to local time
  /// if calibration hasn't completed.
  DateTime get _serverNow =>
      DateTime.now().add(_serverTimeOffset ?? Duration.zero);

  /// Starts periodic server-time re-calibration (tech spec §4.3). During a
  /// long tournament the local clock can drift; re-calibrating every 10 minutes
  /// keeps the timer display accurate across all connected devices.
  void _startServerTimeRecalibration() {
    _serverTimeRecalibration?.cancel();
    _serverTimeRecalibration = Timer.periodic(
      const Duration(minutes: 10),
      (_) => _calibrateServerTime(),
    );
  }

  void startTimer() {
    // Client rule: no guessed player count at setup — the AI finalises the
    // stacks/blinds/levels right now, from the actual final headcount
    // (checked-in players if any confirmed, otherwise final RSVPs), the
    // moment the admin presses Start. This supersedes whatever estimate the
    // 30-minute pre-start window may have already shown.
    recalculateStructure();
    _currentGame = _currentGame!.copyWith(structureConfirmed: true);
    addAuditRecord(
      'structure_final',
      'Structure finalised at start for ${_currentGame!.settings.players} '
          'players: stack ${_currentGame!.structure.startingStack}, '
          '${_currentGame!.structure.levels.length} levels.',
    );

    _levelAnnouncementMarks.clear();
    // Re-calibrate server time and start periodic re-calibration for long
    // tournaments (tech spec §4.3).
    _calibrateServerTime();
    _startServerTimeRecalibration();
    final level = _currentGame!.currentLevelData;
    _currentGame = _currentGame!.copyWith(
      timerRunning: true,
      status: LiveGameStatus.running,
      levelEndTime: _serverNow.add(
        Duration(seconds: _currentGame!.secondsRemaining),
      ),
    );
    addAnnouncement(
      'Tournament starts. Level ${_currentGame!.currentLevel}. '
      'Blinds ${level?.sb ?? 0} and ${level?.bb ?? 0}.',
      true,
    );
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Tournament starting',
        body: '${_currentGame!.settings.name} is live now.',
        type: NotificationType.game,
        link: '/player-live',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    _syncGroupGame();
  }

  void pauseTimer() {
    _currentGame = _currentGame!.copyWith(
      timerRunning: false,
      status: LiveGameStatus.paused,
      secondsRemaining: _currentGame!.currentSecondsRemaining(_serverTimeOffset ?? Duration.zero),
      levelEndTime: null,
      clearLevelEndTime: true,
    );
    _syncGroupGame();
    notifyListeners();
  }

  void resumeTimer() {
    _currentGame = _currentGame!.copyWith(
      timerRunning: true,
      status: LiveGameStatus.running,
      levelEndTime: _serverNow.add(
        Duration(seconds: _currentGame!.secondsRemaining),
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  void nextLevel({String? idempotencyKey}) {
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'nextLevel');
    if (rev == null) return; // replayed action — already applied
    final next = _currentGame!.currentLevel + 1;
    _pushUndo();
    _levelAnnouncementMarks.clear();
    // Auto-trigger rebuy pause when crossing rebuysCloseLevel (spec §1, §12 A12)
    final wasBelowRebuyClose =
        _currentGame!.currentLevel <= _currentGame!.settings.rebuysCloseLevel;
    final nowAtOrAboveRebuyClose =
        next > _currentGame!.settings.rebuysCloseLevel;
    final shouldPauseRebuy =
        _currentGame!.settings.rebuys &&
        wasBelowRebuyClose &&
        nowAtOrAboveRebuyClose;
    if (shouldPauseRebuy) {
      final level = (next <= _currentGame!.structure.levels.length)
          ? _currentGame!.structure.levels[next - 1]
          : _currentGame!.structure.levels.last;
      _currentGame = _currentGame!.copyWith(
        currentLevel: next,
        secondsRemaining: level.durationMins * 60,
        timerRunning: false,
        status: LiveGameStatus.rebuypause,
        speedRecommendation: null,
        levelEndTime: null,
        clearSpeedRecommendation: true,
        clearLevelEndTime: true,
        revision: rev,
        lastIdempotencyKey: idemKey,
      );
      addAnnouncement(
        'Rebuys are now closed. Add-ons are available.',
        true,
      );
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Rebuys closed',
          body:
              '${_currentGame!.settings.name} — rebuy period ended. Settlement required.',
          type: NotificationType.game,
          link: '/rebuy-settlement',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    } else {
      // Spec C5: if next index is past the generated end, append an auto-extension
      // level (payable, ~1.4x last BB, same duration, capped by chips in play).
      if (next > _currentGame!.structure.levels.length) {
        final lastLevel = _currentGame!.structure.levels.last;
        int nextBB = (lastLevel.bb * 1.4).ceil();
        final chipsInPlay = _currentGame!.totalChipsInPlay;
        if (nextBB >= chipsInPlay) {
          nextBB = chipsInPlay;
          addAnnouncement('Max blinds reached - sudden death until a winner is decided.', true);
        }
        final nextSB = (nextBB * 0.4).ceil();
        final extensionLevel = BlindLevel(
          level: next,
          sb: nextSB,
          bb: nextBB,
          durationMins: lastLevel.durationMins,
          ante: lastLevel.ante,
        );
        _currentGame = _currentGame!.copyWith(
          structure: _currentGame!.structure.copyWith(
            levels: [..._currentGame!.structure.levels, extensionLevel],
          ),
        );
      }
      final extLevel = _currentGame!.structure.levels[next - 1];
      _currentGame = _currentGame!.copyWith(
        currentLevel: next,
        secondsRemaining: extLevel.durationMins * 60,
        timerRunning: true,
        status: LiveGameStatus.running,
        speedRecommendation: null,
        clearSpeedRecommendation: true,
        levelEndTime: _serverNow.add(Duration(minutes: extLevel.durationMins)),
        revision: rev,
        lastIdempotencyKey: idemKey,
      );
      addAnnouncement(
        'Level $next. Blinds ${extLevel.sb} / ${extLevel.bb}'
        '${extLevel.ante != null ? " — ante ${extLevel.ante}" : ""}.',
        true,
      );
    }
    _syncGroupGame();
    notifyListeners();
  }

  /// Rewinds to the previous level (spec §12 "Previous" control). The clock
  /// resets to the full previous-level duration and the game resumes running.
  void previousLevel({String? idempotencyKey}) {
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'previousLevel');
    if (rev == null) return; // replayed action — already applied
    final prev = _currentGame!.currentLevel - 1;
    if (prev < 1) return;
    _pushUndo();
    _levelAnnouncementMarks.clear();
    final level = _currentGame!.structure.levels[prev - 1];
    _currentGame = _currentGame!.copyWith(
      currentLevel: prev,
      secondsRemaining: level.durationMins * 60,
      timerRunning: true,
      status: LiveGameStatus.running,
      speedRecommendation: null,
      clearSpeedRecommendation: true,
      levelEndTime: _serverNow.add(Duration(minutes: level.durationMins)),
      revision: rev,
      lastIdempotencyKey: idemKey,
    );
    addAnnouncement(
      'Level $prev. Blinds ${level.sb} and ${level.bb}'
      '${level.ante != null ? ', ante ${level.ante}' : ''}.',
      true,
    );
    _syncGroupGame();
    notifyListeners();
  }

  /// Restarts the clock for the current level (spec §12: requires
  /// confirmation showing its exact effect — the admin UI gates this behind a
  /// confirm dialog). Resets to the full level duration and resumes running.
  void restartLevel({String? idempotencyKey}) {
    final game = _currentGame;
    if (game == null) return;
    if (game.status != LiveGameStatus.running &&
        game.status != LiveGameStatus.paused &&
        game.status != LiveGameStatus.rebuypause) {
      return;
    }
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'restartLevel');
    if (rev == null) return; // replayed action — already applied
    _pushUndo();
    _levelAnnouncementMarks.clear();
    final level = game.currentLevelData;
    final durationMins = level?.durationMins ?? game.structure.levelDuration;
    _currentGame = game.copyWith(
      secondsRemaining: durationMins * 60,
      timerRunning: true,
      status: LiveGameStatus.running,
      speedRecommendation: null,
      clearSpeedRecommendation: true,
      levelEndTime: _serverNow.add(Duration(minutes: durationMins)),
      revision: rev,
      lastIdempotencyKey: idemKey,
    );
    _syncGroupGame();
    addAuditRecord(
      'restart-level',
      'Restarted level ${game.currentLevel} (blinds ${level?.sb ?? 0}/${level?.bb ?? 0}).',
    );
    addAnnouncement('Level ${game.currentLevel} restarted.', true);
    notifyListeners();
  }

  // ── Player management ──────────────────────────────────────────────────────
  void eliminatePlayer(String playerId, {String? koRecipientId, String? idempotencyKey}) {
    if (!_isGameAuthority) return;
    final (rev, key) =
        _claimIdempotency(idempotencyKey ?? '', action: 'eliminatePlayer', target: playerId);
    if (rev == null) return; // replayed action — already applied
    _pushUndo();
    final active = _currentGame!.players
        .where((p) => p.active && !p.eliminated)
        .toList();
    final pos = active.length;
    final bounty = _currentGame!.settings.koEnabled
        ? _currentGame!.settings.koAmount
        : 0;
    final updated = _currentGame!.players.map((p) {
      if (p.id == playerId) {
        return p.copyWith(eliminated: true, active: false, eliminationPos: pos, table: 0, seat: 0);
      }
      // Optional single knockout recipient (technical §11.3). The bounty
      // chips transfer from the eliminated player, so total chips in play
      // is unchanged — only the recipient's knockout count increases.
      if (koRecipientId != null && p.id == koRecipientId) {
        return p.copyWith(knockouts: p.knockouts + 1);
      }
      return p;
    }).toList();
    final remaining = updated.where((p) => p.active).length;
    // Final table redraw only fires for multi-table events (spec §7 and BR-020: "If a
    // multi-table event hits <= 9 players, a complete random redraw occurs.
    // Single table events do NOT trigger a redraw."). Seat-based single source of
    // truth — matches admin_dashboard's hadMultipleTables, so the auto-trigger
    // and the manual "Final Table Reached!" prompt can never disagree.
    final multiTableEvent = _currentGame!.players.any((p) => p.table > 1);
    final redrawNotCompleted = !_currentGame!.finalTableRedrawCompleted;
    if (remaining <= 9 && multiTableEvent && redrawNotCompleted) {
      _currentGame = _currentGame!.copyWith(
        players: updated,
        status: LiveGameStatus.finaltable,
        timerRunning: false,
        revision: rev,
        lastIdempotencyKey: key,
      );
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Final table reached',
          body: '${_currentGame!.settings.name} — nine players remain.',
          type: NotificationType.game,
          link: '/final-table',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    } else {
      _currentGame = _currentGame!.copyWith(
        players: updated,
        revision: rev,
        lastIdempotencyKey: key,
      );
    }
    final p = _currentGame!.players.firstWhere((pl) => pl.id == playerId);
    // Elimination names are optional per tournament and disabled by default
    // (15-053) — spoken only when the admin enabled the setting.
    final speakElimination = _currentGame!.settings.announceEliminations;
    if (koRecipientId != null && bounty > 0) {
      final koPlayer = _currentGame!.players
          .where((pl) => pl.id == koRecipientId)
          .firstOrNull;
      addAnnouncement(
        '${p.name} eliminated by ${koPlayer?.name ?? '?'} — $bounty bounty awarded.',
        speakElimination,
      );
    } else {
      addAnnouncement('${p.name} eliminated.', speakElimination);
    }
  }

  /// Manual trigger for final table state (small tournaments that never
  /// auto-transition because they started with ≤9 players).
  void triggerFinalTable() {
    if (_currentGame == null) return;
    if (_currentGame!.status == LiveGameStatus.finaltable) return;
    _currentGame = _currentGame!.copyWith(
      status: LiveGameStatus.finaltable,
      timerRunning: false,
    );
    addAuditRecord(
      'final_table',
      'Final table triggered manually.',
    );
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Final table',
        body: '${_currentGame!.settings.name} — final table triggered.',
        type: NotificationType.game,
        link: '/final-table',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  /// Explicitly corrects a past elimination without using Undo (which is unsafe
  /// if dependent actions occurred). Adds a compensating audit action.
  void correctElimination(String playerId) {
    if (!_isGameAuthority) return;
    if (_currentGame == null) return;

    // We intentionally bypass `_pushUndo()` for audit preservation,
    // but the spec says "never delete audit history", so we just append.
    final players = _currentGame!.players.map((p) {
      if (p.id == playerId) {
        return p.copyWith(
          eliminated: false,
          clearEliminationPos: true,
          active: true,
        );
      }
      return p;
    }).toList();

    _currentGame = _currentGame!.copyWith(players: players);
    final correctedPlayer = players.firstWhere((p) => p.id == playerId);

    addAuditRecord(
      'correction',
      'Corrected elimination for ${correctedPlayer.name}',
    );
    addAnnouncement(
      'Correction: ${correctedPlayer.name} has been reinstated to the game.',
      false,
    );
  }

  /// Host/Admin- or Co-Admin-only (spec §4: rebuys are never self-service —
  /// a member may only [requestRebuy]).
  void grantRebuy(String playerId, {String? idempotencyKey}) {
    final game = _currentGame;
    if (game == null || !canGrantRebuys) return;
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'grantRebuy', target: playerId);
    if (rev == null) return; // replayed action — already applied
    if (!game.settings.rebuys || game.rebuysClosed) return;
    final player = game.players.where((p) => p.id == playerId).firstOrNull;
    if (player == null || !player.eliminated) return;
    final rebuyLimit = game.settings.rebuyLimit;
    if (rebuyLimit != null && player.rebuys >= rebuyLimit) {
      lastRsvpError = '${player.name} has already used their $rebuyLimit '
          'rebuy${rebuyLimit == 1 ? '' : 's'}.';
      notifyListeners();
      return;
    }

    _pushUndo();
    final rebuyStack = game.structure.rebuyStack;
    _currentGame = game.copyWith(
      players: game.players
          .map((p) => p.id == playerId
              ? p.copyWith(
                  rebuys: p.rebuys + 1,
                  eliminated: false,
                  clearEliminationPos: true,
                  active: true,
                )
              : p)
          .toList(),
      totalChipsInPlay: game.totalChipsInPlay + rebuyStack,
      rebuyRequests: game.rebuyRequests.where((id) => id != playerId).toList(),
      revision: rev,
      lastIdempotencyKey: idemKey,
    );
    // Recalculate prize pool/prizes after money enters the game.
    // This updates only prizePool, organizerAmount and prizes on the structure,
    // leaving blind levels and any manual edits completely intact.
    _updatePrizePool();
  }

  /// Registers a player's request for a rebuy from the live view. The admin
  /// approves it from the dashboard, which clears the request. Non-authority
  /// devices also push the change as an array-union patch so the admin's
  /// dashboard picks it up live.
  void requestRebuy(String playerId) {
    if (_currentGame!.rebuyRequests.contains(playerId)) return;
    _currentGame = _currentGame!.copyWith(
      rebuyRequests: [..._currentGame!.rebuyRequests, playerId],
    );
    notifyListeners();
    if (!_isGameAuthority) {
      _patchActiveGame({
        'rebuyRequests': FieldValue.arrayUnion([playerId]),
      });
    }
  }

  void cancelRebuyRequest(String playerId) {
    _currentGame = _currentGame!.copyWith(
      rebuyRequests: _currentGame!.rebuyRequests
          .where((id) => id != playerId)
          .toList(),
    );
    notifyListeners();
    if (!_isGameAuthority) {
      _patchActiveGame({
        'rebuyRequests': FieldValue.arrayRemove([playerId]),
      });
    }
  }

  /// Records a re-entry (checklist §12.5): a separate, secondary option that
  /// grants the approved entry stack and is tracked independently of rebuys
  /// (12-046/12-047). Closes with late registration/rebuys (12-049), which is
  /// enforced by only showing the action while rebuys are still open.
  void grantReEntry(String playerId, {String? idempotencyKey}) {
    final game = _currentGame;
    if (game == null || !canGrantRebuys) return;
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'grantReEntry', target: playerId);
    if (rev == null) return; // replayed action — already applied
    if (!game.settings.reEntry || game.rebuysClosed) return;
    final player = game.players.where((p) => p.id == playerId).firstOrNull;
    if (player == null || !player.eliminated) return;

    _pushUndo();
    final entryStack = game.structure.startingStack;
    _currentGame = game.copyWith(
      players: game.players
          .map(
            (p) => p.id == playerId
                ? p.copyWith(
                    reEntries: p.reEntries + 1,
                    eliminated: false,
                    clearEliminationPos: true,
                    active: true,
                  )
                : p,
          )
          .toList(),
      totalChipsInPlay: game.totalChipsInPlay + entryStack,
      revision: rev,
      lastIdempotencyKey: idemKey,
    );
    _updatePrizePool();
  }

  void grantAddOn(String playerId, {String? idempotencyKey}) {
    final game = _currentGame;
    if (game == null || !canGrantRebuys) return;
    final (rev, idemKey) =
        _claimIdempotency(idempotencyKey ?? '', action: 'grantAddOn', target: playerId);
    if (rev == null) return; // replayed action — already applied
    if (!game.settings.addOn || game.settlementConfirmed) return;
    final player = game.players.where((p) => p.id == playerId).firstOrNull;
    if (player == null ||
        player.eliminated ||
        !player.active ||
        player.hasAddOn) {
      return;
    }

    _pushUndo();
    final addOnStack = game.structure.addOnStack;
    _currentGame = game.copyWith(
      players: game.players
          .map((p) => p.id == playerId ? p.copyWith(hasAddOn: true) : p)
          .toList(),
      totalChipsInPlay: game.totalChipsInPlay + addOnStack,
      addOnRequests: game.addOnRequests.where((id) => id != playerId).toList(),
      revision: rev,
      lastIdempotencyKey: idemKey,
    );
    // Recalculate prize pool/prizes after money enters the game.
    _updatePrizePool();
  }

  /// Registers a player's request for an add-on from the live view. The admin
  /// approves it during the settlement flow, which clears the request.
  void requestAddOn(String playerId) {
    if (_currentGame!.addOnRequests.contains(playerId)) return;
    _currentGame = _currentGame!.copyWith(
      addOnRequests: [..._currentGame!.addOnRequests, playerId],
    );
    notifyListeners();
    if (!_isGameAuthority) {
      _patchActiveGame({
        'addOnRequests': FieldValue.arrayUnion([playerId]),
      });
    }
  }

  void cancelAddOnRequest(String playerId) {
    _currentGame = _currentGame!.copyWith(
      addOnRequests: _currentGame!.addOnRequests
          .where((id) => id != playerId)
          .toList(),
    );
    notifyListeners();
    if (!_isGameAuthority) {
      _patchActiveGame({
        'addOnRequests': FieldValue.arrayRemove([playerId]),
      });
    }
  }

  void undoLast() {
    if (_undoStack.isEmpty) {
      addAnnouncement('Nothing to undo.', false);
      return;
    }
    final previous = _undoStack.removeLast();
    if (previous == null) return;
    _currentGame = previous;
    _saveUndoStack(); // <-- newly added sidecar persistence
    notifyListeners();
    addAnnouncement('Last action undone.', false);
  }

  void requestCheckIn(String playerId) {
    final requester = _currentGame!.players
        .where((p) => p.id == playerId)
        .firstOrNull;
    if (_currentGame!.status.isActiveLive && _currentGame!.rebuysClosed) {
      addAnnouncement('Late registration has closed.', false);
      return;
    }
    _currentGame = _currentGame!.copyWith(
      players: _currentGame!.players
          .map(
            (p) => p.id == playerId
                ? p.copyWith(checkedIn: true, confirmed: false)
                : p,
          )
          .toList(),
    );

    // Store the pending check-in state so incoming Firebase snapshots cannot
    // revert the "Waiting for confirmation" status before admin confirms.
    _pendingCheckIn.add(playerId);

    if (!_isGameAuthority) {
      // Members write only their own checkedIn flag via dot-path (same pattern
      // as RSVP). This actually persists to Firestore immediately.
      final gid = _currentGame?.groupId.isNotEmpty == true 
          ? _currentGame!.groupId 
          : _currentGroupId;
      final gameId = _currentGame?.id;
      if (gid != null && gameId != null && _backendUp) {
        unawaited(
          _repo.patchGame(gid, gameId, {
            'players.$playerId.checkedIn': true,
            'players.$playerId.confirmed': false,
          }).then((_) {
            // Overlay stays until admin confirms (checkedIn && confirmed == true).
          }).catchError((Object e) {
            debugPrint('requestCheckIn patch failed: $e');
            // On failure revert local state so the button is tappable again.
            _pendingCheckIn.remove(playerId);
            _currentGame = _currentGame?.copyWith(
              players: _currentGame!.players
                  .map((p) => p.id == playerId
                      ? p.copyWith(checkedIn: false, confirmed: false)
                      : p)
                  .toList(),
            );
            notifyListeners();
          }),
        );
      }
    }
    // Admin path: whole-doc save via _syncGameToCloud handles persistence.

    if (requester != null && _user?.id != playerId) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Check-in request',
          body: '${requester.name} is waiting to be checked in.',
          type: NotificationType.game,
          link: '/check-in',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
    _syncGroupGame();
    notifyListeners();
  }

  void checkInPlayer(String playerId) {
    if (_currentGame!.status.isActiveLive && _currentGame!.rebuysClosed) {
      addAnnouncement('Late registration has closed.', false);
      return;
    }
    _pushUndo();
    _currentGame = _currentGame!.copyWith(
      players: _currentGame!.players
          .map(
            (p) => p.id == playerId
                ? p.copyWith(checkedIn: true, confirmed: true)
                : p,
          )
          .toList(),
    );
    _syncGroupGame();
    notifyListeners();
  }

  void cancelCheckIn(String playerId) {
    _currentGame = _currentGame!.copyWith(
      players: _currentGame!.players
          .map(
            (p) => p.id == playerId
                ? p.copyWith(checkedIn: false, confirmed: false)
                : p,
          )
          .toList(),
    );
    _syncGroupGame();
    notifyListeners();
  }

  /// Closes door check-in (spec §4.7). Once closed, the host is prompted to
  /// start the tournament and no further walk-ins are accepted.
  void closeCheckIn() {
    if (!_isGameAuthority) return;
    _currentGame = _currentGame!.copyWith(
      checkInClosed: true,
      status: LiveGameStatus.ready,
    );
    _syncGroupGame();
    addAnnouncement(
      'Check-in is now closed. No more players may join unless re-opened.',
      false,
    );
    notifyListeners();
  }

  void reopenCheckIn() {
    if (!_isGameAuthority) return;
    _currentGame = _currentGame!.copyWith(
      checkInClosed: false,
      status: LiveGameStatus.checkin,
    );
    _syncGroupGame();
    addAnnouncement('Check-in re-opened.', false);
    notifyListeners();
  }

  /// Registers an un-invited walk-in player at the door (spec §4.7). They are
  /// checked in immediately and seated by the next seating generation.
  ///
  /// Late-registration guard (User Flow §3.2 / §12.5): once the game is live
  /// and late registration has closed permanently at the end of the selected
  /// rebuy level, no new players may be added ("A player arrives after late
  /// registration closes; the system prevents addition"). Rebuy-break, final
  /// table, completed and cancelled states also block outright. Pre-live
  /// door walk-ins stay allowed by design even when check-in has been closed.
  ///
  /// Returns a validation message when the addition is illegal, or null on
  /// success. Callers may ignore the result safely.
  String? addWalkInPlayer(String name) {
    final game = _currentGame;
    if (game == null) return 'No active game.';
    final trimmed = Sanitization.sanitizeName(name);
    if (trimmed.isEmpty) return 'Enter a name for the walk-in.';
    switch (game.status) {
      case LiveGameStatus.completed:
        return 'The tournament has finished — no new players can be added.';
      case LiveGameStatus.cancelled:
        return 'The tournament was cancelled — no new players can be added.';
      case LiveGameStatus.rebuypause:
        return 'Rebuy break in progress — registration is closed.';
      case LiveGameStatus.finaltable:
        return 'Final table is set — no new players can be added.';
      default:
        break;
    }
    if (game.status.isActiveLive && game.rebuysClosed) {
      return 'Late registration has closed — no new players can be added.';
    }
    _pushUndo();
    final id = 'p-${DateTime.now().millisecondsSinceEpoch}';
    final player = Player(
      id: id,
      name: trimmed,
      isGuest: false,
      rsvp: null,
      checkedIn: true,
      confirmed: true,
      eliminated: false,
      rebuys: 0,
      hasAddOn: false,
      knockouts: 0,
      table: 0,
      seat: 0,
      active: true,
    );
    _currentGame = game.copyWith(
      players: [...game.players, player],
      totalChipsInPlay: game.totalChipsInPlay + game.structure.startingStack,
    );
    _updatePrizePool();
    recalculateStructure();

    // Suggest a seat if tables are already generated (meaning play has started or seating is done)
    if (_currentGame!.players.any((p) => p.table > 0)) {
      final tables = _currentGame!.players
          .where((p) => p.table > 0)
          .map((p) => p.table)
          .toSet();
      if (tables.isNotEmpty) {
        // Find table with minimum players
        int minTable = tables.first;
        int minCount = 999;
        for (var t in tables) {
          int count = _currentGame!.players
              .where((p) => p.table == t && p.active)
              .length;
          if (count < minCount) {
            minCount = count;
            minTable = t;
          }
        }
        // Find first empty seat at minTable
        final taken = _currentGame!.players
            .where((p) => p.table == minTable)
            .map((p) => p.seat)
            .toSet();
        int freeSeat = 1;
        while (taken.contains(freeSeat)) {
          freeSeat++;
        }
        _pendingSeatMove = SeatMoveRecommendation(
          fromPlayerId: player.id,
          fromPlayerName: player.name,
          fromTable: 0,
          fromSeat: 0,
          toTable: minTable,
          toSeat: freeSeat,
          reason: 'Late add requires a seat.',
        );
      }
    }

    _syncGroupGame();
    addAnnouncement('${player.name} walked in and is checked in.', true);
    notifyListeners();
    return null;
  }

  void confirmGuest(String guestId) {
    if (!_isGameAuthority) return;
    _pushUndo();
    final game = _currentGame!;
    final guest = game.players.where((p) => p.id == guestId).firstOrNull;

    // #3: Only confirm a guest that actually exists. Never add chips for a
    // phantom row (e.g. a stale Accept tap that raced a state change).
    if (guest == null) return;

    // #4: Late-registration re-check at confirm time — no new stacks once
    // rebuys have closed while the game is live. Mirrors the guard applied
    // when the guest request first arrived (_applyQueuedGuestCheckIn) so the
    // admin cannot confirm a late guest the event no longer accepts.
    if (game.status.isActiveLive && game.rebuysClosed) {
      addAnnouncement(
        'Late registration is closed — ${guest.name} cannot be confirmed now.',
        false,
      );
      return;
    }

    final updated = game.players
        .map(
          (p) => p.id == guestId
              ? p.copyWith(confirmed: true, checkedIn: true, active: true)
              : p,
        )
        .toList();

    final extraChips = game.structure.startingStack;
    final inviterId = guest.inviterId;
    final guestSlot = guest.guestSlot;
    final canTagSlot = inviterId != null && guestSlot != null;

    _currentGame = game.copyWith(
      players: updated,
      pendingGuests: game.pendingGuests.where((p) => p.id != guestId).toList(),
      totalChipsInPlay: game.totalChipsInPlay + extraChips,
      guestSlots: canTagSlot
          ? game.guestSlots.map((s) {
              if (s.inviterId == inviterId && s.slot == guestSlot) {
                return s.copyWith(
                  guestName: guest.name,
                  status: GuestSlotStatus.checkedIn,
                );
              }
              return s;
            }).toList()
          : game.guestSlots,
    );

    if (extraChips > 0) {
      _updatePrizePool();
    }

    // #2: Close the server-side slot-claim lifecycle once the guest is
    // confirmed and their slot is tagged checked-in. The confirmed seat is
    // still protected against re-claims by the guestSlots.checkedIn state, but
    // the claim-lock doc no longer lingers, so a future host correction
    // (removePlayer/rejectGuest) can re-open the seat without a stale lock.
    if (canTagSlot && _backendUp) {
      _repo
          .releaseSlotClaim(_currentGame!.id, inviterId, guestSlot)
          .catchError((_) {});
    }

    addAnnouncement('Guest confirmed and seated.', false);
    if (guest != null) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Guest confirmed',
          body: '${guest.name} is confirmed for ${game.settings.name}.',
          type: NotificationType.invite,
          link: '/guest-flow',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
  }

  /// Admin rejects a pending guest request — the guest is removed from the
  /// players list and no longer sits at the table (07-026). Their slot is
  /// freed so another guest can claim it.
  void rejectGuest(String guestId) {
    if (!_isGameAuthority) return;
    _pushUndo();
    final guest = _currentGame!.players
        .where((p) => p.id == guestId)
        .firstOrNull;
    final inviterId = guest?.inviterId;
    final guestSlot = guest?.guestSlot;
    final canFree = guest != null && inviterId != null && guestSlot != null;
    _currentGame = _currentGame!.copyWith(
      players: _currentGame!.players.where((p) => p.id != guestId).toList(),
      pendingGuests: _currentGame!.pendingGuests
          .where((p) => p.id != guestId)
          .toList(),
      guestSlots: canFree
          ? _currentGame!.guestSlots
                .map(
                  (s) => s.inviterId == inviterId && s.slot == guestSlot
                      ? s.copyWith(
                          clearGuestName: true,
                          status: GuestSlotStatus.unclaimed,
                        )
                      : s,
                )
                .toList()
          : _currentGame!.guestSlots,
    );
    addAnnouncement('Guest request rejected.', false);
    // Free the server-side slot claim too, so another guest can claim the
    // slot immediately (spec §7.1 — admin correction reopens the slot).
    if (canFree && _backendUp) {
      _repo
          .releaseSlotClaim(_currentGame!.id, inviterId, guestSlot)
          .catchError((_) {});
    }
  }

  /// Marks the matching guest slot as claimed so the free-slot count
  /// on the guest flow and invitation screens stays accurate. When
  /// [requested] is true the claim carries a check-in request and the slot
  /// moves to [GuestSlotStatus.checkInRequested] (user-flow spec §7.1:
  /// Unclaimed → Reserved → Check-in Requested → Checked In).
  List<GuestSlot> _markSlotReserved(
    List<GuestSlot> slots,
    String inviterId,
    int slot, {
    String? name,
    bool requested = false,
  }) {
    final target = requested
        ? GuestSlotStatus.checkInRequested
        : GuestSlotStatus.reserved;
    final updated = slots.map((s) {
      if (s.inviterId == inviterId && s.slot == slot && s.available) {
        return s.copyWith(guestName: name, status: target);
      }
      return s;
    }).toList();
    // Safety net: the inviter somehow has no persisted slot record.
    if (!updated.any((s) => s.inviterId == inviterId && s.slot == slot)) {
      updated.add(
        GuestSlot(
          id: 'slot-${DateTime.now().millisecondsSinceEpoch}-$inviterId-$slot',
          inviterId: inviterId,
          slot: slot,
          guestName: name,
          status: target,
        ),
      );
    }
    return updated;
  }

  /// Guest flow: attach a brand-new guest to a game and mark them pending.
  /// With a backend this posts a request to the game's queue for the admin
  /// device to consume — the guest's own view stays read-only. Offline (no
  /// backend) the same mutation is applied locally so the demo flow keeps
  /// working. The guest's session is persisted either way so the device can
  /// recover the request after a refresh (checklist 07-030).
  ///
  /// Resolves the slot and returns one of:
  ///  * [GuestCheckInStatus.booked] — the slot was free and has now been
  ///    booked with [name];
  ///  * [GuestCheckInStatus.confirmed] — the slot was already booked under
  ///    [name] (the guest re-identified and resumed);
  ///  * [GuestCheckInStatus.taken] — the slot is booked under a different
  ///    name (message explains the conflict);
  ///  * [GuestCheckInStatus.failed] — a transient/validation failure.
  Future<GuestCheckInResult> requestGuestCheckIn(
      String name, String inviterId, int slot) async {
    final game = _currentGame;
    if (game == null) {
      return const GuestCheckInResult(
        GuestCheckInStatus.failed,
        message: 'No active game found.',
      );
    }

    // Late registration closes permanently once the rebuy window shuts (User
    // Flow §3.2/§10.3, Tech Spec §21/§12.5): reject the booking before the
    // optimistic reserve so the guest never sees a phantom "booked" slot.
    if (game.status.isActiveLive && game.rebuysClosed) {
      return const GuestCheckInResult(
        GuestCheckInStatus.failed,
        message: 'Late registration has closed - no new players can be added.',
      );
    }

    final session = _guestSession;
    // A guest's own booking lives in the request queue and, on a guest device,
    // the game is seen through the guest projection which strips pendingGuests.
    // So the slot may not look booked here even though THIS device reserved it.
    // Trust the device-local session: if the same person re-enters the same
    // name on the same inviter+slot, it's a re-identification, not a new claim —
    // never a spurious "this slot is for someone else". Falls through otherwise
    // so a genuinely different person is still blocked / redirected.
    if (session != null &&
        session.gameId == game.id &&
        session.inviterId == inviterId &&
        session.slot == slot &&
        session.name.trim().toLowerCase() == name.trim().toLowerCase()) {
      _saveGuestSession(session);
      return const GuestCheckInResult(GuestCheckInStatus.confirmed);
    }

    final existingSlot = game.guestSlots
        .where((s) => s.inviterId == inviterId && s.slot == slot)
        .firstOrNull;
    final claimedPlayer = game.players.where(
      (p) => p.isGuest && p.inviterId == inviterId && p.guestSlot == slot,
    ).firstOrNull;

    final isReserved =
        (existingSlot != null && !existingSlot.available) || claimedPlayer != null;

    if (isReserved) {
      final claimedName = claimedPlayer?.name ?? existingSlot?.guestName;
      final matches = claimedName != null &&
          claimedName.trim().toLowerCase() == name.trim().toLowerCase();
      if (matches) {
        // Re-identification successful — this is the guest's own slot.
        _saveGuestSession(
          GuestSession(
            gameId: game.id,
            name: claimedName,
            inviterId: inviterId,
            slot: slot,
          ),
        );
        return const GuestCheckInResult(GuestCheckInStatus.confirmed);
      }
      // The slot belongs to someone else — never overwrite their booking.
      return const GuestCheckInResult(
        GuestCheckInStatus.taken,
        message:
            'This slot is not booked on your name — it is reserved for someone else.',
      );
    }

    final guestId = 'g-${DateTime.now().millisecondsSinceEpoch}';
    final sanitizedName = Sanitization.sanitizeName(name);
    _saveGuestSession(
      GuestSession(
        gameId: game.id,
        name: sanitizedName,
        inviterId: inviterId,
        slot: slot,
      ),
    );

    if (_backendUp) {
      try {
        // Transactional claim: Firestore serializes racing guests on the
        // deterministic slot doc, so the first reservation wins server-side
        // even when both devices hold stale snapshots (spec §7.1).
        final err = await _repo.reserveGuestSlotTx(
          gameId: game.id,
          inviterId: inviterId,
          slot: slot,
          payload: {
            'guestId': guestId,
            'name': sanitizedName,
            'inviterId': inviterId,
            'slot': slot,
            // Lets security rules verify only group admins consume requests.
            'gid': game.groupId,
          },
        );
        if (err != null) {
          return GuestCheckInResult(
            GuestCheckInStatus.taken,
            message: err,
          );
        }
      } catch (e) {
        debugPrint('reserveGuestSlotTx(guestCheckIn) failed: $e');
        return const GuestCheckInResult(
          GuestCheckInStatus.failed,
          message: 'Could not reach the host. Check your connection.',
        );
      }
    }

    // The guest stays pending until the host confirms them at check-in
    // (spec §6 "waiting for admin confirmation", checklist 07-027/07-028).
    // Apply the pending guest locally (online AND offline) so this device
    // shows the booking instead of collapsing to "rejected" while the host's
    // request queue still holds the claim.
    _pushUndo();
    final guest = Player(
      id: guestId,
      name: sanitizedName,
      isGuest: true,
      inviterId: inviterId,
      guestSlot: slot,
      rsvp: Rsvp.going,
      checkedIn: false,
      confirmed: false,
      eliminated: false,
      rebuys: 0,
      hasAddOn: false,
      knockouts: 0,
      table: 0,
      seat: 0,
      active: false,
    );
    _currentGame = game.copyWith(
      players: [...game.players, guest],
      pendingGuests: [...game.pendingGuests, guest],
      guestSlots: _markSlotReserved(
        game.guestSlots,
        inviterId,
        slot,
        name: sanitizedName,
        // Claim + check-in request are one step in this flow (spec §6.3–6.5).
        requested: true,
      ),
    );
    notifyListeners();
    return const GuestCheckInResult(GuestCheckInStatus.booked);
  }

  /// Signs this device in anonymously so guests can read public projections
  /// and write to the request queue without an account. A no-op when a real
  /// account is already signed in — never replaces an authenticated session.
  Future<void> ensureGuestAuth() async {
    if (!_backendUp) return;
    if (_repo.currentUser != null) return;
    await signInAsGuest();
  }

  // ── Guest session (device-local, checklist 07-030) ─────────────────────────
  GuestSession? _guestSession;
  GuestSession? get guestSession => _guestSession;

  /// True while this device holds an approved/requested guest session
  /// (used by the router guard to allow guests into player-live without an
  /// account — checklist 15-014).
  bool get hasGuestSession => _guestSession != null;

  /// Role-safe game copies (§2.3). Non-admin views must never read private
  /// fields; the public surfaces are fed from these projections, never from
  /// the raw game object.
  LiveGame? get tvGame =>
      _currentGame == null ? null : projections.tvProjection(_currentGame!);

  /// The game as a registered non-admin member sees it: payout amounts and
  /// organizer amount removed, chat preserved.
  LiveGame? get playerProjection => _currentGame == null
      ? null
      : projections.playerProjection(_currentGame!, viewerId: _user?.id);

  /// The game as a guest sees it: payout/organizer amounts and chat removed.
  LiveGame? get guestProjection =>
      _currentGame == null ? null : projections.guestProjection(_currentGame!);

  /// The projection matching the current viewer (guest vs registered member).
  LiveGame? get viewerProjection =>
      hasGuestSession ? guestProjection : playerProjection;

  void _saveGuestSession(GuestSession session) {
    _guestSession = session;
    RecoveryService.saveGuestSession(session);
  }

  /// Clears the stored guest session (e.g. the guest was rejected or left).
  void clearGuestSession() {
    _guestSession = null;
    RecoveryService.clearGuestSession();
    notifyListeners();
  }

  /// Assign table + seat numbers to every checked-in player (spec §12.1).
  /// Tables are capped at [effectiveTableSettings.maxPerTable] (configurable
  /// per group, overridable per tournament — defaults to 10); once checked-in
  /// count exceeds that, multiple balanced tables are created automatically.
  /// Every player gets exactly one unique (table, seat) — no duplicates.
  void generateSeating(TableSeatingMode mode) {
    if (!_isGameAuthority) return;
    final game = _currentGame;
    if (game == null) return;

    // Only checked-in, confirmed, non-eliminated participants are seated.
    final seated = game.players
        .where((p) => p.checkedIn && p.confirmed && !p.eliminated)
        .toList();
    if (seated.isEmpty) return;
    _pushUndo();

    // Order players according to the chosen seating mode.
    List<Player> ordered;
    switch (mode) {
      case TableSeatingMode.random:
        ordered = [...seated]..shuffle(Random());
        break;
      case TableSeatingMode.manual:
        ordered = [...seated];
        break;
      case TableSeatingMode.keepGuests:
        // Group each guest next to their inviter so the round-robin deal keeps
        // them on the same table where capacity allows.
        ordered = _orderKeepingGuests(seated, together: true);
        break;
      case TableSeatingMode.separateGuests:
        ordered = _orderKeepingGuests(seated, together: false);
        break;
    }

    // Balanced tables: ceil(count / maxPerTable), distributed as evenly as
    // possible. maxPerTable comes from the tournament's override, or the
    // group's default otherwise (spec: configurable, defaults to 10).
    final maxPerTable = effectiveTableSettings.maxPerTable.clamp(2, 999);
    final count = ordered.length;
    final tableCount = (count / maxPerTable).ceil();
    final perTable = List<int>.filled(tableCount, count ~/ tableCount);
    for (var i = 0; i < count % tableCount; i++) {
      perTable[i]++;
    }

    // Deal round-robin into tables, filling seats 1..n per table.
    final seatCursor = List<int>.filled(tableCount, 0);
    final assignments = <String, ({int table, int seat})>{};
    var idx = 0;
    for (final p in ordered) {
      // Find the next table that still has capacity (round-robin).
      var table = idx % tableCount;
      var guard = 0;
      while (seatCursor[table] >= perTable[table] && guard < tableCount) {
        table = (table + 1) % tableCount;
        guard++;
      }
      seatCursor[table]++;
      assignments[p.id] = (table: table + 1, seat: seatCursor[table]);
      idx++;
    }

    // Random initial dealer position (13-012/13-026) chosen from the seated
    // players. The system does not track dealer-button rotation (13-032).
    final dealer = seated.isEmpty
        ? null
        : seated[Random().nextInt(seated.length)];

    _currentGame = game.copyWith(
      players: game.players.map((p) {
        final a = assignments[p.id];
        return a == null ? p : p.copyWith(table: a.table, seat: a.seat);
      }).toList(),
      dealerPlayerId: dealer?.id,
      // A new draw invalidates any previous confirmation (13-013).
      seatingConfirmed: false,
    );
    // Announce the drawn dealer out loud so the room hears who deals first
    // (checklist 13-026). Falls back quietly if voice is disabled.
    if (dealer != null) {
      addAnnouncement('Seating drawn. ${dealer.name} deals first.', true);
    }
    notifyListeners();
  }

  /// Marks the generated physical seating as confirmed before play starts
  /// (checklist 13-013). Seats remain editable afterwards via the move flow.
  void confirmSeating() {
    final game = _currentGame;
    if (game == null) return;
    if (!_isGameAuthority) {
      if (isAdmin) {
        // Another admin device owns the edit role — don't silently no-op.
        addAnnouncement(
          'Another device is editing this game. Changes here are not saved.',
          false,
        );
      }
      return;
    }
    _currentGame = game.copyWith(seatingConfirmed: true);
    addAnnouncement('Seating confirmed. Shuffle up and deal!', true);
    // Notify each seated participant of their table and seat (Tech §14.3).
    for (final p in game.players.where((p) => p.confirmed && p.table > 0)) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}-${p.id}',
          title: 'Seat assigned',
          body:
              '${game.settings.name} — you are Table ${p.table}, Seat ${p.seat}.',
          type: NotificationType.game,
          link: '/invitation',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
  }

  /// Assigns one player to an explicit (table, seat) — used by Manual seating
  /// (13-002) and validated to prevent duplicate seats (13-021). Clearing the
  /// previous confirmation forces a re-confirm of the physical layout.
  String? assignSeat(String playerId, int table, int seat) {
    final game = _currentGame;
    if (game == null) return null;
    if (table < 1 || seat < 1) return 'Choose a valid table and seat.';
    final occupied = game.players.any(
      (p) =>
          p.id != playerId &&
          p.table == table &&
          p.seat == seat &&
          !p.eliminated,
    );
    if (occupied) return 'That seat is already taken — choose another.';
    _pushUndo();
    _currentGame = game.copyWith(
      players: game.players
          .map(
            (p) => p.id == playerId ? p.copyWith(table: table, seat: seat) : p,
          )
          .toList(),
      seatingConfirmed: false,
    );
    notifyListeners();
    return null;
  }

  /// Detects when tables differ by more than one active player and builds a
  /// recommendation for the administrator (checklist 13-015/13-016/13-017).
  SeatMoveRecommendation? _buildSeatMoveRecommendation() {
    final game = _currentGame;
    if (game == null) return null;
    final seated = game.players.where((p) => p.active && p.table > 0).toList();
    if (seated.length < 2) return null;
    final counts = <int, int>{};
    for (final p in seated) {
      counts[p.table] = (counts[p.table] ?? 0) + 1;
    }
    final tables = counts.keys.toList();
    if (tables.length < 2) return null;

    // Sort tables by player count
    final sortedByCount = tables.toList()
      ..sort((a, b) => counts[a]!.compareTo(counts[b]!));
    final minTable = sortedByCount.first;
    final maxTable = sortedByCount.last;

    final minCount = counts[minTable]!;
    final maxCount = counts[maxTable]!;
    if (maxCount - minCount <= 1) return null;
    // Pick the player with the smallest seat number on the largest table so the
    // recommendation is deterministic and understandable.
    final mover = seated.where((p) => p.table == maxTable).toList()
      ..sort((a, b) => a.seat.compareTo(b.seat));
    final from = mover.first;
    // Find the first free seat on the destination table.
    final taken = seated
        .where((p) => p.table == minTable)
        .map((p) => p.seat)
        .toSet();
    var toSeat = 1;
    while (taken.contains(toSeat)) {
      toSeat++;
    }
    return SeatMoveRecommendation(
      fromPlayerId: from.id,
      fromPlayerName: from.name,
      fromTable: from.table,
      fromSeat: from.seat,
      toTable: minTable,
      toSeat: toSeat,
      reason:
          'Table $maxTable has $maxCount players while Table $minTable has '
          '$minCount. Moving ${from.name} balances the tables.',
    );
  }

  /// Current pending seat-move recommendation, if any (checklist §13.2).
  SeatMoveRecommendation? get seatingRecommendation => _pendingSeatMove;

  bool get hasSeatingImbalance => seatingRecommendation != null;

  /// Asks the engine for a fresh table-balance recommendation. Nothing is
  /// applied — the admin must review and confirm (13-018).
  void requestSeatingBalance() {
    _pendingSeatMove = _buildSeatMoveRecommendation();
    notifyListeners();
  }

  /// Clears the pending recommendation without changing any seats (13-020).
  void dismissSeatMove() {
    if (_pendingSeatMove == null) return;
    _pendingSeatMove = null;
    notifyListeners();
  }

  /// Applies the confirmed recommendation: the player moves, source and
  /// destination seats update consistently (13-018/13-019).
  void confirmSeatMove() {
    if (!_isGameAuthority) return;
    final rec = _pendingSeatMove;
    if (rec == null) return;
    final game = _currentGame;
    if (game == null) return;
    final occupied = game.players.any(
      (p) =>
          p.id != rec.fromPlayerId &&
          p.table == rec.toTable &&
          p.seat == rec.toSeat &&
          !p.eliminated,
    );
    if (occupied) {
      _pendingSeatMove = null;
      notifyListeners();
      return;
    }
    _pushUndo();
    _currentGame = game.copyWith(
      players: game.players
          .map(
            (p) => p.id == rec.fromPlayerId
                ? p.copyWith(table: rec.toTable, seat: rec.toSeat)
                : p,
          )
          .toList(),
      seatingConfirmed: false,
    );
    _pendingSeatMove = null;
    addAnnouncement(
      '${rec.fromPlayerName} moved to Table ${rec.toTable} seat ${rec.toSeat}.',
      true,
    );
    notifyListeners();
  }

  // ── Late registration (checklist §12.3) ────────────────────────────────────

  /// Late registration stays open until the rebuy period ends — the configured
  /// closing level, normally the end of Level 6 (07-039, 12-028, 20-023).
  bool get lateRegistrationOpen {
    final game = _currentGame;
    if (game == null) return false;
    final live =
        game.status == LiveGameStatus.running ||
        game.status == LiveGameStatus.paused;
    return live &&
        !game.settlementConfirmed &&
        game.currentLevel <= game.settings.rebuysCloseLevel;
  }

  /// Adds a registered player during late registration (12-022/12-023).
  /// The late player receives a full fresh starting stack (12-024) and is
  /// assigned to the recommended balanced table and an available seat
  /// (12-025). Totals are recalculated (12-026).
  void addLatePlayer(String name) {
    if (!lateRegistrationOpen) return;
    _pushUndo();
    final game = _currentGame!;
    final id = 'p-${DateTime.now().millisecondsSinceEpoch}';
    final (table: table, seat: seat) = _findAvailableSeat();
    final player = Player(
      id: id,
      name: name.trim(),
      isGuest: false,
      rsvp: null,
      checkedIn: true,
      confirmed: true,
      eliminated: false,
      rebuys: 0,
      hasAddOn: false,
      knockouts: 0,
      table: table,
      seat: seat,
      active: true,
    );
    _currentGame = game.copyWith(
      players: [...game.players, player],
      totalChipsInPlay: game.totalChipsInPlay + game.structure.startingStack,
    );
    // Recalculate prize pool/prizes after money enters the game.
    _updatePrizePool();
    _syncGroupGame();
    addAnnouncement('${player.name} has joined the tournament.', true);
    notifyListeners();
  }

  /// Completely removes a player from the active tournament.
  /// Deducts starting stack, rebuys, and add-ons from total chips.
  /// Recalculates prize pool and distribution.
  void removePlayer(String playerId) {
    if (!_isGameAuthority) return;
    if (_currentGame == null) return;
    _pushUndo();
    final game = _currentGame!;
    final p = game.players.where((pl) => pl.id == playerId).firstOrNull;
    if (p == null) return;

    int chipsToRemove = game.structure.startingStack;
    if (p.rebuys > 0) {
      chipsToRemove += p.rebuys * game.structure.startingStack;
    }
    if (p.hasAddOn) {
      chipsToRemove += game.structure.addOnStack;
    }

    final newPlayers = game.players.where((pl) => pl.id != playerId).toList();

    _currentGame = game.copyWith(
      players: newPlayers,
      totalChipsInPlay: (game.totalChipsInPlay - chipsToRemove).clamp(
        0,
        99999999,
      ),
    );

    _updatePrizePool();
    _syncGroupGame();
    // A removed guest frees their slot: drop the server-side claim lock so
    // the seat can be claimed again (spec §7.1).
    if (p.isGuest && p.inviterId != null && p.guestSlot != null && _backendUp) {
      _repo
          .releaseSlotClaim(game.id, p.inviterId!, p.guestSlot!)
          .catchError((_) {});
    }
    addAnnouncement('${p.name} has been removed from the tournament.', true);
    notifyListeners();
  }

  /// Finds the table with the fewest active players and its first free seat.
  ({int table, int seat}) _findAvailableSeat() {
    final game = _currentGame;
    if (game == null) return (table: 1, seat: 1);
    final seated = game.players.where((p) => p.active && p.table > 0).toList();
    if (seated.isEmpty) return (table: 1, seat: 1);
    final counts = <int, int>{};
    for (final p in seated) {
      counts[p.table] = (counts[p.table] ?? 0) + 1;
    }
    final maxPerTable = effectiveTableSettings.maxPerTable.clamp(2, 999);
    final tableCount =
        (game.activePlayers.length / maxPerTable).ceil().clamp(1, maxPerTable);
    var bestTable = 1;
    var bestCount = 1 << 30;
    for (var t = 1; t <= tableCount; t++) {
      final c = counts[t] ?? 0;
      if (c < maxPerTable && c < bestCount) {
        bestTable = t;
        bestCount = c;
      }
    }
    final taken = seated
        .where((p) => p.table == bestTable)
        .map((p) => p.seat)
        .toSet();
    var seat = 1;
    while (taken.contains(seat)) {
      seat++;
    }
    return (table: bestTable, seat: seat);
  }

  /// Re-computes prizePool, organizerAmount and prize distribution after any
  /// money enters the game (late registration, rebuy, re-entry, add-on).
  ///
  /// This is surgical update on the structure only: it uses
  /// [TournamentStructure.copyWith] to update the three financial fields while
  /// leaving every blind level — including manual edits from StructureEditor —
  /// completely unchanged (fixes checklist 12-026).
  void _updatePrizePool() {
    final game = _currentGame;
    if (game == null) return;

    final s = game.settings;
    final structure = game.structure;

    // Gross eligible = all actual money that entered the game:
    //   confirmed players × buy-in  +  all rebuys × rebuy price
    //   +  all re-entries × buy-in  +  all add-ons × add-on price.
    // Rebuy/add-on prices default to the buy-in unless the admin set a custom
    // price (09-050/12-051, 12-060).
    final confirmedCount = game.players.where((p) => p.confirmed).length;
    final totalRebuys = game.players.fold<int>(0, (sum, p) => sum + p.rebuys);
    final totalReEntries = game.players.fold<int>(
      0,
      (sum, p) => sum + p.reEntries,
    );
    final totalAddOns = game.players.where((p) => p.hasAddOn).length;

    final koTotal = s.koEnabled ? (confirmedCount + totalReEntries) * s.koAmount : 0;
    
    final grossEligible =
        (confirmedCount * s.buyIn) +
        (totalRebuys * s.effectiveRebuyCost) +
        (totalReEntries * s.buyIn) +
        (totalAddOns * (s.addOn ? s.effectiveAddOnCost : 0)) -
        koTotal;

    // Delegate the organizer-cut and prize-split maths to the shared helper in
    // TournamentEngine so the rules stay consistent everywhere.
    final int roundingUnit = TournamentEngine.roundingUnitFor(s.buyIn);

    final recalculated = TournamentEngine.recalculatePrizes(
      grossEligible,
      confirmedCount,
      s.organizerPct.toDouble(),
      forcePaidPlaces: s.forcePaidPlaces,
      roundingUnit: roundingUnit,
    );

    // Patch only the financial fields; levels and all other structure data
    // remain exactly as they were (including any StructureEditor overrides).
    _currentGame = game.copyWith(
      structure: structure.copyWith(
        prizePool: recalculated.prizePool,
        organizerAmount: recalculated.organizerAmount,
        prizes: recalculated.prizes,
      ),
    );
  }

  /// Manually overrides the number of paid places and recalculates prizes.
  void overridePaidPlaces(int? count) {
    if (!_isGameAuthority) return;
    if (_currentGame == null) return;
    _pushUndo();
    _currentGame = _currentGame!.copyWith(
      settings: _currentGame!.settings.copyWith(forcePaidPlaces: count),
    );
    _updatePrizePool();
    addAuditRecord(
      'structure_edit',
      'Paid places overridden to ${count ?? 'auto'}',
    );
    notifyListeners();
  }

  /// Orders players so guests are placed immediately after (together) or far
  /// from (separate) their inviter, used to steer the round-robin deal.
  List<Player> _orderKeepingGuests(
    List<Player> players, {
    required bool together,
  }) {
    final registered = players.where((p) => !p.isGuest).toList();
    final guests = players.where((p) => p.isGuest).toList();
    if (together) {
      final result = <Player>[];
      for (final r in registered) {
        result.add(r);
        result.addAll(guests.where((g) => g.inviterId == r.id));
      }
      // Any guest whose inviter isn't seated still gets placed.
      result.addAll(
        guests.where((g) => !registered.any((r) => r.id == g.inviterId)),
      );
      return result;
    }
    // Separate: interleave registered and guests so inviter/guest land apart.
    final result = <Player>[];
    final maxLen = registered.length > guests.length
        ? registered.length
        : guests.length;
    for (var i = 0; i < maxLen; i++) {
      if (i < registered.length) result.add(registered[i]);
      if (i < guests.length) result.add(guests[i]);
    }
    return result;
  }

  void acceptSpeedRecommendation({SpeedRecommendation? rec}) {
    if (!_isGameAuthority) return;
    final game = _currentGame;
    if (game == null) return;
    final recommendation = rec ?? game.speedRecommendation;
    if (recommendation == null) return;
    _pushUndo();
    final structure = game.structure;
    final isSpeedUp = recommendation == SpeedRecommendation.speedUp;
    final newDuration = isSpeedUp
        ? structure.levelDuration - 5
        : structure.levelDuration + 5;
    final clamped = newDuration < 10
        ? 10
        : (newDuration > 20 ? 20 : newDuration);

    final pastLevels = structure.levels.where((l) => l.level <= game.currentLevel).toList();
    var futureLevels = structure.levels.where((l) => l.level > game.currentLevel).toList();

    if (futureLevels.isNotEmpty) {
      final chips = game.settings.chipSet;

      if (isSpeedUp) {
        // 1. Advance ante
        int? firstAnteIdx;
        for (var i = 0; i < futureLevels.length; i++) {
          if (futureLevels[i].ante != null) {
            firstAnteIdx = i;
            break;
          }
        }
        if (firstAnteIdx != null && firstAnteIdx > 0) {
          final moveUp = firstAnteIdx > 1 ? 2 : 1;
          final anteVal = futureLevels[firstAnteIdx].ante;
          futureLevels[firstAnteIdx - moveUp] = BlindLevel(
            level: futureLevels[firstAnteIdx - moveUp].level,
            sb: futureLevels[firstAnteIdx - moveUp].sb,
            bb: futureLevels[firstAnteIdx - moveUp].bb,
            ante: anteVal,
            durationMins: clamped,
          );
        }

        // 2. Increase future blinds (steepen curve)
        futureLevels = futureLevels.map((l) {
          final newBB = TournamentEngine.snapToPracticalBlind(l.bb * 1.25, chips);
          final newSB = TournamentEngine.snapToPracticalBlind(newBB / 2, chips);
          return BlindLevel(
            level: l.level,
            sb: newSB,
            bb: newBB,
            ante: l.ante,
            durationMins: clamped,
          );
        }).toList();
      } else {
        // Slow down
        // 1. Delay ante
        int? firstAnteIdx;
        for (var i = 0; i < futureLevels.length; i++) {
          if (futureLevels[i].ante != null) {
            firstAnteIdx = i;
            break;
          }
        }
        if (firstAnteIdx != null && firstAnteIdx < futureLevels.length - 1) {
          futureLevels[firstAnteIdx] = BlindLevel(
            level: futureLevels[firstAnteIdx].level,
            sb: futureLevels[firstAnteIdx].sb,
            bb: futureLevels[firstAnteIdx].bb,
            ante: null,
            durationMins: clamped,
          );
        }

        // 2. Insert intermediate level if steep jump exists
        bool inserted = false;
        final newFuture = <BlindLevel>[];
        for (var i = 0; i < futureLevels.length; i++) {
          final current = futureLevels[i];
          newFuture.add(BlindLevel(
            level: current.level,
            sb: current.sb,
            bb: current.bb,
            ante: current.ante,
            durationMins: clamped,
          ));
          if (!inserted && i < futureLevels.length - 1) {
            final next = futureLevels[i + 1];
            if (next.bb >= current.bb * 2) {
              final midBB = TournamentEngine.snapToPracticalBlind(current.bb * 1.5, chips);
              final midSB = TournamentEngine.snapToPracticalBlind(midBB / 2, chips);
              newFuture.add(BlindLevel(
                level: 0, // will re-index later
                sb: midSB,
                bb: midBB,
                ante: current.ante,
                durationMins: clamped,
              ));
              inserted = true;
            }
          }
        }
        futureLevels = newFuture;
      }
    }

    // Re-index all levels sequentially to ensure no gaps
    final allLevels = [...pastLevels, ...futureLevels];
    for (var i = 0; i < allLevels.length; i++) {
      final l = allLevels[i];
      allLevels[i] = BlindLevel(
        level: i + 1,
        sb: l.sb,
        bb: l.bb,
        ante: l.ante,
        durationMins: l.level > game.currentLevel ? clamped : l.durationMins,
      );
    }

    _currentGame = game.copyWith(
      speedRecommendation: null,
      structure: structure.copyWith(
        levelDuration: clamped,
        levels: allLevels,
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  TournamentStructure _structureWithLevels(
    TournamentStructure s,
    List<BlindLevel> levels,
  ) {
    return TournamentStructure(
      startingStack: s.startingStack,
      chipPlan: s.chipPlan,
      rebuyStack: s.rebuyStack,
      rebuyChipPlan: s.rebuyChipPlan,
      addOnStack: s.addOnStack,
      addOnChipPlan: s.addOnChipPlan,
      levels: levels,
      levelDuration: s.levelDuration,
      expectedFinishMins: s.expectedFinishMins,
      prizes: s.prizes,
      prizePool: s.prizePool,
      organizerAmount: s.organizerAmount,
      colorUpInstructions: s.colorUpInstructions,
      warnings: s.warnings,
    );
  }

  /// Regenerates the whole structure for the actual confirmed attendance
  /// (checklist 09-003 / 22-006: the engine always regenerates rather than
  /// reusing a fixed template). Keeps the current level and resets its clock.
  /// Total expected attendance taken from RSVPs: every "Going" answer counts
  /// the member plus their guest slots (Going +2 = 3 people). Falls back to
  /// the group roster when nobody has answered yet.
  int expectedPlayersFromRsvps(LiveGame game) {
    var total = 0;
    for (final p in game.players) {
      if (!p.isGuest && p.rsvp != null && p.rsvp!.isGoing) {
        total += 1 + p.rsvp!.guestCount;
      }
    }
    return total >= 2 ? total : game.players.where((p) => !p.isGuest).length;
  }

  /// Admin has reviewed the generated structure (30-minute estimate).
  void confirmStructure() {
    if (!_isGameAuthority) return;
    final game = _currentGame;
    if (game == null) return;
    _currentGame = game.copyWith(structureConfirmed: true);
    addAuditRecord(
      'structure_confirm',
      'Structure confirmed: stack ${game.structure.startingStack}, '
          '${game.structure.levels.length} levels of ${game.structure.levelDuration}m.',
    );
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Structure ready',
        body: '${_currentGame!.settings.name} - final structure has been generated and locked.',
        type: NotificationType.game,
        link: '/structure-review',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  /// Generates (or regenerates) the structure estimate from the inputs the
  /// admin provided plus the current expected attendance. Only allowed once
  /// the 30-minute pre-start window is open (client rule: the structure is
  /// reviewed ~30 minutes before the game, while people are still deciding
  /// whether to attend).
  /// C1: Admin-Triggered Final Structure Generation at Check-in
  void generateFinalStructure(int confirmedCount, {bool force = false}) {
    final game = _currentGame;
    if (game == null) return;
    _pushUndo();
    // Check-in opens with nobody checked in yet, so `confirmedCount` is 0 at
    // that moment. A 0-player structure is meaningless (and used to divide by
    // zero inside the chip planner). Fall back to the expected head-count from
    // RSVPs, then to the configured field size, and never below a two-handed
    // game.
    final expected = confirmedCount > 0
        ? confirmedCount
        : (game.goingWithGuestsCount > 0
            ? game.goingWithGuestsCount
            : game.settings.players);
    final count = expected < 2 ? 2 : expected;
    final s = game.settings.copyWith(players: count);
    final structure = TournamentEngine.generate(
      TournamentParams(
        players: count,
        durationHours: s.durationHours,
        buyIn: s.buyIn,
        chipSet: s.chipSet,
        rebuys: s.rebuys,
        rebuysCloseLevel: s.rebuysCloseLevel,
        reEntry: s.reEntry,
        addOn: s.addOn,
        anteEnabled: s.anteEnabled,
        anteAfterLevel: s.anteAfterLevel,
        anteStyle: s.anteStyle,
        koEnabled: s.koEnabled,
        koAmount: s.koAmount,
        organizerPct: s.organizerPct,
        rebuyCost: s.rebuyCost,
        addOnCost: s.addOnCost,
      ),
    );
    _currentGame = game.copyWith(
      settings: s,
      structure: structure,
      originalLevels: List.of(structure.levels),
      totalChipsInPlay: structure.startingStack * count,
      currentLevel: 1,
      secondsRemaining: structure.levelDuration * 60,
      structureConfirmed: false,
    );
    addAuditRecord(
      'structure_estimate',
      'AI generated the structure estimate for $count expected players.',
    );
    notifyListeners();
  }

  void recalculateStructure() {
    final game = _currentGame;
    if (game == null) return;
    _pushUndo();

    final confirmed = game.players.where((p) => p.confirmed).length;
    final count = confirmed >= 2 ? confirmed : expectedPlayersFromRsvps(game);
    _recalculateWithPlayers(count);
  }

  void updateStructurePlayerCount(int players) {
    final game = _currentGame;
    if (game == null) return;
    _pushUndo();
    _recalculateWithPlayers(players);
  }

  void _recalculateWithPlayers(int count) {
    final game = _currentGame!;
    final s = game.settings;
    final newSettings = s.copyWith(players: count);
    var structure = TournamentEngine.generate(
      TournamentParams(
        players: count,
        durationHours: newSettings.durationHours,
        buyIn: newSettings.buyIn,
        chipSet: newSettings.chipSet,
        rebuys: newSettings.rebuys,
        rebuysCloseLevel: newSettings.rebuysCloseLevel,
        reEntry: newSettings.reEntry,
        addOn: newSettings.addOn,
        anteEnabled: newSettings.anteEnabled,
        anteAfterLevel: newSettings.anteAfterLevel,
        anteStyle: newSettings.anteStyle,
        koEnabled: newSettings.koEnabled,
        koAmount: newSettings.koAmount,
        organizerPct: newSettings.organizerPct,
        rebuyCost: newSettings.rebuyCost,
        addOnCost: newSettings.addOnCost,
      ),
    );
    // Once play has started the starting stacks are frozen — blinds, levels
    // and the player count may still change (client rule).
    if (game.stacksLocked) {
      structure = structure.copyWith(
        startingStack: game.structure.startingStack,
        chipPlan: game.structure.chipPlan,
        rebuyStack: game.structure.rebuyStack,
        rebuyChipPlan: game.structure.rebuyChipPlan,
        addOnStack: game.structure.addOnStack,
        addOnChipPlan: game.structure.addOnChipPlan,
      );
    }

    final newLevel = game.currentLevel.clamp(1, structure.levels.length);
    _currentGame = game.copyWith(
      settings: newSettings,
      structure: structure,
      currentLevel: newLevel,
      secondsRemaining: structure.levels[newLevel - 1].durationMins * 60,
      speedRecommendation: null,
      clearSpeedRecommendation: true,
    );
    addAnnouncement(
      'Structure recalculated for $count confirmed player${count != 1 ? 's' : ''}.',
      true,
    );
  }



  /// Applies admin edits to future levels (the structure editor modal).
  /// The active and already-finished levels are left untouched.
  /// Shared validation for blind-level durations (allowed: 10/15/20 min).
  /// Returns null when valid, otherwise the rejection message.
  String? _validateLevelDuration(int durationMins) {
    if (durationMins != 10 && durationMins != 15 && durationMins != 20) {
      return 'Level duration must be 10, 15 or 20 minutes.';
    }
    return null;
  }

  void applyLevelEdits(List<LevelEdit> edits) {
    final game = _currentGame;
    if (game == null || edits.isEmpty) return;
    for (final e in edits) {
      if (_validateLevelDuration(e.durationMins) != null ||
          e.sb <= 0 ||
          e.bb <= e.sb) {
        return;
      }
    }
    _pushUndo();
    final byLevel = {for (final e in edits) e.level: e};
    final levels = game.structure.levels.map((l) {
      final e = byLevel[l.level];
      if (e == null) return l;
      return BlindLevel(
        level: l.level,
        sb: e.sb,
        bb: e.bb,
        ante: e.ante,
        durationMins: e.durationMins,
      );
    }).toList();
    _currentGame = game.copyWith(
      structure: _structureWithLevels(game.structure, levels),
    );
    addAnnouncement('Level structure updated by admin.', false);
  }

  /// Replaces the future levels (everything from the current level onward)
  /// with a renumbered list produced by the structure editor. Inserting or
  /// removing levels is supported because the whole future segment is swapped,
  /// not patched by level number (checklist §12.4).
  void applyFutureLevels(List<BlindLevel> futureLevels) {
    final game = _currentGame;
    if (game == null || futureLevels.isEmpty) return;
    for (final l in futureLevels) {
      if (_validateLevelDuration(l.durationMins) != null ||
          l.sb <= 0 ||
          l.bb <= l.sb) {
        return;
      }
    }
    _pushUndo();
    // Keep all completed levels PLUS the currently active level.
    final prefix = game.structure.levels.take(game.currentLevel).toList();
    // Renumber sequentially so inserting a level shifts the rest correctly.
    var n = game.currentLevel + 1;
    final renumbered = [
      for (final l in futureLevels)
        BlindLevel(
          level: n++,
          sb: l.sb,
          bb: l.bb,
          ante: l.ante,
          durationMins: l.durationMins,
        ),
    ];
    final levels = [...prefix, ...renumbered];
    _currentGame = game.copyWith(
      structure: _structureWithLevels(game.structure, levels),
      secondsRemaining: game.secondsRemaining,
    );
    addAuditRecord(
      'structure_edit',
      'Future levels updated: ${renumbered.length} future level'
          '${renumbered.length == 1 ? '' : 's'} (was ${(game.structure.levels.length - prefix.length).clamp(0, 999)})',
    );
    addAnnouncement('Level structure updated by admin.', false);
  }

  /// Inserts one intermediate future level directly after [afterLevel]
  /// (Tech Spec §8.6 permitted slow-down action; User Flow §4.14 "An
  /// intermediate future blind level may be inserted"). Subsequent levels are
  /// renumbered with a +1 shift; completed and active levels stay immutable
  /// (spec §12.4/§8.6), so [afterLevel] must be >= the current level.
  ///
  /// Validation: game must exist, durationMins must be one of the allowed
  /// 10/15/20 minute values, bb > sb > 0 and ante >= 0. Monotonic blind
  /// progression across neighbours is left to the admin's responsibility.
  ///
  /// Returns a validation message when the insert was rejected, or null on
  /// success. Undoable via [_pushUndo]; audited as 'structure_insert_level'.
  String? insertFutureLevel(
    int afterLevel,
    int sb,
    int bb,
    int? ante,
    int durationMins,
  ) {
    final game = _currentGame;
    if (game == null) return 'No active game.';
    if (afterLevel < game.currentLevel) {
      return 'Completed and active levels cannot be changed.';
    }
    final durationProblem = _validateLevelDuration(durationMins);
    if (durationProblem != null) return durationProblem;
    if (sb <= 0 || bb <= sb) {
      return 'Blinds must increase — small blind first, then big blind.';
    }
    if (ante != null && ante < 0) return 'Ante cannot be negative.';
    _pushUndo();
    final inserted = BlindLevel(
      level: afterLevel + 1,
      sb: sb,
      bb: bb,
      ante: ante,
      durationMins: durationMins,
    );
    final levels = <BlindLevel>[];
    var appended = false;
    for (final l in game.structure.levels) {
      final shifted = BlindLevel(
        level: l.level >= afterLevel + 1 ? l.level + 1 : l.level,
        sb: l.sb,
        bb: l.bb,
        ante: l.ante,
        durationMins: l.durationMins,
      );
      levels.add(shifted);
      if (l.level == afterLevel) {
        levels.add(inserted);
        appended = true;
      }
    }
    // Appending below the current last level: no anchor row exists.
    if (!appended) levels.add(inserted);
    _currentGame = game.copyWith(
      structure: _structureWithLevels(game.structure, levels),
    );
    addAuditRecord(
      'structure_insert_level',
      'Inserted level ${inserted.level}: '
          '$sb/$bb${ante != null ? ' ante $ante' : ''}, $durationMins min.',
    );
    addAnnouncement(
      'Level ${inserted.level} inserted ($sb/$bb, $durationMins min).',
      false,
    );
    return null;
  }

  void confirmFinalTable({
    List<({String playerId, int seat})>? seating,
    String? dealerId,
  }) {
    final finalists = _currentGame!.players
        .where((p) => p.active && !p.eliminated)
        .toList();
    // The final table seats at most 9 players (checklist 13-025).
    if (finalists.length > 9) return;
    // Guard against re-entrant redraws: the seats and dealer were already
    // drawn on a previous confirm (e.g. a stale tap racing a state change),
    // so refuse to re-randomize the table/dealer.
    if (_currentGame!.finalTableRedrawCompleted) return;
    _pushUndo();
    final players = seating == null
        ? _currentGame!.players
        : _currentGame!.players.map((p) {
            for (final s in seating) {
              if (s.playerId == p.id) {
                return p.copyWith(seat: s.seat, table: 1);
              }
            }
            return p;
          }).toList();
    // Initial dealer for the final table: the admin's choice, or a random
    // finalist (Tech spec §12.3 — the redraw picks the seats AND the
    // initial dealer-button position).
    final dealer =
        (dealerId != null
            ? finalists.where((f) => f.id == dealerId).firstOrNull
            : null) ??
        (finalists.isEmpty
            ? null
            : finalists[Random().nextInt(finalists.length)]);
    final currentLevelData = _currentGame!.currentLevelData;
    final durationMins =
        currentLevelData?.durationMins ?? _currentGame!.structure.levelDuration;
    _currentGame = _currentGame!.copyWith(
      players: players,
      status: LiveGameStatus.running,
      timerRunning: true,
      finalTableRedrawCompleted: true,
      dealerPlayerId: dealer?.id,
      // The paused level is over — restart the clock for the current level.
      // Uses the server-calibrated clock (like every other timer reset) so the
      // countdown stays in sync across all connected devices.
      secondsRemaining: durationMins * 60,
      levelEndTime: _serverNow.add(Duration(minutes: durationMins)),
    );
    addAnnouncement('Final table! Please take your new seats.', true);
    if (dealer != null) {
      addAnnouncement('Dealer on the final table: ${dealer.name}.', true);
    }
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Final table reached',
        body:
            '${_currentGame!.settings.name} — 9 players remain, seats redrawn.',
        type: NotificationType.game,
        link: '/player-live',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
  }

  /// Validation message explaining why completion was refused (User Flow
  /// §4.17 "System validates that every paid position has one player"). Set
  /// by [recordFinishOrder] when the recorded finish order fails
  /// [validateCompletion]; cleared again on the next attempt.
  String? _completionError;
  String? get completionError => _completionError;

  /// Validates that the tournament can be completed cleanly (User Flow
  /// §4.17). Returns an error message, or null when everything checks out:
  ///
  /// - every eliminated player carries a finish position,
  /// - no two players share the same finishing position,
  /// - every paid place defined by structure.prizes (places 1..N) is
  ///   assigned to exactly one player,
  /// - a winner exists (place 1).
  ///
  /// Evaluated prospectively from the current state, so it can be called
  /// before [recordFinishOrder] commits anything.
  String? validateCompletion() {
    final game = _currentGame;
    if (game == null) return 'No active game.';
    final eliminated = game.players.where((p) => p.eliminated).toList()
      ..sort(
        (a, b) => (b.eliminationPos ?? 0).compareTo(a.eliminationPos ?? 0),
      );
    final prospectiveOrder = [
      ...eliminated.map((p) => p.id),
      ...game.activePlayers.map((p) => p.id),
    ];
    return _validateCompletionState(game, prospectiveOrder);
  }

  /// Shared §4.17 validator over an explicit finish order (first-out first).
  String? _validateCompletionState(LiveGame game, List<String> order) {
    final unpositioned = game.players
        .where((p) => p.eliminated && p.eliminationPos == null)
        .length;
    if (unpositioned > 0) {
      return '$unpositioned eliminated player'
          '${unpositioned == 1 ? ' has' : 's have'} no recorded finish position.';
    }
    final placeHolders = <int, String>{};
    for (final p in game.players.where((p) => p.eliminated)) {
      final clash = placeHolders[p.eliminationPos!];
      if (clash != null) {
        return 'Players $clash and ${p.name} both hold place '
            '${p.eliminationPos}.';
      }
      placeHolders[p.eliminationPos!] = p.id;
    }
    final activeCount = game.activePlayers.length;
    var survivorRank = 0;
    final seen = <String>{};
    for (final id in order) {
      if (!seen.add(id)) continue;
      final p = game.players.where((x) => x.id == id).firstOrNull;
      if (p == null || p.eliminated) continue;
      survivorRank++;
      final pos = activeCount - survivorRank + 1;
      final clash = placeHolders[pos];
      if (clash != null && clash != id) {
        return 'Two players are recorded for place $pos.';
      }
      placeHolders[pos] = id;
    }
    final paidPlaces = game.structure.prizes.isEmpty
        ? activeCount
        : game.structure.prizes.length;
    for (var place = 1; place <= min(paidPlaces, activeCount); place++) {
      if (!placeHolders.containsKey(place)) {
        return 'Paid place $place has no player assigned.';
      }
    }
    return null;
  }

  /// Updates the payout prizes (for custom deals/chops before finalizing results).
  void updatePrizes(List<Prize> customPrizes) {
    if (!_isGameAuthority) return;
    if (_currentGame == null) return;
    _pushUndo();
    _currentGame = _currentGame!.copyWith(
      structure: _currentGame!.structure.copyWith(
        prizes: customPrizes,
      ),
    );
    _syncGroupGame();
    notifyListeners();
  }

  bool recordFinishOrder(List<String> order) {
    final game = _currentGame;
    if (game == null) return false;
    final error = _validateCompletionState(game, order);
    if (error != null) {
      _completionError = error;
      addAnnouncement(error, false);
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Incomplete results warning',
          body: 'Cannot end tournament: $error',
          type: NotificationType.system,
          link: '/result-podium',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
      notifyListeners();
      return false;
    }
    _completionError = null;
    _pushUndo();
    _currentGame = _currentGame!.copyWith(
      finishOrder: order,
      status: LiveGameStatus.completed,
      timerRunning: false,
    );
    _syncGroupGame();
    // This device settled the game — write my own result now (other members'
    // devices record theirs when the completed doc reaches them).
    if (_backendUp) {
      _maybeRecordOwnResult(_currentGame!);
    } else {
      // Offline fallback: aggregate locally so stats still move in demo mode.
      _recordOwnResultOffline(_currentGame!);
    }
    addAnnouncement('We have a winner!', true);
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'Tournament finished',
        body: '${_currentGame!.settings.name} is over — see the final results.',
        type: NotificationType.result,
        link: '/result-podium',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    return true;
  }

  void addAnnouncement(String text, [bool speakOutLoud = true]) {
    final announcement = Announcement(
      id: 'ann-${DateTime.now().millisecondsSinceEpoch}',
      text: text,
      timestamp: DateTime.now(),
    );
    _currentGame = _currentGame!.copyWith(
      announcements: [..._currentGame!.announcements, announcement],
    );
    // Speak key tournament announcements when the admin has enabled voice
    // and this device is the Audio Master (checklist §15.4). Failure is
    // swallowed by VoiceService (15-054).
    if (speakOutLoud && _voiceEnabled && thisDeviceIsAudioMaster) {
      VoiceService.instance.speak(text);
    }
    notifyListeners();
  }

  /// Appends a new audit record to the history. This history is never deleted.
  void addAuditRecord(String type, String details) {
    if (_currentGame == null || _user == null) return;
    final record = AuditRecord(
      id: 'audit-${DateTime.now().millisecondsSinceEpoch}',
      timestamp: DateTime.now(),
      type: type,
      actor: _user!.name,
      details: details,
    );
    _currentGame = _currentGame!.copyWith(
      auditHistory: [..._currentGame!.auditHistory, record],
    );
    notifyListeners();
  }

  // ── Chat & polls ───────────────────────────────────────────────────────────
  /// Maximum message length (checklist 08-009).
  static const int maxChatMessageLength = 1000;

  /// Basic spam rate limit (tech spec §14.1): at most
  /// [_chatBurstLimit] messages per sliding [_chatBurstWindow].
  static const int _chatBurstLimit = 8;
  static const Duration _chatBurstWindow = Duration(seconds: 30);
  final Map<String, List<DateTime>> _chatSendTimes = <String, List<DateTime>>{};

  /// True when [userId] has exceeded the chat burst limit right now.
  bool _chatRateLimited(String userId) {
    final now = DateTime.now();
    final times = _chatSendTimes.putIfAbsent(userId, () => <DateTime>[]);
    times.removeWhere((t) => now.difference(t) > _chatBurstWindow);
    return times.length >= _chatBurstLimit;
  }

  void _recordChatSend(String userId) {
    _chatSendTimes.putIfAbsent(userId, () => <DateTime>[]).add(DateTime.now());
  }

  // ── Chat unread tracking (Tech Spec §14.1) ────────────────────────────────
  /// Last-read timestamp per chat scope key. Scope keys are `group:<gid>`
  /// for the group hub chat and `game:<gid>` for a live game's chat.
  final Map<String, DateTime> _chatLastRead = {};

  /// Marks an entire chat scope as read up to now so its unread counter
  /// resets. Callers (chat sheet / group hub screens) invoke this when the
  /// conversation becomes visible.
  void markChatRead(String scopeKey) {
    _chatLastRead[scopeKey] = DateTime.now();
    notifyListeners();
  }

  /// Unread count over one chat list: non-deleted messages authored by
  /// someone else, posted after the scope's last-read timestamp.
  int _unreadChatCount(String scopeKey, List<ChatMessage> messages) {
    final uid = _user?.id;
    if (uid == null) return 0;
    final lastRead = _chatLastRead[scopeKey];
    var count = 0;
    for (final m in messages) {
      if (m.deleted || m.authorId == uid) continue;
      if (lastRead != null && !m.timestamp.isAfter(lastRead)) continue;
      count++;
    }
    return count;
  }

  /// Number of unread group-chat messages for group [gid] (Tech Spec §14.1).
  int unreadGroupChatCount(String gid) =>
      _unreadChatCount('group:$gid', _currentGroup.chat);

  /// Number of unread messages in game [gid]'s chat (Tech Spec §14.1). Reads
  /// the current live game when it matches, otherwise the mirrored copy kept
  /// on the group bundle.
  int unreadGameChatCount(String gid) =>
      _unreadChatCount('game:$gid', gameChatMessages(gid));

  /// Sends a chat message. Returns a validation message when the message
  /// cannot be sent (empty, too long or rate limited), or null on success.
  String? sendChatMessage(String? gameId, String body) {
    if (_user == null) return null;
    // Spec §22: sanitize input before processing.
    final sanitized = Sanitization.sanitizeChat(body);
    if (sanitized.isEmpty) return 'Message cannot be empty.';
    if (sanitized.length > maxChatMessageLength) {
      return 'Message is too long — maximum $maxChatMessageLength characters.';
    }
    if (_chatRateLimited(_user!.id)) {
      return 'You are sending messages too quickly — wait a moment and try again.';
    }
    _recordChatSend(_user!.id);
    final isGameChat = gameId != null && _currentGame?.id == gameId;
    final msg = ChatMessage(
      id: 'msg-${DateTime.now().millisecondsSinceEpoch}',
      authorId: _user!.id,
      authorName: _user!.name,
      body: sanitized,
      timestamp: DateTime.now(),
      deleted: false,
      gameId: isGameChat ? gameId : null,
    );
    if (isGameChat) {
      final ctx = _cloudGameContext;
      if (_backendUp && ctx != null) {
        // Per-game chat is its own subcollection the host and every member may
        // append to directly — no game-doc write (members are forbidden the
        // `chat` field) and no projection round-trip, so the message stays put.
        _gameChatMessages = [..._gameChatMessages, msg];
        unawaited(_repo
            .sendGameChatMessage(ctx.$1, ctx.$2, msg)
            .catchError((Object e) => debugPrint('sendGameChat failed: $e')));
      } else {
        // Offline / mock mode — keep it on the local game model.
        _currentGame = _currentGame!.copyWith(chat: [..._currentGame!.chat, msg]);
      }
    } else {
      _setGroup(_currentGroup.copyWith(chat: [..._currentGroup.chat, msg]));
      _postGroupChat(msg);
    }
    
    // Fan out a push notification for this chat message (UAT 12-108/13-059).
    // The sender is excluded inside _fanOutPush so they don't banner themselves.
    pushNotification(
      AppNotification(
        id: 'chat-${msg.id}',
        title: isGameChat 
            ? 'Game Chat: ${_currentGame?.settings.name ?? 'Live Game'}' 
            : 'Group Chat: ${_currentGroup.name}',
        body: '${_user!.name}: $sanitized',
        timestamp: DateTime.now(),
        type: NotificationType.chat,
        link: isGameChat ? '/game/$gameId' : '/group?tab=chat',
        read: false,
      ),
    );

    notifyListeners();
    return null;
  }

  /// Every visible message for a game's chat: the per-game chat subcollection
  /// merged with any pinned/system cards carried on the game document, sorted
  /// oldest-first so the chat view reads top-to-bottom.
  List<ChatMessage> gameChatMessages(String gameId) {
    final LiveGame? base = _currentGame?.id == gameId
        ? _currentGame
        : _currentGroup.games.where((g) => g.id == gameId).firstOrNull;
    final byId = <String, ChatMessage>{};
    for (final m in base?.chat ?? const <ChatMessage>[]) {
      byId[m.id] = m;
    }
    for (final m in _gameChatMessages) {
      byId[m.id] = m;
    }
    final list = byId.values.toList()
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return list;
  }

  /// Persists a group-chat message to `groups/{gid}/chat` (fire-and-forget).
  void _postGroupChat(ChatMessage msg) {
    if (!_backendUp || _currentGroupId == null) return;
    unawaited(_repo
        .sendGroupChatMessage(_currentGroupId!, msg)
        .catchError((Object e) => debugPrint('sendGroupChat failed: $e')));
  }

  /// Persists a poll create/update to `groups/{gid}/polls` (fire-and-forget).
  void _persistPoll(Poll poll) {
    if (!_backendUp || _currentGroupId == null) return;
    unawaited(_repo
        .savePoll(_currentGroupId!, poll)
        .catchError((Object e) => debugPrint('savePoll failed: $e')));
  }

  void deleteMessage(String msgId) {
    final inGameChat = _gameChatMessages.any((m) => m.id == msgId);
    _setGroup(
      _currentGroup.copyWith(
        chat: _currentGroup.chat
            .map((m) => m.id == msgId ? m.copyWith(deleted: true) : m)
            .toList(),
      ),
    );
    final game = _currentGame;
    if (game != null) {
      _currentGame = game.copyWith(
        chat: game.chat
            .map((m) => m.id == msgId ? m.copyWith(deleted: true) : m)
            .toList(),
      );
    }
    if (inGameChat) {
      _gameChatMessages = _gameChatMessages
          .map((m) => m.id == msgId ? m.copyWith(deleted: true) : m)
          .toList();
    }
    notifyListeners();
    if (!_backendUp) return;
    final ctx = _cloudGameContext;
    if (inGameChat && ctx != null) {
      unawaited(_repo
          .markGameChatMessageDeleted(ctx.$1, ctx.$2, msgId)
          .catchError((Object e) => debugPrint('deleteGameChat failed: $e')));
      return;
    }
    if (_currentGroupId != null) {
      unawaited(_repo
          .markChatMessageDeleted(_currentGroupId!, msgId)
          .catchError((Object e) => debugPrint('deleteMessage failed: $e')));
    }
  }

  /// Creates a poll. Returns a validation message when the question or options
  /// are invalid (empty or duplicate options rejected — checklist 08-015/08-016),
  /// or null on success.
  String? createPoll(
    String question,
    List<String> options, {
    bool multi = false,
  }) {
    // Spec §22: sanitize all poll input.
    final trimmedQuestion = Sanitization.sanitizePollQuestion(question);
    final trimmed = options
        .map((o) => Sanitization.sanitizePollOption(o))
        .where((o) => o.isNotEmpty)
        .toList();
    if (trimmedQuestion.isEmpty) return 'Poll needs a question.';
    if (trimmed.length < 2) return 'Poll needs at least two options.';
    if (trimmed.length > 10) return 'Polls support at most ten options.';
    final unique = <String>{};
    for (final o in trimmed) {
      if (!unique.add(o.toLowerCase())) {
        return 'Duplicate options are not allowed.';
      }
    }
    final poll = Poll(
      id: 'poll-${DateTime.now().millisecondsSinceEpoch}',
      question: trimmedQuestion,
      options: trimmed,
      votes: const {},
      closed: false,
      createdAt: DateTime.now(),
      multi: multi,
    );
    _setGroup(_currentGroup.copyWith(polls: [..._currentGroup.polls, poll]));
    _persistPoll(poll);
    pushNotification(
      AppNotification(
        id: 'n-${DateTime.now().millisecondsSinceEpoch}',
        title: 'New poll',
        body: trimmedQuestion,
        type: NotificationType.admin,
        link: '/group',
        read: false,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
    return null;
  }

  /// Records a vote. For single-choice polls [selected] holds one option;
  /// for multi-choice polls it holds every option the member ticked.
  void votePoll(String pollId, List<String> selected) {
    final userId = _user?.id;
    if (userId == null) return;
    Poll? updated;
    _setGroup(
      _currentGroup.copyWith(
        polls: _currentGroup.polls.map((p) {
          if (p.id != pollId || p.closed) return p;
          final kept = p.multi
              ? selected
              : selected.isNotEmpty
              ? [selected.first]
              : <String>[];
          final newVotes = Map<String, List<String>>.from(p.votes);
          if (kept.isEmpty) {
            newVotes.remove(userId);
          } else {
            newVotes[userId] = kept;
          }
          updated = Poll(
            id: p.id,
            question: p.question,
            options: p.options,
            votes: newVotes,
            closed: p.closed,
            createdAt: p.createdAt,
            multi: p.multi,
          );
          return updated!;
        }).toList(),
      ),
    );
    if (updated != null) _persistPoll(updated!);
    notifyListeners();
  }

  /// Admin closes a poll so it no longer accepts votes (checklist 08-022/08-023).
  void closePoll(String pollId) {
    Poll? closedPoll;
    _setGroup(
      _currentGroup.copyWith(
        polls: _currentGroup.polls
            .map(
              (p) => p.id == pollId
                  ? (closedPoll = Poll(
                      id: p.id,
                      question: p.question,
                      options: p.options,
                      votes: p.votes,
                      closed: true,
                      createdAt: p.createdAt,
                      multi: p.multi,
                    ))
                  : p,
            )
            .toList(),
      ),
    );
    if (closedPoll != null) {
      final poll = closedPoll!;
      _persistPoll(poll);
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'Poll closed',
          body: poll.question,
          type: NotificationType.admin,
          link: '/group',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
      // Tech Spec §14.2: "Results may suggest a matching tournament preset."
      // Surface a preset recommendation from the votes so an admin starting a
      // tournament from a poll-driven flow sees the suggestion up front.
      final signals = <num>[
        for (final entry in poll.optionCounts().entries)
          for (final m in RegExp(r'-?\d+(\.\d+)?').allMatches(entry.key))
            num.tryParse(m.group(0) ?? '') ?? 0,
      ];
      final suggestions = suggestPresets(
        expectedPlayers: poll.totalVotes,
        pollSignals: signals,
      );
      if (suggestions.isNotEmpty) {
        pushNotification(
          AppNotification(
            id: 'n-${DateTime.now().millisecondsSinceEpoch}',
            title: 'Preset suggestion',
            body: '${poll.question} — consider preset '
                '${suggestions.map((p) => p.name).join(' or ')}?',
            type: NotificationType.admin,
            link: RoutePaths.createTournament,
            read: false,
            timestamp: DateTime.now(),
          ),
        );
      }
    }
    notifyListeners();
  }

  /// Whether the RSVP change deadline (1 hour before scheduled start,
  /// 07-011/07-012, UAT-025) has passed for the current game.
  bool get rsvpCutoffPassed =>
      isAdmin ? false : (_currentGame?.settings.rsvpCutoffPassed ?? false);

  /// Sets (or clears) the signed-in member's RSVP for a game — the one open on
  /// screen, or any game in the current group (e.g. tapped from the chat invite
  /// card). Re-selecting the response the member already holds is a no-op; a
  /// different response is persisted and stays selected after the round-trip.
  void setRSVP(Rsvp? rsvp, {String? gameId}) {
    final userId = _user?.id;
    if (userId == null) return;
    _applyRsvpFor(userId, rsvp, gameId: gameId);
  }

  /// Admin-only override: corrects or reopens another member's RSVP (User
  /// Flow §3.1 "The admin may correct or reopen an RSVP when necessary").
  /// Persists through the exact same write paths as [setRSVP].
  void adminSetRSVP(String participantId, Rsvp? rsvp, {String? gameId}) {
    if (!isAdmin || participantId.isEmpty) return;
    _applyRsvpFor(participantId, rsvp, gameId: gameId, announce: false);
  }

  void _applyRsvpFor(String userId, Rsvp? rsvp,
      {String? gameId, bool announce = true}) {
    final targetId = gameId ?? _currentGame?.id;
    if (targetId == null) return;

    final isCurrent = _currentGame?.id == targetId;
    final target = isCurrent
        ? _currentGame
        : _currentGroup.games.where((g) => g.id == targetId).firstOrNull;
    if (target == null) return;
    if (target.settings.rsvpCutoffPassed && !isAdmin) return;

    // No-op when the member already holds exactly this response — a tap on the
    // already-selected button must not churn a write or flicker the UI.
    //
    // But "already holds" must mean *the server* holds it, not just this
    // device: if local state drifted ahead (a write that never landed, or a
    // stale restored snapshot) this guard silently killed every retry tap and
    // the admin never saw the RSVP at all. `_lastSavedGame` is the last state
    // actually adopted from / written to Firestore, so it is the honest
    // reference.
    final mine = target.players.where((p) => p.id == userId).firstOrNull;
    final serverGame = _lastSavedGame?.id == targetId ? _lastSavedGame : null;
    final serverMine =
        serverGame?.players.where((p) => p.id == userId).firstOrNull;
    final serverAgrees = serverGame == null || serverMine?.rsvp == rsvp;
    if (mine != null && mine.rsvp == rsvp) {
      if (serverAgrees && !_pendingOwnRsvp.containsKey(targetId)) return;
      debugPrint('RSVP re-tap for $userId: local=${mine.rsvp?.name} '
          'server=${serverMine?.rsvp?.name} — forcing a write');
    }

    // Destructive-shrink handling lives inside applyRsvp →
    // [_reconcileExcessGuestSlots]: unconfirmed excess guests are dropped
    // silently, while confirmed ones are kept and surfaced to the admin as a
    // conflict notification (checklist 07-015) — the member's change is never
    // hard-blocked (§7.1).

    LiveGame applyRsvp(LiveGame g) {
      final onRoster = g.players.any((p) => p.id == userId);
      // A member who joined the group *after* this game was created is not on
      // the seeded roster yet — add them when they answer the invite.
      final players = onRoster
          ? g.players
              .map((p) => p.id == userId ? p.copyWith(rsvp: rsvp) : p)
              .toList()
          : [...g.players, _memberAsPlayer(userId, rsvp)];
      var updated = g.copyWith(players: players);
      updated = _syncGuestSlots(updated, userId, rsvp?.guestCount ?? 0);
      updated = _reconcileExcessGuestSlots(updated, userId, rsvp?.guestCount ?? 0);
      return updated;
    }

    final before = target;
    final after = applyRsvp(target);

    if (isCurrent) {
      _currentGame = after;
    }
    // All paths: hold the selection locally until a remote snapshot confirms
    // it. This prevents any lagging Firebase snapshot from reverting the
    // selection before the write round-trip completes (applies to admin too).
    _pendingOwnRsvp[targetId] = rsvp;

    if (!_isGameAuthority || !isCurrent) {
      // Members write only their own fields via dot-path. (An authority
      // RSVPing a game that isn't open on screen also patches directly — the
      // on-screen game's whole-doc save wouldn't cover it.)
      var patch = _rsvpDotPatch(before, after);
      if (patch.isEmpty && !serverAgrees) {
        // Local already displayed this answer, so the diff is empty, but the
        // server never received it. Write the field explicitly instead of
        // dropping the tap on the floor.
        patch = {'players.$userId.rsvp': rsvp?.name};
      }
      _persistOwnRsvpPatch(targetId, patch, rsvp);
    }
    // (authority + on-screen game: persisted by _syncGameToCloud's whole-doc
    // save when notifyListeners fires below.)

    // Notify the admin of RSVP changes (spec §8 notification triggers).
    if (announce && _currentGroup.ownerId != userId) {
      final name = mine?.name ?? _user?.name ?? '';
      final playerName = name.isEmpty ? 'A member' : name;
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'RSVP update',
          body: '$playerName is ${rsvp?.label ?? 'no response'}.',
          type: NotificationType.rsvp,
          link: '/invitation',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }

    // Keep the group's copy of the game in sync so hub badges update at once.
    _setGroup(
      _currentGroup.copyWith(
        games: _currentGroup.games
            .map((g) => g.id == targetId ? applyRsvp(g) : g)
            .toList(),
      ),
    );
    notifyListeners();
  }

  /// Persists the member's own RSVP dot-path patch against a game doc (the one
  /// open on screen or any game in the current group — chat invite card).
  ///
  /// The optimistic overlay ([_pendingOwnRsvp]) is held for the entire retry
  /// window and only dropped once every attempt has failed — so a tap never
  /// "un-selects itself" while the group id is still resolving or the auth
  /// token is still propagating right after login.
  void _persistOwnRsvpPatch(String gameId, Map<String, dynamic> dotPaths, Rsvp? targetRsvp) {
    if (dotPaths.isEmpty) {
      // before == after at field level — nothing to write. Logged because a
      // silent return here is indistinguishable from a successful save and
      // previously hid a whole class of "the tap did nothing" bugs.
      debugPrint('RSVP patch skipped for $gameId: diff produced no fields');
      return;
    }

    unawaited(() async {
      // Longer, gentler backoff: covers both a slow group-bundle resolve and
      // the post-login token gap without ever yanking the selection.
      const delaysMs = [0, 250, 500, 1000, 2000, 3500, 5000, 8000, 12000];
      var triedSelfJoin = false;
      Object? lastError;
      for (var attempt = 0; attempt < delaysMs.length; attempt++) {
        if (delaysMs[attempt] > 0) {
          await Future<void>.delayed(Duration(milliseconds: delaysMs[attempt]));
        }
        // A newer RSVP for this game supersedes this write.
        if (_pendingOwnRsvp[gameId] != targetRsvp) return;
        if (!_backendUp || _user == null) continue;

        // Re-resolve the group id every attempt — it may still be settling
        // immediately after login / navigation.
        final g = _currentGame?.id == gameId
            ? _currentGame
            : _currentGroup.games.where((x) => x.id == gameId).firstOrNull;
        final gid =
            (g != null && g.groupId.isNotEmpty) ? g.groupId : _currentGroupId;
        if (gid == null) {
          debugPrint('RSVP patch waiting for group id (attempt ${attempt + 1})');
          continue;
        }

        try {
          await _repo.patchGame(gid, gameId, dotPaths);
          if (lastRsvpError != null) {
            lastRsvpError = null;
            notifyListeners();
          }
          if (g != null) {
            unawaited(_publishProjections(g).catchError((Object _) {}));
          }
          return;
        } catch (e) {
          lastError = e;
          debugPrint('RSVP patch failed (attempt ${attempt + 1}): $e');
          if (_isRetriablePermissionError(e)) {
            await _nudgeAuthToken();
            // The game doc is member-gated. If this signed-in user reached the
            // game via a shared game code / link they were never added to the
            // group roster, so `isMember` is false and the write is denied.
            // Self-join the roster (rules allow a user to create their own
            // 'member' row) and try again.
            if (!triedSelfJoin && !isGuest) {
              triedSelfJoin = true;
              try {
                await _repo.joinGroup(gid, _user!);
                debugPrint('RSVP patch: self-joined group $gid roster, retrying');
              } catch (joinErr) {
                debugPrint('RSVP patch: self-join failed: $joinErr');
              }
            }
          }
        }
      }
      final errorStr = (lastError ?? '').toString().toLowerCase();
      if (_isRetriablePermissionError(lastError ?? '')) {
        lastRsvpError = 'RSVP not saved — you may not have write access to this game. Ask the host to add you to the group.';
      } else if (errorStr.contains('quota-exceeded') || errorStr.contains('resource-exhausted') || errorStr.contains('quota')) {
        lastRsvpError = 'RSVP not saved — database quota exceeded (free tier limit reached).';
      } else {
        lastRsvpError = 'RSVP save failed. Tap again to retry.';
      }
      _pendingOwnRsvp.remove(gameId);
      _rsvpReassertCount.remove(gameId);
      notifyListeners();
    }());
  }

  /// A roster [Player] for the signed-in member, from the group roster. Used
  /// when a member RSVPs to a game created before they joined the group.
  Player _memberAsPlayer(String userId, Rsvp? rsvp) {
    final m = _currentGroup.members.where((x) => x.id == userId).firstOrNull;
    return Player(
      id: userId,
      name: m?.name ?? _user?.name ?? '',
      isGuest: false,
      rsvp: rsvp,
      checkedIn: false,
      confirmed: false,
      eliminated: false,
      rebuys: 0,
      hasAddOn: false,
      knockouts: 0,
      table: 0,
      seat: 0,
      active: true,
    );
  }

  /// Builds the dot-path patch describing an RSVP change: the member's own
  /// `players.{id}` entry plus the guest-slot rows their +N count creates,
  /// updates or removes. A member new to the roster is written whole; an
  /// existing one gets a field-level `players.{id}.rsvp` patch.
  Map<String, dynamic> _rsvpDotPatch(LiveGame before, LiveGame after) {
    final patch = <String, dynamic>{};
    final uid = _user?.id;

    final beforePlayer = before.players.where((p) => p.id == uid).firstOrNull;
    final afterPlayer = after.players.where((p) => p.id == uid).firstOrNull;
    if (afterPlayer != null) {
      if (beforePlayer == null) {
        patch['players.$uid'] = playerToMap(afterPlayer);
      } else if (afterPlayer.rsvp?.name != beforePlayer.rsvp?.name) {
        patch['players.$uid.rsvp'] = afterPlayer.rsvp?.name;
      }
    }

    final beforeSlots = {for (final s in before.guestSlots) s.id: s};
    for (var i = 0; i < after.guestSlots.length; i++) {
      final s = after.guestSlots[i];
      final old = beforeSlots[s.id];
      if (old == null) {
        patch['guestSlots.${s.id}'] = {
          ...guestSlotToMap(s),
          'orderIndex': i,
        };
      } else if (old.guestName != s.guestName ||
          old.status != s.status ||
          old.slot != s.slot) {
        patch['guestSlots.${s.id}'] = {
          ...guestSlotToMap(s),
          'orderIndex': i,
        };
      }
    }
    for (final s in before.guestSlots) {
      if (!after.guestSlots.any((n) => n.id == s.id)) {
        patch['guestSlots.${s.id}'] = FieldValue.delete();
      }
    }
    return patch;
  }

  /// Keeps the persisted [GuestSlot] records aligned with a member's "Going +N"
  /// RSVP count (checklist 07-014). Missing slots are created as unclaimed;
  /// slots beyond the new count that are still unclaimed are removed. Claimed
  /// slots are never deleted here — excess claims are handled by
  /// [_reconcileExcessGuestSlots].
  LiveGame _syncGuestSlots(LiveGame game, String userId, int newCount) {
    final existing = game.guestSlots
        .where((s) => s.inviterId == userId)
        .toList();
    final claimed = existing.where((s) => !s.available).toList();
    final keep = <GuestSlot>[];
    for (var slot = 1; slot <= newCount; slot++) {
      final existingForSlot = existing.where((s) => s.slot == slot).firstOrNull;
      if (existingForSlot != null) {
        keep.add(existingForSlot);
      } else {
        keep.add(
          GuestSlot(
            id: 'slot-${DateTime.now().millisecondsSinceEpoch}-$userId-$slot',
            inviterId: userId,
            slot: slot,
            status: GuestSlotStatus.unclaimed,
          ),
        );
      }
    }
    // Unclaimed slots beyond the new count are dropped; claimed ones remain.
    final rest = game.guestSlots
        .where(
          (s) =>
              s.inviterId != userId ||
              (s.inviterId == userId && s.slot > newCount && !s.available),
        )
        .toList();
    final slots = [
      ...rest,
      ...keep,
      ...claimed.where((s) => s.slot <= newCount),
    ];
    // Deduplicate (id-based) to be safe.
    final seen = <String>{};
    final merged = <GuestSlot>[];
    for (final s in slots) {
      if (seen.add(s.id)) merged.add(s);
    }
    return game.copyWith(guestSlots: merged);
  }

  /// Checklist 07-015 / 20-030 / 20-031: when a player lowers their guest
  /// count, unused guest slots beyond the new count are released safely.
  /// Unconfirmed requests are removed; guests already confirmed on an excess
  /// slot are kept but surfaced to the administrator as a conflict.
  LiveGame _reconcileExcessGuestSlots(
    LiveGame game,
    String userId,
    int newCount,
  ) {
    final excess = game.players
        .where(
          (p) =>
              p.isGuest &&
              p.inviterId == userId &&
              (p.guestSlot ?? 0) > newCount,
        )
        .toList();
    if (excess.isEmpty) return game;
    final confirmed = excess.where((p) => p.confirmed).toList();
    // Spec B3/L-20: Only remove UNCLAIMED (unconfirmed) excess guests.
    final unconfirmedExcessIds = excess.where((p) => !p.confirmed).map((p) => p.id).toSet();
    final unconfirmedExcessSlots = excess
        .where((p) => !p.confirmed)
        .map((p) => p.guestSlot)
        .toSet();
    final updated = game.copyWith(
      players: game.players.where((p) => !unconfirmedExcessIds.contains(p.id)).toList(),
      pendingGuests: game.pendingGuests.where((p) => !unconfirmedExcessIds.contains(p.id)).toList(),
      guestSlots: game.guestSlots.where((s) => 
        !(s.inviterId == userId && unconfirmedExcessSlots.contains(s.slot))
      ).toList(),
    );
    if (confirmed.isNotEmpty) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'RSVP reduced after guest check-in',
          body:
              '${confirmed.map((p) => p.name).join(', ')} '
              '${confirmed.length == 1 ? 'is' : 'are'} confirmed on a guest slot '
              'the inviter just removed. Review before seating.',
          type: NotificationType.admin,
          link: '/check-in',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
    return updated;
  }

  /// Sends an RSVP reminder to every member who has not yet responded
  /// (checklist 04-023/04-024). Pushes a notification per member so the
  /// (dummy) inbox shows the reminders, and logs the action for the admin.
  void sendRSVPReminders(String gameId) {
    final game = gameById(gameId);
    if (game == null || _user == null) return;
    final target = _currentGame?.id == gameId ? _currentGame : game;
    if (target == null) return;
    final pending = target.players
        .where((p) => !p.isGuest && p.rsvp == null)
        .toList();
    if (pending.isEmpty) return;
    for (final _ in pending) {
      pushNotification(
        AppNotification(
          id: 'n-${DateTime.now().millisecondsSinceEpoch}',
          title: 'RSVP reminder',
          body:
              'You haven\'t responded to ${target.settings.name} '
              '(${target.settings.date} at ${target.settings.time}). '
              'Let the host know if you\'re in.',
          type: NotificationType.rsvp,
          link: '/invitation',
          read: false,
          timestamp: DateTime.now(),
        ),
      );
    }
    addAuditRecord(
      'rsvp_reminder',
      'Reminder sent to ${pending.length} member'
          '${pending.length == 1 ? '' : 's'} who have not responded.',
    );
    addAnnouncement(
      'Reminder sent to ${pending.length} player'
      '${pending.length == 1 ? '' : 's'} without an RSVP.',
      false,
    );
    notifyListeners();
  }

  // ── Code lookup ────────────────────────────────────────────────────────────

  /// Extracts a bare join code from anything the user might enter: a raw code
  /// (`FRIDAY7`), a full invite link
  /// (`https://poker-night-tools.web.app/join-group?code=FRIDAY7`), a game link
  /// (`.../game/FP2608`) or a QR payload. Returns an upper-cased `[A-Z0-9]`
  /// string, or `''` when nothing code-like is present.
  static String extractJoinCode(String input) {
    var s = input.trim();
    if (s.isEmpty) return '';

    final uri = Uri.tryParse(s);
    if (uri != null && uri.hasScheme) {
      final q = uri.queryParameters['code'];
      if (q != null && q.isNotEmpty) {
        s = q;
      } else if (uri.pathSegments.isNotEmpty) {
        // `/game/FP2608`, `/join/FP2608`, `/join-group/FRIDAY7`
        s = uri.pathSegments.last;
      }
    } else if (s.contains('code=')) {
      s = s.split('code=').last.split('&').first;
    } else if (s.contains('/')) {
      s = s.split('/').last.split('?').first.split('#').first;
    }

    return s.toUpperCase().replaceAll(RegExp('[^A-Z0-9]'), '');
  }

  /// Classifies a join code (or invite link / QR payload) as a group code, a
  /// game code or a TV code — without joining or subscribing to anything.
  /// The unified join screen uses this to route guests and signed-in users to
  /// the right flow. Safe to call unauthenticated (join codes are world-
  /// readable by design).
  Future<JoinCodeResolution> resolveJoinCode(String input) async {
    final code = extractJoinCode(input);
    if (code.isEmpty) return const JoinCodeResolution(JoinCodeKind.notFound, '');
    if (!_backendUp) return JoinCodeResolution(JoinCodeKind.error, code);
    if (!_consumeCodeLookupSlot()) {
      return JoinCodeResolution(JoinCodeKind.rateLimited, code);
    }
    try {
      final data = await _repo.peekJoinCode(code);
      if (data == null) return JoinCodeResolution(JoinCodeKind.notFound, code);
      final gameId = data['gameId'] as String?;
      if (gameId == null || gameId.isEmpty) {
        return JoinCodeResolution(JoinCodeKind.group, code);
      }
      final kind = (data['kind'] as String?) ?? 'game';
      return JoinCodeResolution(
        kind == 'tv' ? JoinCodeKind.tv : JoinCodeKind.game,
        code,
      );
    } catch (e) {
      debugPrint('resolveJoinCode failed: $e');
      return JoinCodeResolution(JoinCodeKind.error, code);
    }
  }

  /// Sliding-window throttle for join-code lookups (spec §22 rate limits).
  /// Firestore rules cannot count reads, so the client caps itself at 10
  /// lookups per minute per device.
  final List<DateTime> _codeLookupTimes = <DateTime>[];
  bool _consumeCodeLookupSlot() {
    final now = DateTime.now();
    _codeLookupTimes
        .removeWhere((t) => now.difference(t) > const Duration(minutes: 1));
    if (_codeLookupTimes.length >= 10) return false;
    _codeLookupTimes.add(now);
    return true;
  }

  /// Resolves a public/TV join code through Firestore and subscribes the
  /// matching feed. TVs and guests read the sanitized `publicGames/{id}`
  /// projections (never the raw game doc); the returned result tells the
  /// caller which screen to open. Returns [CodeLookupResult.notFound] for
  /// unknown codes or when no backend is available.
  Future<CodeLookupResult> enterGameCode(String code) async {
    if (!_backendUp) return CodeLookupResult.notFound;
    if (!_consumeCodeLookupSlot()) return CodeLookupResult.rateLimited;
    try {
      final hit = await _repo.findGameByCode(code);
      if (hit == null) return CodeLookupResult.notFound;

      _lookupSub?.cancel();
      if (hit.kind == 'game' && _isGameAuthority) {
        // Admins can follow the raw document.
        _lookupSub =
            _repo.gameDocSnapshots(hit.gid, hit.gameId, isAdmin: true).listen((snap) {
          final data = snap.data();
          if (!snap.exists || data == null) return;
          try {
            _clearUndoStack();
            final remote =
                liveGameFromFirestoreDoc(Map<String, dynamic>.from(data));
            _currentGame =
                _withPendingCheckInOverlay(_withOwnRsvpOverlay(remote));
            _lastSavedGame = remote;
            notifyListeners();
          } catch (e) {
            debugPrint('code-lookup game decode failed: $e');
          }
        }, onError: (Object e) => debugPrint('lookup stream error: $e'));
      } else {
        // Guests / TVs / Members (F-001 Fix): sanitized projection feed.
        final projectionKey = hit.kind == 'tv' ? 'tv' : (hit.kind == 'game' ? 'player' : 'guest');
        _lookupSub = _repo.publicGameStream(hit.gameId).listen((doc) {
          final payload = doc[projectionKey] as Map<String, dynamic>?;
          if (payload == null) return;
          try {
            _clearUndoStack();
            _currentGame = _withPendingCheckInOverlay(_withOwnRsvpOverlay(
              liveGameFromMap(Map<String, dynamic>.from(payload as Map)),
            ));
            notifyListeners();
          } catch (e) {
            debugPrint('projection decode failed: $e');
          }
        }, onError: (Object e) => debugPrint('public stream error: $e'));
      }
      return hit.kind == 'tv'
          ? CodeLookupResult.tv
          : CodeLookupResult.game;
    } catch (e) {
      debugPrint('enterGameCode failed: $e');
      return CodeLookupResult.notFound;
    }
  }

  // ── Cash game ──────────────────────────────────────────────────────────────
  CashSession? _cashSession;
  CashSession? get cashSession => _cashSession;

  /// Completed cash sessions shown in history (checklist 16-002). Cloud-backed
  /// per group via [completedCashSessionsStream]; locally appended when the
  /// backend is unavailable.
  List<CashSession> _cashHistory = const [];
  List<CashSession> get cashHistory => List.unmodifiable(_cashHistory);

  void startCashGame(CashSessionSettings settings, List<String> playerNames) {
    _cashSession = CashSession(
      id: 'cash-${DateTime.now().millisecondsSinceEpoch}',
      settings: settings,
      isCompleted: false,
      startTime: DateTime.now(),
      players: List.generate(
        playerNames.length,
        (i) => CashPlayer(
          id: 'cp-${DateTime.now().millisecondsSinceEpoch}-$i',
          name: playerNames[i],
          stack: settings.minBuyIn,
          totalBuyIns: settings.minBuyIn,
          buyInCount: 1,
          cashedOut: 0,
        ),
      ),
    );
    notifyListeners();
  }

  /// Records a cash buy-in / rebuy for a player (or adds a brand-new player).
  /// Returns a validation message when the amount falls outside the session's
  /// [CashSessionSettings.minBuyIn]..[CashSessionSettings.maxBuyIn] bounds, or
  /// null on success.
  String? cashBuyIn(
    String playerIdOrName,
    double amount, {
    bool isNew = false,
  }) {
    final session = _cashSession;
    if (session == null) return 'No active cash session.';
    if (amount <= 0) return 'Amount must be positive.';
    final min = session.settings.minBuyIn;
    final max = session.settings.maxBuyIn;
    // No currency symbols in the primary interface (User Flow spec §3.4).
    if (amount < min) return 'Minimum buy-in is $min.';
    if (amount > max) return 'Maximum buy-in is $max.';
    if (isNew) {
      _cashSession = session.copyWith(
        players: [
          ...session.players,
          CashPlayer(
            id: 'cp-${DateTime.now().millisecondsSinceEpoch}-${Random().nextInt(9999)}',
            name: playerIdOrName,
            stack: amount,
            totalBuyIns: amount,
            buyInCount: 1,
            cashedOut: 0,
          ),
        ],
      );
    } else {
      _cashSession = session.copyWith(
        players: session.players
            .map(
              (p) => p.id == playerIdOrName
                  ? p.copyWith(
                      stack: p.stack + amount,
                      totalBuyIns: p.totalBuyIns + amount,
                      buyInCount: p.buyInCount + 1,
                    )
                  : p,
            )
            .toList(),
      );
    }
    notifyListeners();
    return null;
  }

  void cashCashOut(String playerId, double amount) {
    final session = _cashSession;
    if (session == null) return;
    _cashSession = session.copyWith(
      players: session.players
          .map(
            (p) =>
                p.id == playerId ? p.copyWith(cashedOut: amount, stack: 0, hasCashedOut: true) : p,
          )
          .toList(),
    );
    notifyListeners();
  }

  /// Corrects an incorrectly entered buy-in, top-up or cash-out (checklist
  /// 17-020 / 17-028 / 20-047). All totals are recomputed from the corrected
  /// fields; stack/total/buyInCount/cashedOut that are null are left as-is.
  void cashEditPlayer(
    String playerId, {
    double? stack,
    double? totalBuyIns,
    int? buyInCount,
    double? cashedOut,
    bool? hasCashedOut,
  }) {
    final session = _cashSession;
    if (session == null) return;
    _cashSession = session.copyWith(
      players: session.players
          .map(
            (p) => p.id == playerId
                ? CashPlayer(
                    id: p.id,
                    name: p.name,
                    stack: stack ?? p.stack,
                    totalBuyIns: totalBuyIns ?? p.totalBuyIns,
                    buyInCount: buyInCount ?? p.buyInCount,
                    cashedOut: cashedOut ?? p.cashedOut,
                    hasCashedOut: hasCashedOut ?? p.hasCashedOut,
                  )
                : p,
          )
          .toList(),
    );
    notifyListeners();
  }

  void endCashGame({String? unresolvedNote}) {
    final session = _cashSession;
    if (session == null) return;
    _cashSession = session.copyWith(
      isCompleted: true,
      unresolvedNote: unresolvedNote,
    );
    _cashHistory = [_cashSession!, ..._cashHistory];
    notifyListeners();
    final gid = _currentGroupId ?? _currentGame?.groupId;
    final uid = _repo.currentUid;
    if (_backendUp && gid != null && uid != null) {
      unawaited(_repo
          .saveCashSession(gid, _cashSession!)
          .catchError(
              (Object e) => debugPrint('saveCashSession failed: $e')));
    }
    clearCashSession();
  }

  /// Discards the current cash session so a fresh game can be started.
  void clearCashSession() {
    _cashSession = null;
    RecoveryService.clearCashSession();
    notifyListeners();
  }

  // ── Notifications ──────────────────────────────────────────────────────────
  /// Replaced by the live inbox stream once user data is subscribed; empty
  /// until then (no demo seed — a fresh account starts clean).
  List<AppNotification> _notifications = const [];
  List<AppNotification> get notifications => _notifications;

  int get unreadCount => _notifications.where((n) => !n.read).length;

  void markAllRead() {
    _notifications = _notifications.map((n) => n.copyWith(read: true)).toList();
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.markAllNotificationsRead(uid)
          .catchError((Object e) => debugPrint('markAllRead failed: $e')));
    }
  }

  void markNotificationRead(String id) {
    _notifications = _notifications
        .map((n) => n.id == id ? n.copyWith(read: true) : n)
        .toList();
    notifyListeners();
    final uid = _repo.currentUid;
    if (_backendUp && uid != null) {
      unawaited(_repo.markNotificationRead(uid, id)
          .catchError((Object e) => debugPrint('markRead failed: $e')));
    }
  }

  /// Prepends a notification locally, stages it in the current group's outbox
  /// and fans it out to group members as a REAL push via OneSignal — all from
  /// this device, with no Cloud Function (free plan).
  void pushNotification(AppNotification notification) {
    // Collision-safe ids: several call sites build ids from
    // `DateTime.now().millisecondsSinceEpoch` alone, which can collide when
    // notifications are created rapidly (e.g. in a loop). De-duplicate here
    // so the inbox list never holds two identical ids.
    var id = notification.id;
    final existingIds = _notifications.map((n) => n.id).toSet();
    if (existingIds.contains(id)) {
      var n = 2;
      while (existingIds.contains('$id-$n')) {
        n++;
      }
      id = '$id-$n';
      notification = notification.copyWith(id: id);
    }
    _notifications = [notification, ..._notifications];
    // This device originated the event — never re-banner it on itself when
    // the mirrored inbox copy arrives.
    _seenNotificationIds.add(notification.id);
    notifyListeners();
    if (_backendUp) {
      final gid = _currentGroup.id;
      if (gid.isNotEmpty) {
        unawaited(_repo.stageGroupNotification(gid, notification).catchError(
            (Object e) => debugPrint('stageGroupNotification failed: $e')));
        _fanOutPush(gid, notification);
      }
    }
  }

  /// OneSignal fan-out (the free-plan replacement for the Cloud Function).
  /// Only the staging device sends; every other device just mirrors the
  /// outbox into its inbox, so pushes are never duplicated.
  void _fanOutPush(String gid, AppNotification notification) {
    if (!OneSignalSender.instance.configured) return;
    final uid = _repo.currentUid;
    final memberIds = _currentGroup.members.map((m) => m.id).toList();
    final targets = <String>[
      if (notification.audience != null && notification.audience!.isNotEmpty)
        ...notification.audience!.where(memberIds.contains)
      else
        ...memberIds,
    ].where((id) => id != uid).toList();
    if (targets.isEmpty) return;
    unawaited(OneSignalSender.instance
        .send(
          title: notification.title,
          body: notification.body,
          appUrlPath: notification.link,
          externalIds: targets,
        )
        .then((_) => debugPrint('🔥 SUCCESS: Fanned out push to $targets!'))
        .catchError((Object e) => debugPrint('push fan-out failed: $e')));
  }

  // ── Voice & misc ───────────────────────────────────────────────────────────
  bool _voiceEnabled = true;
  bool get voiceEnabled => _voiceEnabled;

  void toggleVoice() {
    _voiceEnabled = !_voiceEnabled;
    _persistPref('voiceEnabled', _voiceEnabled);
    notifyListeners();
  }

  void setVoiceEnabled(bool value) {
    if (_voiceEnabled == value) return;
    _voiceEnabled = value;
    _persistPref('voiceEnabled', _voiceEnabled);
    notifyListeners();
  }

  /// Audio Master (checklist 15-041/15-042/15-043): the administrator manually
  /// selects which connected device plays announcements. When no master is
  /// chosen (`null`) every device with voice enabled may announce — the
  /// backwards-compatible default.
  ///
  /// `_audioMasterDeviceId` is `null` when no master is selected; otherwise it
  /// holds the device id of the chosen Audio Master. `thisDeviceIsAudioMaster`
  /// is true when this device may speak.
  String? _audioMasterDeviceId;

  /// Stable per-session id for the current browser/device.
  String? _thisDeviceId;
  String get thisDeviceId =>
      _thisDeviceId ??= 'dev-${DateTime.now().millisecondsSinceEpoch}';

  String? get audioMasterDeviceId => _audioMasterDeviceId;

  /// Whether announcements may play on this device (no master selected, or
  /// this device is the master) — matches the documented fallback where every
  /// voice-enabled device may announce while no master is chosen.
  bool get thisDeviceIsAudioMaster =>
      _audioMasterDeviceId == null || _audioMasterDeviceId == thisDeviceId;

  /// Selects this device as the Audio Master. Only this device will announce.
  void setAudioMasterDevice() {
    if (_audioMasterDeviceId == thisDeviceId) return;
    _audioMasterDeviceId = thisDeviceId;
    notifyListeners();
  }

  /// Clears the Audio Master selection — every device with voice enabled may
  /// announce again.
  void clearAudioMasterDevice() {
    if (_audioMasterDeviceId == null) return;
    _audioMasterDeviceId = null;
    notifyListeners();
  }

  /// Whether eliminated-player names are announced (checklist 15-053) —
  /// optional per tournament and disabled by default.
  bool get announceEliminations =>
      _currentGame?.settings.announceEliminations ?? false;

  void setAnnounceEliminations(bool value) {
    final game = _currentGame;
    if (game == null || game.settings.announceEliminations == value) return;
    _currentGame = game.copyWith(
      settings: game.settings.copyWith(announceEliminations: value),
    );
    _syncGroupGame();
    notifyListeners();
  }

  // ── Account preferences (settings screen) ─────────────────────────────────
  bool _soundsEnabled = true;
  bool get soundsEnabled => _soundsEnabled;

  void setSoundsEnabled(bool value) {
    if (_soundsEnabled == value) return;
    _soundsEnabled = value;
    notifyListeners();
  }

  bool _compactSummary = false;
  bool get compactSummary => _compactSummary;

  void setCompactSummary(bool value) {
    if (_compactSummary == value) return;
    _compactSummary = value;
    notifyListeners();
  }

  /// SMS/text notifications for RSVPs and game events.
  bool _smsEnabled = false;
  bool get smsEnabled => _smsEnabled;

  void setSmsEnabled(bool value) {
    if (_smsEnabled == value) return;
    _smsEnabled = value;
    notifyListeners();
  }

  /// Theme preference: one of "dark", "light", "system".
  String _themePreference = 'dark';
  String get themePreference => _themePreference;

  void setThemePreference(String value) {
    if (_themePreference == value) return;
    _themePreference = value;
    _persistPref('themePreference', value);
    notifyListeners();
  }

  /// Color theme id — one of the [ThemePalettes.all] ids.
  String _colorTheme = 'red';
  String get colorTheme => _colorTheme;

  void setColorTheme(String value) {
    if (_colorTheme == value) return;
    _colorTheme = value;
    _persistPref('colorTheme', value);
    notifyListeners();
  }

  /// Id of the chip set used as the default for new tournaments; null = the
  /// standard set.
  String? _defaultChipSetId;
  String? get defaultChipSetId => _defaultChipSetId;

  void setDefaultChipSet(String? id) {
    if (_defaultChipSetId == id) return;
    _defaultChipSetId = id;
    notifyListeners();
  }

  /// Selected avatar colour index (into the app's avatar palette).
  int _avatarColorIndex = 0;
  int get avatarColorIndex => _avatarColorIndex;

  void setAvatarColor(int index) {
    if (_avatarColorIndex == index) return;
    _avatarColorIndex = index;
    notifyListeners();
  }

  /// Deletes the signed-in account (profile doc, membership mirrors, auth
  /// user) and invalidates every session so a deleted account cannot keep
  /// using a stale live game (checklist 05-014). Returns a friendly error
  /// message on failure — notably `requires-recent-login`, where the caller
  /// must re-authenticate first.
  Future<String?> deleteAccount() async {
    try {
      await _repo.deleteAccount();
    } on fa.FirebaseAuthException catch (e) {
      if (e.code == 'requires-recent-login') {
        return 'For security please sign in again before deleting your account.';
      }
      return e.message ?? 'Could not delete the account. Please try again.';
    }
    _user = null;
    _currentGame = null;
    _cashSession = null;
    _guestSession = null;
    _restoredFromRecovery = false;
    _recoveryTime = null;
    RecoveryService.clearGame();
    RecoveryService.clearCashSession();
    RecoveryService.clearGuestSession();
    notifyListeners();
    return null;
  }

  String _guestCode = '';
  String get guestCode => _guestCode;

  void setGuestCode(String code) {
    _guestCode = code;
    notifyListeners();
  }

  // ── Drawer state ───────────────────────────────────────────────────────────
  bool _isDrawerOpen = false;
  bool get isDrawerOpen => _isDrawerOpen;

  void openDrawer() {
    if (_isDrawerOpen) return;
    _isDrawerOpen = true;
    notifyListeners();
  }

  void closeDrawer() {
    if (!_isDrawerOpen) return;
    _isDrawerOpen = false;
    notifyListeners();
  }

  void toggleDrawer() {
    _isDrawerOpen = !_isDrawerOpen;
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _serverTimeRecalibration?.cancel();
    _authSub?.cancel();
    _connectivitySub?.cancel();
    _teardownUserData();
    super.dispose();
  }
}

/// Result of a guest slot resolve (booking vs re-identification vs conflict).
enum GuestCheckInStatus { booked, confirmed, taken, failed }

class GuestCheckInResult {
  const GuestCheckInResult(this.status, {this.message});

  final GuestCheckInStatus status;

  /// Optional user-facing message, e.g. the conflict explanation when the slot
  /// belongs to a different name.
  final String? message;

  /// True when the guest now owns a booking on the slot ([booked] just made
  /// one; [confirmed] reused the one already under their name).
  bool get ok =>
      status == GuestCheckInStatus.booked || status == GuestCheckInStatus.confirmed;
}



