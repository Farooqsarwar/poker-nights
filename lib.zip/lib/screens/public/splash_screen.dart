import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';

import '../../app/colors.dart';
import '../../app/route_paths.dart';
import '../../widgets/brand_lockup.dart';

/// Splash shown on cold start (mirrors web splash overlay, ~2s).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 2000), () {
      if (mounted) context.go(RoutePaths.landing);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Logo: scale up from tiny, flip in, fade in, then slide up with text
            const PokerNightLogo(size: 160)
                .animate()
                .scaleXY(
              begin: 0.2,
              end: 1,
              duration: 700.ms,
              curve: Curves.elasticOut, // bouncy grow
            )
                .rotateY(
              begin: -0.5, // half turn flip
              end: 0,
              duration: 700.ms,
              curve: Curves.easeOutBack,
            )
                .fadeIn(duration: 500.ms)
                .slideY(
              begin: 0.3,
              end: 0,
              duration: 600.ms,
              delay: 400.ms, // wait for grow/flip to settle
              curve: Curves.easeOut,
            ),
            const SizedBox(height: 24),
            // Text: fade in + slide up, synced with logo's slide
            Text(
              'Poker Night Tools',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.2,
              ),
            )
                .animate()
                .fadeIn(duration: 600.ms, delay: 400.ms)
                .slideY(
              begin: 0.3,
              end: 0,
              duration: 600.ms,
              delay: 400.ms,
              curve: Curves.easeOut,
            ),
          ],
        ),
      ),
    );
  }
}