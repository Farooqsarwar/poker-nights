import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../app/colors.dart';
import '../../app/route_paths.dart';
import '../../app/typography.dart';
import '../../constants/app_constants.dart';
import '../../models/game.dart';
import '../../providers/app_provider.dart';
import '../../utils/voice_service.dart';
import '../../widgets/app_alert_banner.dart';
import '../../widgets/app_avatar.dart';
import '../../widgets/app_back_button.dart';
import '../../widgets/app_badge.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_card.dart';
import '../../services/entitlements.dart';
import '../../services/payment_service.dart';
import '../../widgets/app_icon_label.dart';
import '../../widgets/app_modal.dart';
import '../../widgets/app_page.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/event_day_checklist.dart';
import '../../widgets/journey_progress.dart';
import '../../widgets/premium_gate.dart';
import '../../models/payment_record.dart';
import '../../models/live_game.dart';
import '../../widgets/dummy_payment_sheet.dart';

enum SeatingMode { random, manual, keepGuests, separateGuests }

extension SeatingModeLabel on SeatingMode {
  String get label => switch (this) {
    SeatingMode.random => 'Fully random',
    SeatingMode.manual => 'Manual',
    SeatingMode.keepGuests => 'Guests with inviter',
    SeatingMode.separateGuests => 'Guests separate',
  };

  /// Maps the screen enum to the provider's seating enum.
  TableSeatingMode get tableMode => switch (this) {
    SeatingMode.random => TableSeatingMode.random,
    SeatingMode.manual => TableSeatingMode.manual,
    SeatingMode.keepGuests => TableSeatingMode.keepGuests,
    SeatingMode.separateGuests => TableSeatingMode.separateGuests,
  };
}

/// Check-in page mirroring the web `CheckInPage`.
class CheckInScreen extends StatefulWidget {
  const CheckInScreen({super.key});

  @override
  State<CheckInScreen> createState() => _CheckInScreenState();
}

class _CheckInScreenState extends State<CheckInScreen> {
  SeatingMode _seatingMode = SeatingMode.random;
  bool _seatingModeInitialized = false;

  /// Addendum section 3's free hosting limit. Read once; the notice below is
  /// a visible limit and an upgrade path, not enforcement -- section 7 puts
  /// real Premium authorization on a server that does not exist yet.

  @override
  void initState() {
    super.initState();
  }

  /// The checked-in count the split prompt was last shown/dismissed for, so
  /// it doesn't re-open every rebuild once the admin has responded to it at
  /// this count.
  int? _splitPromptRespondedAtCount;
  bool _splitPromptShowing = false;

  /// True while [AppProvider.startTournament] is in flight.
  ///
  /// Starting freezes the head-count and starts the clock — the single most
  /// consequential action in the app, and the one the host is most likely to
  /// tap twice, because they are standing at a table with everyone waiting.
  bool _starting = false;

  /// Once seating is generated the count naturally sits at/above the
  /// threshold on every rebuild; only prompt before that first generation.
  void _maybeShowSplitPrompt(
    BuildContext context,
    AppProvider app,
    int checkedInCount,
    int maxPerTable,
    bool seatedYet,
  ) {
    if (seatedYet ||
        checkedInCount < maxPerTable ||
        _splitPromptShowing ||
        _splitPromptRespondedAtCount == checkedInCount) {
      return;
    }
    _splitPromptShowing = true;
    showAppModal(
      context: context,
      title: 'Split into multiple tables?',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '$checkedInCount players have checked in — that\'s enough to '
            'split across multiple tables (max $maxPerTable per table). '
            'Generate seating now?',
            style: AppTypography.bodySm.copyWith(
              color: AppColors.mutedForeground,
            ),
          ),
          const SizedBox(height: AppSpacing.xl),
          Row(
            children: [
              Expanded(
                child: AppButton(
                  variant: AppButtonVariant.secondary,
                  onPressed: () {
                    _splitPromptRespondedAtCount = checkedInCount;
                    Navigator.of(context).pop();
                  },
                  child: const Text('Not yet'),
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: AppButton(
                  onPressed: () {
                    _splitPromptRespondedAtCount = checkedInCount;
                    app.generateSeating(_seatingMode.tableMode);
                    Navigator.of(context).pop();
                  },
                  child: const Text('Generate seating'),
                ),
              ),
            ],
          ),
        ],
      ),
    ).then((_) {
      _splitPromptShowing = false;
    });
  }

  void _showWalkInModal(BuildContext context, AppProvider app) {
    final controller = TextEditingController();
    showAppModal(
      context: context,
      title: 'Walk-in guest',
      child: StatefulBuilder(
        builder: (context, setModalState) {
          final name = controller.text.trim();
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Register someone who showed up without an RSVP or a guest slot. '
                'This is an admin override \u2014 the normal guest invite flow is bypassed. '
                'They are checked in immediately and seated with the next seating generation.',
                style: AppTypography.bodySm.copyWith(
                  color: AppColors.mutedForeground,
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              // Spec \u00A712.5: late registration is only allowed before the
              // rebuy period closes. The provider enforces the hard gate;
              // this banner makes the timing visible to the admin.
              Builder(builder: (ctx) {
                final app = ctx.read<AppProvider>();
                if (!app.lateRegistrationOpen) {
                  return const AppAlertBanner(
                    type: AppAlertType.error,
                    message:
                        'Late registration is closed. No new players can be added after the rebuy period ends.',
                  );
                }
                return const AppAlertBanner(
                  type: AppAlertType.warning,
                  message:
                      'Admin override: this skips the normal guest slot flow.',
                );
              }),
              const SizedBox(height: AppSpacing.lg),
              AppTextField(
                controller: controller,
                label: 'Name',
                autofocus: true,
                onChanged: (_) => setModalState(() {}),
              ),
              const SizedBox(height: AppSpacing.xl),
              Row(
                children: [
                  Expanded(
                    child: AppButton(
                      variant: AppButtonVariant.secondary,
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: AppButton(
                      onPressed: name.isEmpty || !app.lateRegistrationOpen
                          ? null
                          : () {
                              app.addWalkInPlayer(name);
                              Navigator.of(context).pop();
                            },
                      child: const Text('Check in'),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final game = app.currentGame;
    final isAdmin = app.canRunCurrentGame;

    // Seating setup is admin-only. Players see their seat from the invitation
    // screen, never this setup UI (client feedback 07-018).
    if (!isAdmin) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(RoutePaths.invitation);
      });
      return const SizedBox.shrink();
    }

    if (game == null) {
      // No game in provider — redirect back to a safe screen.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(RoutePaths.invitation);
      });
      return const SizedBox.shrink();
    }

    if (!_seatingModeInitialized) {
      _seatingModeInitialized = true;
      _seatingMode = app.effectiveTableSettings.randomizeByDefault
          ? SeatingMode.random
          : SeatingMode.manual;
    }

    final players = game.players;
    final checkedIn = players.where((p) => p.checkedIn && p.confirmed).toList();
    final notCheckedIn = players
        .where((p) => !p.checkedIn && !p.isGuest)
        .toList();
    final pendingRequests = players
        .where(
          (p) =>
              !p.confirmed && (p.checkedIn || (p.isGuest && p.name.isNotEmpty)),
        )
        .toList();
    final confirmedGuests = players
        .where((p) => p.isGuest && p.confirmed)
        .toList();
    final seatedYet = checkedIn.any((p) => p.table > 0 && p.seat > 0);
    final seatingConfirmed = game.seatingConfirmed;
    // Event-day preparation checklist (user-flow spec §4.6): admin-only and
    // only in the pre-live window (published / check-in / ready).
    final showChecklist = EventDayChecklist.appliesTo(game);

    // Table-split prompt (configurable threshold, spec §5e): once check-in
    // reaches the group/tournament's configured capacity, offer to generate
    // seating across multiple tables instead of silently waiting for a
    // manual click.
    final maxPerTable = app.effectiveTableSettings.maxPerTable;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _maybeShowSplitPrompt(
          context,
          app,
          checkedIn.length,
          maxPerTable,
          seatedYet,
        );
      }
    });

    return AppPage(
      maxWidth: 560,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          JourneyProgress(
            game: game,
            currentRoute: RoutePaths.checkIn,
            onStepTap: (step) => context.go(step.route),
          ),
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: [
              AppBackButton(onTap: () => context.go(RoutePaths.invitation)),
              const SizedBox(width: AppSpacing.md),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Check-in',
                    style: AppTypography.display(
                      size: AppFontSizes.xxxl,
                      weight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    game.settings.name,
                    style: AppTypography.bodySm.copyWith(
                      color: AppColors.mutedForeground,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // Event-day preparation (user-flow spec §4.6) — always the first
          // card so the admin never has to remember the sequence. We are on
          // the check-in screen itself, so step 2 has no open action.
          if (showChecklist) ...[
            EventDayChecklist(
              game: game,
              onOpenCheckIn: null,
              onOpenTvMode: () => context.go(RoutePaths.tvMode),
              onTestVoice: () {
                VoiceService.instance.speak('Voice test.');
              },
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
          // Summary
          AppCard(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg,
              vertical: AppSpacing.md,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _InlineStat(
                  label: 'Checked in',
                  value: '${checkedIn.length}/${players.length}',
                  color: AppColors.success,
                ),
                Container(width: 1, height: 24, color: AppColors.border),
                _InlineStat(
                  label: 'Pending',
                  value: '${pendingRequests.length}',
                  color: AppColors.warning,
                ),
                Container(width: 1, height: 24, color: AppColors.border),
                _InlineStat(
                  label: 'Not arrived',
                  value: '${notCheckedIn.length}',
                  color: AppColors.mutedForeground,
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // Section 6 -- the four head-count concepts, and the lock that makes
          // physical preparation safe. Chips get counted into stacks against a
          // number; once that has happened, a late RSVP must not quietly move
          // it. Locking freezes the figure the structure is built from, and
          // any subsequent drift is REPORTED rather than applied.
          _HeadcountCard(
            planned: app.plannedHeadcount(game),
            locked: game.settings.lockedExpectedPlayers,
            drift: app.lockedHeadcountDrift(game),
            checkedIn: checkedIn.length,
            onLock: () => app.lockExpectedPlayers(),
            onUnlock: app.unlockExpectedPlayers,
          ),
          // Addendum section 3: free hosting covers one table, up to nine
          // players. Surfaced HERE as well as at creation, because this is
          // where the count actually crosses the line -- a host who set up for
          // eight and had two more turn up finds out at the door, not after
          // starting.
          //
          // A notice, not a block. Section 3's monetization principle keeps
          // core tournament operation free, and refusing to check somebody in
          // at the table would be a worse product than telling the host their
          // night now needs two tables.
          // Read live rather than cached: the user can upgrade from the
          // button below this gate, and on returning the gate must be
          // gone. A tier snapshotted in initState would still say Free.
          if (Entitlements.hostingBlockedReason(
                    app.premiumTier,
                    checkedIn.length,
                  )
              case final blocked?) ...[
            const SizedBox(height: AppSpacing.lg),
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: AppColors.primarySoft,
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(
                  color: AppColors.primary.withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.workspace_premium,
                    size: 18,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(
                      blocked,
                      style: AppTypography.bodyXs.copyWith(
                        color: AppColors.foreground,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  AppButton(
                    size: AppButtonSize.sm,
                    onPressed: () => context.push(RoutePaths.upgrade),
                    child: const Text('See Premium'),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: AppSpacing.lg),
          if (pendingRequests.isNotEmpty) ...[
            AppAlertBanner(
              type: AppAlertType.warning,
              message:
                  '${pendingRequests.length} player${pendingRequests.length > 1 ? 's' : ''} waiting for confirmation',
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
          // Pending requests
          if (pendingRequests.isNotEmpty) ...[
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.sm),
                  child: Text(
                    'PENDING CHECK-IN REQUESTS',
                    style: AppTypography.bodyXs.copyWith(
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                      color: AppColors.warning,
                    ),
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  child: Container(
                    color: AppColors.card,
                    child: Column(
                      children: [
                        for (final g in pendingRequests)
                          _PendingGuestRow(
                            key: ValueKey('pending-${g.id}'),
                            guest: g,
                            inviter: g.isGuest
                                ? players
                                      .where((p) => p.id == g.inviterId)
                                      .firstOrNull
                                : null,
                            onConfirm: () => g.isGuest
                                ? app.confirmGuest(g.id)
                                : app.checkInPlayer(g.id),
                            onReject: () => g.isGuest
                                ? app.rejectGuest(g.id)
                                : app.cancelCheckIn(g.id),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
          // Players
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm, vertical: AppSpacing.sm),
                child: Text(
                  'PLAYERS',
                  style: AppTypography.bodyXs.copyWith(
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                    color: AppColors.mutedForeground,
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.lg),
                child: Container(
                  color: AppColors.card,
                  child: Column(
                    children: [
                      for (final p in players.where((p) => !p.isGuest))
                        Container(
                          key: ValueKey('player-${p.id}'),
                          padding: const EdgeInsets.symmetric(
                            vertical: AppSpacing.sm,
                            horizontal: AppSpacing.md,
                          ),
                          decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(color: AppColors.border)),
                          ),
                          child: Row(
                            children: [
                              AppAvatar(name: p.name, size: AppAvatarSize.sm),
                              const SizedBox(width: AppSpacing.md),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(p.name, style: AppTypography.bodySm.copyWith(fontWeight: FontWeight.w600)),
                                    if (p.rsvp != null)
                                      Text(
                                        '${p.rsvp!.label} RSVP',
                                        style: AppTypography.bodyXs.copyWith(
                                          color: AppColors.mutedForeground,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              if (p.checkedIn && p.confirmed)
                                const AppBadge(
                                  label: 'Checked in',
                                  variant: AppBadgeVariant.green,
                                )
                              else if (p.checkedIn)
                                AppButton(
                                  size: AppButtonSize.sm,
                                  variant: AppButtonVariant.secondary,
                                  onPressed: game.checkInClosed
                                      ? null
                                      : () => _acceptWithBuyIn(
                                            context,
                                            app,
                                            game,
                                            p,
                                          ),
                                  child: Text(
                                    game.checkInClosed
                                        ? 'Check-in closed'
                                        : game.hasPaid(
                                            p.id,
                                            PaymentPurpose.buyIn,
                                          )
                                            ? 'Accept check-in'
                                            : 'Take buy-in',
                                  ),
                                )
                              else if (p.id == app.user?.id)
                                AppButton(
                                  size: AppButtonSize.sm,
                                  variant: AppButtonVariant.secondary,
                                  onPressed: game.checkInClosed
                                      ? null
                                      : () => app.checkInPlayer(p.id),
                                  child: Text(
                                    game.checkInClosed
                                        ? 'Check-in closed'
                                        : 'Mark me in',
                                  ),
                                )
                              else
                                Text(
                                  'Not checked in yet',
                                  style: AppTypography.bodySm.copyWith(
                                    color: AppColors.mutedForeground,
                                  ),
                                ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          // Confirmed guests
          if (confirmedGuests.isNotEmpty) ...[
            AppCard(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Confirmed guests',
                    style: AppTypography.bodySm.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  for (final g in confirmedGuests)
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: AppSpacing.xs,
                      ),
                      child: Row(
                        children: [
                          AppAvatar(name: g.name, size: AppAvatarSize.sm),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(g.name, style: AppTypography.bodySm),
                                Text(
                                  'Guest of ${players.where((p) => p.id == g.inviterId).firstOrNull?.name ?? '?'}',
                                  style: AppTypography.bodyXs.copyWith(
                                    color: AppColors.mutedForeground,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const AppBadge(
                            label: 'Confirmed',
                            variant: AppBadgeVariant.green,
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
          // Seating
          AppCard(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Seating',
                  style: AppTypography.bodySm.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: AppSpacing.sm,
                  crossAxisSpacing: AppSpacing.sm,
                  childAspectRatio: 2.4,
                  children: [
                    // Addendum §3 "advanced table balancing and seating
                    // controls". PremiumBoundary draws the line: a random
                    // draw seats a night perfectly well and stays free;
                    // choosing WHO sits where is the advanced part.
                    for (final mode in SeatingMode.values)
                      PremiumLock(
                        tier: PremiumBoundary.freeSeatingModes
                                .contains(mode.name)
                            ? PremiumTier.premium // never locked
                            : app.premiumTier,
                        feature: PremiumFeature.advancedSeating,
                        child: _SeatingOption(
                          label: mode.label,
                          active: _seatingMode == mode,
                          onTap: () {
                            setState(() => _seatingMode = mode);
                            app.generateSeating(mode.tableMode);
                          },
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // Seating preview — grouped by the table each player is assigned to.
          if (checkedIn.isNotEmpty)
            Builder(
              builder: (context) {
                final byTable = <int, List<Player>>{};
                for (final p in checkedIn) {
                  byTable.putIfAbsent(p.table, () => []).add(p);
                }
                for (final list in byTable.values) {
                  list.sort((a, b) => a.seat.compareTo(b.seat));
                }
                final seatedYet = byTable.keys.any((t) => t > 0);
                final tables = byTable.keys.toList()..sort();
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (!seatedYet)
                      AppCard(
                        padding: const EdgeInsets.all(AppSpacing.lg),
                        child: Text(
                          'Pick a seating mode above to generate tables and seats.',
                          style: AppTypography.bodySm.copyWith(
                            color: AppColors.mutedForeground,
                          ),
                        ),
                      )
                    else
                      for (final table in tables)
                        Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.md),
                          child: AppCard(
                            padding: const EdgeInsets.all(AppSpacing.lg),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Table $table — ${byTable[table]!.length} seats',
                                  style: AppTypography.bodySm.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: AppSpacing.sm),
                                GridView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 3,
                                        mainAxisSpacing: AppSpacing.sm,
                                        crossAxisSpacing: AppSpacing.sm,
                                        childAspectRatio: 1.6,
                                      ),
                                  itemCount: byTable[table]!.length,
                                  itemBuilder: (context, i) {
                                    final p = byTable[table]![i];
                                    final isDealer =
                                        p.id == game.dealerPlayerId;
                                    return Container(
                                      padding: const EdgeInsets.all(
                                        AppSpacing.sm,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isDealer
                                            ? AppColors.primarySoft
                                            : AppColors.secondary,
                                        borderRadius: BorderRadius.circular(
                                          AppRadius.md,
                                        ),
                                        border: Border.all(
                                          color: isDealer
                                              ? AppColors.primary.withValues(
                                                  alpha: 0.5,
                                                )
                                              : AppColors.border,
                                        ),
                                      ),
                                      child: Column(
                                        children: [
                                          Text(
                                            isDealer
                                                ? 'Dealer · Seat ${p.seat}'
                                                : 'Seat ${p.seat}',
                                            style: AppTypography.bodyXs
                                                .copyWith(
                                                  color: isDealer
                                                      ? AppColors.primary
                                                      : AppColors
                                                            .mutedForeground,
                                                  fontWeight: isDealer
                                                      ? FontWeight.w700
                                                      : null,
                                                ),
                                          ),
                                          const SizedBox(height: AppSpacing.xxs),
                                          Text(
                                            p.name,
                                            style: AppTypography.bodySm
                                                .copyWith(
                                                  fontWeight: FontWeight.w500,
                                                ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          if (p.isGuest)
                                            Text(
                                              'Guest',
                                              style: AppTypography.bodyXs
                                                  .copyWith(
                                                    color: AppColors
                                                        .mutedForeground,
                                                  ),
                                            ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                  ],
                );
              },
            ),
          const SizedBox(height: AppSpacing.lg),
          // Check-in controls (admin)
          AppCard(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: AppButton(
                        variant: AppButtonVariant.secondary,
                        onPressed: game.checkInClosed
                            ? app.reopenCheckIn
                            : app.closeCheckIn,
                        child: Text(
                          game.checkInClosed
                              ? 'Reopen check-in'
                              : 'Close check-in',
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSpacing.sm),
                    Expanded(
                      child: AppButton(
                        variant: AppButtonVariant.secondary,
                        onPressed: game.rebuysClosed
                            ? null
                            : () => _showWalkInModal(context, app),
                        child: const Text('Walk-in'),
                      ),
                    ),
                  ],
                ),
                if (game.rebuysClosed) ...[
                  const SizedBox(height: AppSpacing.sm),
                  AppAlertBanner(
                    type: AppAlertType.warning,
                    message: 'Late registration is permanently closed. No new players can be added.',
                  ),
                ],
                const SizedBox(height: AppSpacing.sm),
                AppButton(
                  variant: AppButtonVariant.ghost,
                  onPressed: () => context.go(RoutePaths.tvMode),
                  child: const AppIconLabel(
                    label: 'Show assignment on TV',
                    icon: Icons.tv_outlined,
                  ),
                ),
                if (game.checkInClosed) ...[
                  const SizedBox(height: AppSpacing.md),
                  const AppAlertBanner(
                    type: AppAlertType.warning,
                    message:
                        'Check-in is closed. Reopen to accept more players or start the tournament below.',
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          // Start game
          if (!seatedYet)
            AppCard(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Text(
                'Generate the seating plan above, then confirm it before starting the game.',
                textAlign: TextAlign.center,
                style: AppTypography.bodySm.copyWith(
                  color: AppColors.mutedForeground,
                ),
              ),
            )
          else if (!seatingConfirmed)
            AppCard(
              padding: const EdgeInsets.all(AppSpacing.lg),
              borderColor: AppColors.warning.withValues(alpha: 0.4),
              child: Column(
                children: [
                  Text(
                    'Seating has been generated but not yet confirmed.',
                    textAlign: TextAlign.center,
                    style: AppTypography.bodySm.copyWith(
                      color: AppColors.warningText,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  AppButton(
                    variant: AppButtonVariant.primary,
                    fullWidth: true,
                    onPressed: app.confirmSeating,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.check_circle,
                          size: 14,
                          color: AppColors.icon,
                        ),
                        SizedBox(width: 6),
                        Text('Confirm physical seating'),
                      ],
                    ),
                  ),
                ],
              ),
            )
          else
            AppCard(
              padding: const EdgeInsets.all(AppSpacing.lg),
              borderColor: AppColors.successSoftBorder,
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle,
                    size: AppFontSizes.xl,
                    color: AppColors.success,
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Text(
                      'Seating confirmed. You can start the game.',
                      style: AppTypography.bodySm.copyWith(
                        color: AppColors.successText,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: AppSpacing.md),
          Row(
            children: [
              Expanded(
                child: AppButton(
                  variant: AppButtonVariant.secondary,
                  onPressed: () => context.go(RoutePaths.invitation),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.arrow_back, size: 14, color: AppColors.icon),
                      SizedBox(width: 6),
                      Text('Back'),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: AppButton(
                  // The real start action: [AppProvider.startBlockedReason]
                  // is the single precondition gate, [startTournament] freezes
                  // the head-count and starts the timer, then the host lands
                  // on the live dashboard so they are not left staring at the
                  // check-in desk.
                  loading: _starting,
                  onPressed: app.startBlockedReason == null
                      ? () async {
                          if (_starting) return;
                          setState(() => _starting = true);
                          await app.startTournament();
                          if (!mounted) return;
                          setState(() => _starting = false);
                          if (context.mounted) {
                            context.go(RoutePaths.adminDashboard);
                          }
                        }
                      : null,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          app.startBlockedReason ??
                              'Start with ${checkedIn.length} players',
                        ),
                        if (app.startBlockedReason == null) ...[
                          const SizedBox(width: 6),
                          Icon(
                            Icons.arrow_forward,
                            size: 14,
                            color: AppColors.icon,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.xxl),
        ],
      ),
    );
  }
}

class _InlineStat extends StatelessWidget {
  const _InlineStat({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: AppTypography.monoXl.copyWith(
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        const SizedBox(height: AppSpacing.xxs),
        Text(
          label.toUpperCase(),
          style: AppTypography.bodyXs.copyWith(
            color: AppColors.mutedForeground,
            letterSpacing: 1.0,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}

class _PendingGuestRow extends StatelessWidget {
  const _PendingGuestRow({
    super.key,
    required this.guest,
    required this.inviter,
    required this.onConfirm,
    required this.onReject,
  });

  final Player guest;
  final Player? inviter;
  final VoidCallback onConfirm;
  final VoidCallback onReject;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.border)),
      ),
      child: Row(
        children: [
          AppAvatar(
            name: guest.name.isEmpty ? '?' : guest.name,
            size: AppAvatarSize.sm,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  guest.name,
                  style: AppTypography.bodySm.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'Invited by ${inviter?.name ?? '?'}',
                  style: AppTypography.bodyXs.copyWith(
                    color: AppColors.mutedForeground,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          IconButton(
            icon: Icon(Icons.check_circle_outline, color: AppColors.success),
            onPressed: onConfirm,
            tooltip: 'Confirm',
          ),
          IconButton(
            icon: Icon(Icons.cancel_outlined, color: AppColors.destructive),
            onPressed: onReject,
            tooltip: 'Reject',
          ),
        ],
      ),
    );
  }
}

class _SeatingOption extends StatelessWidget {
  const _SeatingOption({
    required this.label,
    required this.active,
    required this.onTap,
  });

  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? AppColors.primarySoft : Colors.transparent,
          borderRadius: BorderRadius.circular(AppRadius.md),
          border: Border.all(
            color: active ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: AppTypography.bodySm.copyWith(
            color: active ? AppColors.primary : AppColors.mutedForeground,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}


/// Accepts a check-in, collecting the buy-in first if it is still owed.
///
/// QA case PN-DPAY-001 and section 14: money is collected, then the player is
/// official. Confirming first and collecting after would let a host start a
/// tournament whose prize pool does not match who is sitting at the table.
///
/// A player who has already paid — cash at the door, recorded earlier, or a
/// re-confirmation — skips straight through rather than being asked twice.
/// A declined or cancelled payment leaves them pending, which is the correct
/// state: present, not yet settled.
void _acceptWithBuyIn(
  BuildContext context,
  AppProvider app,
  LiveGame game,
  Player player,
) {
  if (game.hasPaid(player.id, PaymentPurpose.buyIn)) {
    app.checkInPlayer(player.id);
    return;
  }
  showDummyPaymentSheet(
    context: context,
    playerId: player.id,
    playerName: player.name,
    purpose: PaymentPurpose.buyIn,
    onSettled: (record) {
      if (record?.status == PaymentStatus.paid) app.checkInPlayer(player.id);
    },
  );
}

/// Section 6's head-count panel: what we are preparing for, whether it is
/// frozen, and how far RSVPs have drifted since it was.
class _HeadcountCard extends StatelessWidget {
  const _HeadcountCard({
    required this.planned,
    required this.locked,
    required this.drift,
    required this.checkedIn,
    required this.onLock,
    required this.onUnlock,
  });

  final int planned;
  final int? locked;
  final int? drift;
  final int checkedIn;
  final VoidCallback onLock;
  final VoidCallback onUnlock;

  @override
  Widget build(BuildContext context) {
    final isLocked = locked != null;
    return AppCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(
                isLocked ? Icons.lock_outline : Icons.lock_open_outlined,
                size: 16,
                color: isLocked
                    ? AppColors.primary
                    : AppColors.mutedForeground,
              ),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  isLocked
                      ? 'Preparing for $locked players'
                      : 'Preparing for $planned players',
                  style: AppTypography.bodySm.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              AppButton(
                size: AppButtonSize.sm,
                variant: isLocked
                    ? AppButtonVariant.secondary
                    : AppButtonVariant.primary,
                onPressed: isLocked ? onUnlock : onLock,
                child: Text(isLocked ? 'Unlock' : 'Lock for prep'),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            isLocked
                ? 'Locked. Late RSVP changes will not move this number or '
                      'rebuild the structure.'
                : 'Following RSVPs. Lock it once you have counted chips into '
                      'stacks.',
            style: AppTypography.bodyXs.copyWith(
              color: AppColors.mutedForeground,
            ),
          ),
          // Drift is surfaced, never applied -- that is the whole point of
          // the lock. The host decides whether to re-lock.
          if (isLocked && drift != null && drift != 0) ...[
            const SizedBox(height: AppSpacing.sm),
            Container(
              padding: const EdgeInsets.all(AppSpacing.sm),
              decoration: BoxDecoration(
                color: AppColors.primarySoft,
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(
                  color: AppColors.primary.withValues(alpha: 0.3),
                ),
              ),
              child: Text(
                drift! > 0
                    ? 'RSVPs have grown by $drift since you locked. Unlock and '
                          'lock again to prepare for the larger field.'
                    : 'RSVPs have dropped by ${-drift!} since you locked. The '
                          'preparation is unchanged.',
                style: AppTypography.bodyXs.copyWith(
                  color: AppColors.foreground,
                ),
              ),
            ),
          ],
          if (checkedIn > 0) ...[
            const SizedBox(height: AppSpacing.sm),
            Text(
              // Section 6: the START CTA uses actual checked-in, not this.
              '$checkedIn checked in so far — the start button uses that '
              'count, not the prepared one.',
              style: AppTypography.bodyXs.copyWith(
                color: AppColors.mutedForeground,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
