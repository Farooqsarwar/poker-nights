import 'package:flutter/material.dart';

/// Centralized spacing scale (mirrors Tailwind spacing).
class AppSpacing {
  AppSpacing._();

  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24; // Increased from 20 to 24 for more room
  static const double xxl = 32; // Increased from 24 to 32
  static const double xxxl = 40; // Increased from 32 to 40
  static const double huge = 48; // Increased from 40 to 48
  static const double page = 32; // Increased from 24
  static const double section = 40; // Increased from 32

  static const EdgeInsets pagePadding = EdgeInsets.symmetric(
    horizontal: xl,
    vertical: xxl,
  );

  /// Compact-layout page padding.
  ///
  /// Deliberately carries NO extra bottom clearance for the floating bottom
  /// nav. The nav belongs to `ScreenShell`, so the shell pads for it exactly
  /// once, using the nav's own height. This used to add a hardcoded `bottom:
  /// 96` on top of the shell's own `64 + inset`, so compact screens paid for
  /// the nav twice (~160px of dead space) while tablet-width screens — which
  /// took the desktop padding — did not pay for it at all.
  static const EdgeInsets mobileContentPadding = EdgeInsets.only(
    left: xl,
    right: xl,
    top: xl,
    bottom: xl,
  );

  static const EdgeInsets desktopContentPadding = EdgeInsets.only(
    left: xxxl,
    right: xxxl,
    top: xxxl,
    bottom: xxxl,
  );
}

/// Centralized border radius scale (modern, premium squircle-like rounding).
class AppRadius {
  AppRadius._();

  static const double xs = 6;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double pill = 999;
}

/// Centralized shadows (mirrors .card-glow / .card-glow-active / glass).
class AppShadows {
  AppShadows._();

  static const List<BoxShadow> cardGlow = [
    BoxShadow(color: Color(0x1A7F1D1D), blurRadius: 1, spreadRadius: 0),
    BoxShadow(color: Color(0x66000000), blurRadius: 24, offset: Offset(0, 4)),
  ];

  static const List<BoxShadow> cardGlowActive = [
    BoxShadow(color: Color(0x667F1D1D), blurRadius: 1, spreadRadius: 0),
    BoxShadow(color: Color(0x1F7F1D1D), blurRadius: 32, offset: Offset(0, 4)),
  ];

  static const List<BoxShadow> glassPanel = [
    BoxShadow(color: Color(0x80000000), blurRadius: 32, offset: Offset(0, 8)),
  ];

  static const List<BoxShadow> primaryGlow = [
    BoxShadow(color: Color(0x337F1D1D), blurRadius: 15),
  ];

  static const List<BoxShadow> successGlow = [
    BoxShadow(color: Color(0x26166534), blurRadius: 20),
  ];

  static const List<BoxShadow> softCard = [
    BoxShadow(color: Color(0x0D000000), blurRadius: 6, offset: Offset(0, 2)),
  ];
}

/// Centralized motion durations.
class AppDurations {
  AppDurations._();

  static const Duration fastest = Duration(milliseconds: 100);
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration normal = Duration(milliseconds: 300);
  static const Duration slow = Duration(milliseconds: 500);
}

/// Centralized font sizes (Tailwind text scale).
class AppFontSizes {
  AppFontSizes._();

  static const double xs = 12;
  static const double sm = 14;
  static const double md = 16;
  static const double lg = 18;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 30;
  static const double display = 36;
  static const double displayLg = 48;
  static const double displayXl = 60;
  static const double displayHero = 72;
}

/// Centralized asset paths.
class AppAssets {
  AppAssets._();

  static const String spade = '♠';
  static const String heart = '♥';
  static const String diamond = '♦';
  static const String club = '♣';
}
